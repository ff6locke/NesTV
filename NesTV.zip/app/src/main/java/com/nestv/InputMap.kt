package com.nestv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent

/**
 * Maps Android key codes (TV remote such as the G60S, keyboards, gamepads) to NES buttons.
 * Bits: 0 A, 1 B, 2 Select, 3 Start, 4 Up, 5 Down, 6 Left, 7 Right.
 */
class InputMap(ctx: Context) {
    companion object {
        const val A = 1
        const val B = 2
        const val SELECT = 4
        const val START = 8
        const val UP = 16
        const val DOWN = 32
        const val LEFT = 64
        const val RIGHT = 128
        const val TA = 256   // turbo A
        const val TB = 512   // turbo B
        // actions (not NES buttons): they fire once when the key goes down
        const val MENU = 1024
        const val FF = 2048
        const val SAVE = 4096
        const val LOAD = 8192
        const val SLOT_NEXT = 16384
        const val SLOT_PREV = 32768
        const val ACTION_MASK = 0xFC00
        // "hold" bindings: NES button bit shifted left by 16 toggles that button on/off until pressed again
        const val LATCH_MASK = 0xFF0000
        const val CLEAR_LATCH = 0x1000000
        const val ASSIST_MS = 40L   // how long a release is held back so a following key press can be matched to it
        const val GUIDED = 10   // the guided setup walks through the first 10 entries (the NES buttons)
        val NAMES = arrayOf(
            "A", "B", "Select", "Start", "Up", "Down", "Left", "Right", "Turbo A", "Turbo B",
            "Open menu", "Fast forward (toggle)", "Quick save state", "Quick load state", "Next save slot", "Previous save slot"
        )
        val WIZARD_BITS = intArrayOf(A, B, SELECT, START, UP, DOWN, LEFT, RIGHT, TA, TB, MENU, FF, SAVE, LOAD, SLOT_NEXT, SLOT_PREV)

        // one key that presses several NES buttons at once (for remotes that only send two keys together)
        val COMBO_NAMES = arrayOf(
            "A + B", "Right + A", "Right + B", "Right + A + B", "Left + A", "Left + B", "Left + A + B",
            "Up + A", "Up + B", "Down + A", "Down + B"
        )
        val COMBO_BITS = intArrayOf(
            A or B, RIGHT or A, RIGHT or B, RIGHT or A or B, LEFT or A, LEFT or B, LEFT or A or B,
            UP or A, UP or B, DOWN or A, DOWN or B
        )
        val LATCH_NAMES = arrayOf(
            "Hold A on/off", "Hold B on/off", "Hold Right on/off", "Hold Left on/off", "Hold Up on/off", "Hold Down on/off",
            "Release all held buttons"
        )
        val LATCH_BITS = intArrayOf(A shl 16, B shl 16, RIGHT shl 16, LEFT shl 16, UP shl 16, DOWN shl 16, CLEAR_LATCH)
    }

    private val prefs = ctx.getSharedPreferences("input", Context.MODE_PRIVATE)
    private val map = HashMap<Int, Int>()

    @Volatile var keys = 0
    @Volatile var axes = 0
    var onAction: ((Int) -> Unit)? = null
    var onLatch: ((Int) -> Unit)? = null
    @Volatile var latched = 0
    @Volatile var releaseMs = prefs.getInt("release_ms", 0)   // keep a key "down" this long after its release event

    // Rollover assist: 0 off, 1 normal (60 ms), 2 wide (200 ms). Covers for a key the remote drops when a third key goes down.
    @Volatile var assistLevel = prefs.getInt("assist_level", if (prefs.getBoolean("assist", false)) 1 else 0)
    val assist: Boolean get() = assistLevel > 0
    private val assistWindow: Long get() = when (assistLevel) { 1 -> 60L; 2 -> 200L; else -> 0L }
    private val ghost = HashSet<Int>()                  // keys whose release was ignored (probably dropped by the remote)
    private val ghostTimers = HashMap<Int, Runnable>()
    private var lastDownKey = 0
    private val downAt = HashMap<Int, Long>()      // when each held key first went down
    private var lastDownAt = 0L
    private val held = HashMap<Int, Int>()          // key code -> NES bits it holds while down
    private val pending = HashMap<Int, Runnable>()  // delayed releases
    private val handler = Handler(Looper.getMainLooper())
    @Volatile var touch = 0
    @Volatile var turboPhase = 0

    /** NES pad bits; turbo buttons press A/B on alternate phases. */
    val pad: Int get() {
        val m = keys or axes or touch or latched
        var r = m and 0xFF
        if (turboPhase == 0) {
            if ((m and TA) != 0) r = r or A
            if ((m and TB) != 0) r = r or B
        }
        return r
    }

    val configured: Boolean get() = prefs.contains("map")

    init { load() }

    private fun defaults() {
        val d = mapOf(
            KeyEvent.KEYCODE_DPAD_UP to UP, KeyEvent.KEYCODE_DPAD_DOWN to DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT to LEFT, KeyEvent.KEYCODE_DPAD_RIGHT to RIGHT,
            KeyEvent.KEYCODE_DPAD_CENTER to A, KeyEvent.KEYCODE_ENTER to A,
            KeyEvent.KEYCODE_BUTTON_B to A, KeyEvent.KEYCODE_BUTTON_Y to A,
            KeyEvent.KEYCODE_BUTTON_A to B, KeyEvent.KEYCODE_BUTTON_X to B,
            KeyEvent.KEYCODE_BUTTON_R1 to TA, KeyEvent.KEYCODE_BUTTON_L1 to TB,
            KeyEvent.KEYCODE_BUTTON_START to START, KeyEvent.KEYCODE_BUTTON_SELECT to SELECT,
            KeyEvent.KEYCODE_W to UP, KeyEvent.KEYCODE_S to DOWN,
            KeyEvent.KEYCODE_A to LEFT, KeyEvent.KEYCODE_D to RIGHT,
            KeyEvent.KEYCODE_Z to B, KeyEvent.KEYCODE_X to A
        )
        // a function the user has remapped loses its default keys
        val bound = HashSet<Int>(map.values)
        for ((k, v) in d) if (!map.containsKey(k) && !bound.contains(v)) map[k] = v
    }

    fun load() {
        map.clear()
        val s = prefs.getString("map", null)
        if (!s.isNullOrEmpty()) {
            for (item in s.split(",")) {
                val p = item.split(":")
                if (p.size == 2) map[p[0].toInt()] = p[1].toInt()
            }
        }
        defaults()
    }

    /** Replace the A/B/Select/Start bindings with [custom] (keyCode -> bit). Directions keep their defaults. */
    fun save(custom: Map<Int, Int>) {
        prefs.edit().putString("map", custom.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()
        load()
    }

    fun reset() {
        prefs.edit().remove("map").apply()
        load()
    }

    fun bitFor(keyCode: Int): Int = map[keyCode] ?: 0

    /** The user's own bindings (key code -> bit), without the built-in defaults. */
    fun custom(): HashMap<Int, Int> {
        val r = HashMap<Int, Int>()
        val s = prefs.getString("map", null)
        if (!s.isNullOrEmpty()) {
            for (item in s.split(",")) {
                val p = item.split(":")
                if (p.size == 2) r[p[0].toInt()] = p[1].toInt()
            }
        }
        return r
    }

    /** Names of the keys currently bound to a button, for display. */
    fun labelFor(bit: Int): String {
        val names = map.filter { it.value == bit }.keys.map { KeyEvent.keyCodeToString(it).removePrefix("KEYCODE_") }
        return if (names.isEmpty()) "(none)" else names.sorted().joinToString(", ")
    }

    fun setRelease(ms: Int) {
        releaseMs = ms
        prefs.edit().putInt("release_ms", ms).apply()
    }

    fun cycleAssist() {
        assistLevel = (assistLevel + 1) % 3
        prefs.edit().putInt("assist_level", assistLevel).apply()
        releaseAll()
    }

    private fun opposite(a: Int, b: Int): Boolean =
        ((a and LEFT) != 0 && (b and RIGHT) != 0) || ((a and RIGHT) != 0 && (b and LEFT) != 0) ||
            ((a and UP) != 0 && (b and DOWN) != 0) || ((a and DOWN) != 0 && (b and UP) != 0)

    private fun markGhost(k: Int) {
        ghost.add(k)
        ghostTimers.remove(k)?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            ghostTimers.remove(k)
            if (ghost.remove(k)) { held.remove(k); downAt.remove(k); recompute() }
        }
        ghostTimers[k] = r
        handler.postDelayed(r, 30000)
    }

    private fun cancelGhost(k: Int) {
        ghost.remove(k)
        ghostTimers.remove(k)?.let { handler.removeCallbacks(it) }
    }

    /** Once nothing but assumed-held keys remain, let them go. */
    private fun releaseGhostsIfAlone() {
        if (ghost.isNotEmpty() && held.keys.all { ghost.contains(it) }) {
            for (g in ghost.toList()) { held.remove(g); downAt.remove(g); ghostTimers.remove(g)?.let { handler.removeCallbacks(it) } }
            ghost.clear()
            recompute()
        }
    }

    /** The key among [set] that has been down the longest. */
    private fun oldest(set: List<Int>): Int {
        var best = set[0]
        var bt = downAt[best] ?: Long.MAX_VALUE
        for (k in set) {
            val t = downAt[k] ?: Long.MAX_VALUE
            if (t < bt) { best = k; bt = t }
        }
        return best
    }

    private fun recompute() {
        var m = 0
        for (b in held.values) m = m or b
        keys = m
    }

    /** Forget every held key (used when a menu opens, so nothing stays stuck down). */
    fun releaseAll() {
        for (r in pending.values) handler.removeCallbacks(r)
        for (r in ghostTimers.values) handler.removeCallbacks(r)
        pending.clear()
        ghostTimers.clear()
        ghost.clear()
        downAt.clear()
        held.clear()
        keys = 0
    }

    fun onKey(e: KeyEvent): Boolean {
        val kc = e.keyCode
        val bit = bitFor(kc)
        if (bit == 0) return false
        if ((bit and CLEAR_LATCH) != 0) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) { latched = 0; onLatch?.invoke(0) }
            return true
        }
        if ((bit and LATCH_MASK) != 0) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
                latched = latched xor ((bit ushr 16) and 0xFF)
                onLatch?.invoke(latched)
            }
            return true
        }
        if ((bit and ACTION_MASK) != 0) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) onAction?.invoke(bit)
            return true
        }
        val now = SystemClock.uptimeMillis()
        when (e.action) {
            KeyEvent.ACTION_DOWN -> {
                if (e.repeatCount == 0) {
                    // A new key went down while another key's release was still pending: that release was
                    // most likely the remote dropping the old key, so keep the old key held for now.
                    if (assist) {
                        for (entry in pending.entries.toList()) {
                            val k = entry.key
                            // A remote with two key slots drops its OLDEST key when a third goes down, so a release only
                            // counts as a drop if it is the oldest of exactly two keys held before this press.
                            val live = held.keys.filter { !ghost.contains(it) }
                            if (k != kc && live.size == 2 && oldest(live) == k && !opposite(held[k] ?: 0, bit)) {
                                handler.removeCallbacks(entry.value)
                                pending.remove(k)
                                markGhost(k)
                            }
                        }
                    }
                    lastDownKey = kc
                    lastDownAt = now
                }
                pending.remove(kc)?.let { handler.removeCallbacks(it) }
                if (!held.containsKey(kc) || ghost.contains(kc)) downAt[kc] = now
                cancelGhost(kc)
                held[kc] = bit
                recompute()
            }
            KeyEvent.ACTION_UP -> {
                if (!held.containsKey(kc)) return true
                if (ghost.contains(kc)) cancelGhost(kc)
                else if (assist && kc != lastDownKey && now - lastDownAt <= assistWindow &&
                    !opposite(held[kc] ?: 0, bitFor(lastDownKey))
                ) {
                    // released right after a third key went down, and it was the oldest of the three: the remote dropped it
                    val live = held.keys.filter { !ghost.contains(it) }
                    if (live.size == 3 && oldest(live) == kc) {
                        markGhost(kc)
                        return true
                    }
                }
                val delay = maxOf(releaseMs, if (assist) ASSIST_MS.toInt() else 0)
                if (delay > 0) {
                    pending.remove(kc)?.let { handler.removeCallbacks(it) }
                    val r = Runnable {
                        pending.remove(kc)
                        held.remove(kc)
                        downAt.remove(kc)
                        recompute()
                        releaseGhostsIfAlone()
                    }
                    pending[kc] = r
                    handler.postDelayed(r, delay.toLong())
                } else {
                    held.remove(kc)
                    downAt.remove(kc)
                    recompute()
                    releaseGhostsIfAlone()
                }
            }
        }
        return true
    }

    /** D-pad hat / left stick from Bluetooth gamepads. */
    fun onMotion(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_MOVE) return false
        val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val lx = e.getAxisValue(MotionEvent.AXIS_X)
        val ly = e.getAxisValue(MotionEvent.AXIS_Y)
        var m = 0
        if (hx < -0.5f || lx < -0.5f) m = m or LEFT
        if (hx > 0.5f || lx > 0.5f) m = m or RIGHT
        if (hy < -0.5f || ly < -0.5f) m = m or UP
        if (hy > 0.5f || ly > 0.5f) m = m or DOWN
        axes = m
        return true
    }
}
