package com.nestv

import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent

/**
 * Maps Android key codes (TV remote such as the G60S, keyboards, gamepads) to NES buttons.
 * Bits: 0 A, 1 B, 2 Select, 3 Start, 4 Up, 5 Down, 6 Left, 7 Right.
 */
class InputMap(ctx: Context) {
    companion object {
        const val A = 1
        const val B = 2
        const val SELECT = 4
        const val START = 8
        const val UP = 16
        const val DOWN = 32
        const val LEFT = 64
        const val RIGHT = 128
        val NAMES = arrayOf("A", "B", "Select", "Start")
        val WIZARD_BITS = intArrayOf(A, B, SELECT, START)
    }

    private val prefs = ctx.getSharedPreferences("input", Context.MODE_PRIVATE)
    private val map = HashMap<Int, Int>()

    @Volatile var keys = 0
    @Volatile var axes = 0
    @Volatile var touch = 0
    val pad: Int get() = keys or axes or touch

    val configured: Boolean get() = prefs.contains("map")

    init { load() }

    private fun defaults() {
        val d = mapOf(
            KeyEvent.KEYCODE_DPAD_UP to UP, KeyEvent.KEYCODE_DPAD_DOWN to DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT to LEFT, KeyEvent.KEYCODE_DPAD_RIGHT to RIGHT,
            KeyEvent.KEYCODE_DPAD_CENTER to A, KeyEvent.KEYCODE_ENTER to A,
            KeyEvent.KEYCODE_BUTTON_B to A, KeyEvent.KEYCODE_BUTTON_Y to A,
            KeyEvent.KEYCODE_BUTTON_A to B, KeyEvent.KEYCODE_BUTTON_X to B,
            KeyEvent.KEYCODE_BUTTON_START to START, KeyEvent.KEYCODE_BUTTON_SELECT to SELECT,
            KeyEvent.KEYCODE_W to UP, KeyEvent.KEYCODE_S to DOWN,
            KeyEvent.KEYCODE_A to LEFT, KeyEvent.KEYCODE_D to RIGHT,
            KeyEvent.KEYCODE_Z to B, KeyEvent.KEYCODE_X to A
        )
        for ((k, v) in d) if (!map.containsKey(k)) map[k] = v
    }

    fun load() {
        map.clear()
        val s = prefs.getString("map", null)
        if (!s.isNullOrEmpty()) {
            for (item in s.split(",")) {
                val p = item.split(":")
                if (p.size == 2) map[p[0].toInt()] = p[1].toInt()
            }
        }
        defaults()
    }

    /** Replace the A/B/Select/Start bindings with [custom] (keyCode -> bit). Directions keep their defaults. */
    fun save(custom: Map<Int, Int>) {
        prefs.edit().putString("map", custom.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()
        load()
    }

    fun reset() {
        prefs.edit().remove("map").apply()
        load()
    }

    fun bitFor(keyCode: Int): Int = map[keyCode] ?: 0

    fun onKey(e: KeyEvent): Boolean {
        val bit = bitFor(e.keyCode)
        if (bit == 0) return false
        when (e.action) {
            KeyEvent.ACTION_DOWN -> keys = keys or bit
            KeyEvent.ACTION_UP -> keys = keys and bit.inv()
        }
        return true
    }

    /** D-pad hat / left stick from Bluetooth gamepads. */
    fun onMotion(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_MOVE) return false
        val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val lx = e.getAxisValue(MotionEvent.AXIS_X)
        val ly = e.getAxisValue(MotionEvent.AXIS_Y)
        var m = 0
        if (hx < -0.5f || lx < -0.5f) m = m or LEFT
        if (hx > 0.5f || lx > 0.5f) m = m or RIGHT
        if (hy < -0.5f || ly < -0.5f) m = m or UP
        if (hy > 0.5f || ly > 0.5f) m = m or DOWN
        axes = m
        return true
    }
}
