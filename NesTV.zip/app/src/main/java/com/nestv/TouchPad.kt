package com.nestv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** On-screen NES controller for phones: D-pad, A, B, Select, Start and a menu button. Multi-touch. */
class TouchPad(ctx: Context, private val input: InputMap, private val onMenu: () -> Unit) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x88FFFFFF.toInt() }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFFFFF.toInt(); textAlign = Paint.Align.CENTER }

    private var dcx = 0f; private var dcy = 0f; private var dr = 0f
    private var acx = 0f; private var acy = 0f
    private var bcx = 0f; private var bcy = 0f; private var br = 0f
    private var selR = RectF(); private var staR = RectF()
    private var mcx = 0f; private var mcy = 0f; private var mr = 0f

    init { isFocusable = false }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = minOf(w, h).toFloat()
        dr = s * 0.17f
        dcx = dr * 1.35f
        dcy = h - dr * 1.45f
        br = s * 0.095f
        acx = w - br * 1.5f
        acy = h - br * 3.2f
        bcx = acx - br * 2.7f
        bcy = acy + br * 1.3f
        val pw = s * 0.2f
        val ph = s * 0.075f
        val py = h - ph * 1.8f
        selR = RectF(w / 2f - pw * 1.15f, py - ph / 2, w / 2f - pw * 0.15f, py + ph / 2)
        staR = RectF(w / 2f + pw * 0.15f, py - ph / 2, w / 2f + pw * 1.15f, py + ph / 2)
        mr = s * 0.045f
        mcx = w - s * 0.07f
        mcy = s * 0.07f
        stroke.strokeWidth = s * 0.006f
        text.textSize = br * 0.8f
    }

    private fun inMenu(x: Float, y: Float): Boolean {
        val dx = x - mcx; val dy = y - mcy
        return dx * dx + dy * dy <= (mr * 1.6f) * (mr * 1.6f)
    }

    private fun near(x: Float, y: Float, cx: Float, cy: Float, r: Float): Boolean {
        val dx = x - cx; val dy = y - cy
        return dx * dx + dy * dy <= r * r
    }

    private fun hit(x: Float, y: Float): Int {
        var m = 0
        val dx = x - dcx
        val dy = y - dcy
        if (dx * dx + dy * dy <= (dr * 1.7f) * (dr * 1.7f)) {
            val dz = dr * 0.3f
            if (dx < -dz) m = m or InputMap.LEFT
            if (dx > dz) m = m or InputMap.RIGHT
            if (dy < -dz) m = m or InputMap.UP
            if (dy > dz) m = m or InputMap.DOWN
        }
        if (near(x, y, acx, acy, br * 1.4f)) m = m or InputMap.A
        if (near(x, y, bcx, bcy, br * 1.4f)) m = m or InputMap.B
        val pad = selR.height() * 0.4f
        if (x >= selR.left - pad && x <= selR.right + pad && y >= selR.top - pad && y <= selR.bottom + pad) m = m or InputMap.SELECT
        if (x >= staR.left - pad && x <= staR.right + pad && y >= staR.top - pad && y <= staR.bottom + pad) m = m or InputMap.START
        return m
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val act = e.actionMasked
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            if (inMenu(e.getX(i), e.getY(i))) { onMenu(); return true }
        }
        var m = 0
        if (act != MotionEvent.ACTION_CANCEL) {
            val skip = if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
            for (i in 0 until e.pointerCount) {
                if (i == skip) continue
                m = m or hit(e.getX(i), e.getY(i))
            }
        }
        if (m != input.touch) {
            input.touch = m
            invalidate()
        }
        return true
    }

    private fun shade(on: Boolean) { fill.color = if (on) 0x99FFFFFF.toInt() else 0x44FFFFFF }

    override fun onDraw(c: Canvas) {
        val t = input.touch
        // D-pad
        shade(false)
        c.drawCircle(dcx, dcy, dr * 1.15f, fill)
        c.drawCircle(dcx, dcy, dr * 1.15f, stroke)
        val a = dr * 0.42f
        val l = dr * 1.0f
        shade((t and InputMap.UP) != 0);    c.drawRect(dcx - a, dcy - l, dcx + a, dcy - a * 0.2f, fill)
        shade((t and InputMap.DOWN) != 0);  c.drawRect(dcx - a, dcy + a * 0.2f, dcx + a, dcy + l, fill)
        shade((t and InputMap.LEFT) != 0);  c.drawRect(dcx - l, dcy - a, dcx - a * 0.2f, dcy + a, fill)
        shade((t and InputMap.RIGHT) != 0); c.drawRect(dcx + a * 0.2f, dcy - a, dcx + l, dcy + a, fill)
        // A / B
        shade((t and InputMap.A) != 0)
        c.drawCircle(acx, acy, br, fill); c.drawCircle(acx, acy, br, stroke)
        c.drawText("A", acx, acy + br * 0.28f, text)
        shade((t and InputMap.B) != 0)
        c.drawCircle(bcx, bcy, br, fill); c.drawCircle(bcx, bcy, br, stroke)
        c.drawText("B", bcx, bcy + br * 0.28f, text)
        // Select / Start
        val rr = selR.height() / 2
        text.textSize = br * 0.45f
        shade((t and InputMap.SELECT) != 0)
        c.drawRoundRect(selR, rr, rr, fill); c.drawRoundRect(selR, rr, rr, stroke)
        c.drawText("SELECT", selR.centerX(), selR.centerY() + br * 0.16f, text)
        shade((t and InputMap.START) != 0)
        c.drawRoundRect(staR, rr, rr, fill); c.drawRoundRect(staR, rr, rr, stroke)
        c.drawText("START", staR.centerX(), staR.centerY() + br * 0.16f, text)
        text.textSize = br * 0.8f
        // Menu button
        shade(false)
        c.drawCircle(mcx, mcy, mr, fill); c.drawCircle(mcx, mcy, mr, stroke)
        val bw = mr * 0.9f
        for (k in -1..1) c.drawLine(mcx - bw / 2, mcy + k * mr * 0.3f, mcx + bw / 2, mcy + k * mr * 0.3f, stroke)
    }
}
