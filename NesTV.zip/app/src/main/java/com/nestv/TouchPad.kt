package com.nestv

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * On-screen NES controller for phones: D-pad, A, B, turbo A/B, Select, Start and a menu button.
 * Multi-touch. Opacity, position and size of every control are adjustable and remembered.
 */
class TouchPad(
    ctx: Context,
    private val input: InputMap,
    private val prefs: SharedPreferences,
    private val onMenu: () -> Unit
) : View(ctx) {

    companion object {
        const val DPAD = 0
        const val BTN_A = 1
        const val BTN_B = 2
        const val TURBO_A = 3
        const val TURBO_B = 4
        const val SEL = 5
        const val STA = 6
        const val MENU = 7
        const val N = 8
        private val EDIT_LABELS = arrayOf("Smaller", "Bigger", "Reset", "Done")
    }

    private val fx = FloatArray(N)   // centre of each control as a fraction of the view size
    private val fy = FloatArray(N)
    private val fs = FloatArray(N)   // size multiplier of each control
    private var sz = 0f

    private var op = prefs.getInt("touch_alpha", 45) / 100f
    private var drawOp = op
    private var themeIdx = prefs.getInt("touch_theme", 0)

    private fun theme(): TouchTheme = TouchThemes.LIST[themeIdx.coerceIn(0, TouchThemes.LIST.size - 1)]

    /** Re-read opacity and theme from the preferences (after the settings screen changed them). */
    fun reloadStyle() {
        op = prefs.getInt("touch_alpha", 45) / 100f
        themeIdx = prefs.getInt("touch_theme", 0)
        invalidate()
    }

    var opacity: Float
        get() = op
        set(v) { op = v.coerceIn(0.1f, 1f); invalidate() }

    var editing = false
        private set
    private var selected = -1
    private var offX = 0f
    private var offY = 0f
    private var onEditDone: (() -> Unit)? = null
    private val editRects = Array(4) { RectF() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val hl = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFFFD600.toInt() }

    init { isFocusable = false }

    // ---------- layout ----------
    private fun defaultCentres(w: Int, h: Int): Array<FloatArray> {
        val s = minOf(w, h).toFloat()
        val dr = s * 0.17f
        val br = s * 0.095f
        val ax = w - br * 1.5f
        val ay = h - br * 3.2f
        val bx = ax - br * 2.7f
        val by = ay + br * 1.3f
        val pw = s * 0.2f
        val py = h - s * 0.075f * 1.8f
        return arrayOf(
            floatArrayOf(dr * 1.35f, h - dr * 1.45f),
            floatArrayOf(ax, ay),
            floatArrayOf(bx, by),
            floatArrayOf(ax, ay - br * 2.15f),
            floatArrayOf(bx, by - br * 2.15f),
            floatArrayOf(w / 2f - pw * 0.65f, py),
            floatArrayOf(w / 2f + pw * 0.65f, py),
            floatArrayOf(w - s * 0.07f, s * 0.07f)
        )
    }

    private fun loadLayout(w: Int, h: Int) {
        val d = defaultCentres(w, h)
        for (i in 0 until N) {
            fx[i] = prefs.getFloat("tp_x$i", d[i][0] / w)
            fy[i] = prefs.getFloat("tp_y$i", d[i][1] / h)
            fs[i] = prefs.getFloat("tp_s$i", 1f)
        }
    }

    private fun saveLayout() {
        val e = prefs.edit()
        for (i in 0 until N) {
            e.putFloat("tp_x$i", fx[i]); e.putFloat("tp_y$i", fy[i]); e.putFloat("tp_s$i", fs[i])
        }
        e.apply()
    }

    private fun resetLayout() {
        val e = prefs.edit()
        for (i in 0 until N) { e.remove("tp_x$i"); e.remove("tp_y$i"); e.remove("tp_s$i") }
        e.apply()
        loadLayout(width, height)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sz = minOf(w, h).toFloat()
        loadLayout(w, h)
        val bw = sz * 0.30f
        val bh = sz * 0.10f
        val gap = sz * 0.02f
        val left = (w - (4 * bw + 3 * gap)) / 2f
        for (k in 0 until 4) {
            val l = left + k * (bw + gap)
            editRects[k].set(l, sz * 0.03f, l + bw, sz * 0.03f + bh)
        }
    }

    private fun cx(i: Int) = fx[i] * width
    private fun cy(i: Int) = fy[i] * height
    private fun radius(i: Int): Float = when (i) {
        DPAD -> sz * 0.17f * fs[i]
        BTN_A, BTN_B -> sz * 0.095f * fs[i]
        TURBO_A, TURBO_B -> sz * 0.095f * 0.7f * fs[i]
        MENU -> sz * 0.045f * fs[i]
        else -> 0f
    }
    private fun pillW(i: Int) = sz * 0.2f * fs[i]
    private fun pillH(i: Int) = sz * 0.075f * fs[i]

    private fun pillRect(i: Int, grow: Float = 0f): RectF {
        val hw = pillW(i) / 2 + grow
        val hh = pillH(i) / 2 + grow
        return RectF(cx(i) - hw, cy(i) - hh, cx(i) + hw, cy(i) + hh)
    }

    private fun near(x: Float, y: Float, i: Int, r: Float): Boolean {
        val dx = x - cx(i)
        val dy = y - cy(i)
        return dx * dx + dy * dy <= r * r
    }

    // ---------- play mode ----------
    private fun hit(x: Float, y: Float): Int {
        var m = 0
        val dr = radius(DPAD)
        if (near(x, y, DPAD, dr * 1.7f)) {
            val dx = x - cx(DPAD)
            val dy = y - cy(DPAD)
            val dz = dr * 0.3f
            if (dx < -dz) m = m or InputMap.LEFT
            if (dx > dz) m = m or InputMap.RIGHT
            if (dy < -dz) m = m or InputMap.UP
            if (dy > dz) m = m or InputMap.DOWN
        }
        if (near(x, y, BTN_A, radius(BTN_A) * 1.4f)) m = m or InputMap.A
        if (near(x, y, BTN_B, radius(BTN_B) * 1.4f)) m = m or InputMap.B
        if (near(x, y, TURBO_A, radius(TURBO_A) * 1.4f)) m = m or InputMap.TA
        if (near(x, y, TURBO_B, radius(TURBO_B) * 1.4f)) m = m or InputMap.TB
        val g = pillH(SEL) * 0.4f
        if (pillRect(SEL, g).contains(x, y)) m = m or InputMap.SELECT
        if (pillRect(STA, g).contains(x, y)) m = m or InputMap.START
        return m
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (editing) return editTouch(e)
        val act = e.actionMasked
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            if (near(e.getX(i), e.getY(i), MENU, radius(MENU) * 1.6f)) { onMenu(); return true }
        }
        var m = 0
        if (act != MotionEvent.ACTION_CANCEL) {
            val skip = if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
            for (i in 0 until e.pointerCount) {
                if (i == skip) continue
                m = m or hit(e.getX(i), e.getY(i))
            }
        }
        if (m != input.touch) {
            input.touch = m
            invalidate()
        }
        return true
    }

    // ---------- edit mode ----------
    fun startEdit(done: () -> Unit) {
        editing = true
        selected = -1
        onEditDone = done
        input.touch = 0
        invalidate()
    }

    fun finishEdit() {
        if (!editing) return
        editing = false
        selected = -1
        saveLayout()
        invalidate()
        onEditDone?.invoke()
        onEditDone = null
    }

    private fun editHit(i: Int, x: Float, y: Float): Boolean = when (i) {
        DPAD -> near(x, y, i, radius(i) * 1.3f)
        SEL, STA -> pillRect(i, pillH(i) * 0.4f).contains(x, y)
        MENU -> near(x, y, i, radius(i) * 1.6f)
        else -> near(x, y, i, radius(i) * 1.4f)
    }

    private fun editTouch(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                for (k in 0 until 4) {
                    if (editRects[k].contains(x, y)) {
                        when (k) {
                            0 -> if (selected >= 0) fs[selected] = (fs[selected] * 0.9f).coerceAtLeast(0.5f)
                            1 -> if (selected >= 0) fs[selected] = (fs[selected] * 1.1f).coerceAtMost(2.2f)
                            2 -> { resetLayout(); selected = -1 }
                            3 -> { finishEdit(); return true }
                        }
                        invalidate()
                        return true
                    }
                }
                selected = -1
                for (i in N - 1 downTo 0) {
                    if (editHit(i, x, y)) {
                        selected = i
                        offX = x - cx(i)
                        offY = y - cy(i)
                        break
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (selected >= 0 && width > 0 && height > 0) {
                    fx[selected] = ((x - offX) / width).coerceIn(0.03f, 0.97f)
                    fy[selected] = ((y - offY) / height).coerceIn(0.03f, 0.97f)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> saveLayout()
        }
        return true
    }

    // ---------- drawing ----------
    private fun alpha(k: Float, lo: Int) = (drawOp * k).toInt().coerceIn(lo, 255)

    private fun lighten(rgb: Int): Int {
        val r = ((rgb shr 16) and 255) + (255 - ((rgb shr 16) and 255)) * 35 / 100
        val g = ((rgb shr 8) and 255) + (255 - ((rgb shr 8) and 255)) * 35 / 100
        val bl = (rgb and 255) + (255 - (rgb and 255)) * 35 / 100
        return (r shl 16) or (g shl 8) or bl
    }

    /** Fill and outline colours for a control of base colour [rgb], pressed or not. */
    private fun shade(on: Boolean, rgb: Int) {
        val th = theme()
        val c = if (on) lighten(rgb) else rgb
        fill.color = Color.argb(if (on) alpha(340f, 30) else alpha(150f * th.fillK, 0), (c shr 16) and 255, (c shr 8) and 255, c and 255)
        val sc = if (th.stroke >= 0) th.stroke else rgb
        stroke.color = Color.argb(alpha(300f, 20), (sc shr 16) and 255, (sc shr 8) and 255, sc and 255)
    }

    private fun ctlColor(i: Int): Int {
        val th = theme()
        return when (i) {
            BTN_A -> th.a
            BTN_B -> th.b
            TURBO_A -> th.ta
            else -> th.tb
        }
    }

    private fun drawCircleBtn(i: Int, on: Boolean, label: String) {
        val r = radius(i)
        shade(on, ctlColor(i))
        if (theme().square) {
            val rc = RectF(cx(i) - r, cy(i) - r, cx(i) + r, cy(i) + r)
            canvasRef.drawRoundRect(rc, r * 0.3f, r * 0.3f, fill)
            canvasRef.drawRoundRect(rc, r * 0.3f, r * 0.3f, stroke)
        } else {
            canvasRef.drawCircle(cx(i), cy(i), r, fill)
            canvasRef.drawCircle(cx(i), cy(i), r, stroke)
        }
        text.textSize = r * 0.8f
        canvasRef.drawText(label, cx(i), cy(i) + r * 0.28f, text)
    }

    private fun drawPill(i: Int, on: Boolean, label: String) {
        val rc = pillRect(i)
        val rr = rc.height() / 2
        shade(on, theme().pill)
        canvasRef.drawRoundRect(rc, rr, rr, fill)
        canvasRef.drawRoundRect(rc, rr, rr, stroke)
        text.textSize = rc.height() * 0.45f
        canvasRef.drawText(label, rc.centerX(), rc.centerY() + rc.height() * 0.16f, text)
    }

    private lateinit var canvasRef: Canvas

    override fun onDraw(c: Canvas) {
        canvasRef = c
        drawOp = if (editing && op < 0.6f) 0.6f else op
        val th = theme()
        stroke.strokeWidth = sz * 0.006f
        text.color = Color.argb(alpha(450f, 30), (th.text shr 16) and 255, (th.text shr 8) and 255, th.text and 255)
        hl.strokeWidth = sz * 0.01f

        val t = input.touch
        // D-pad
        val dr = radius(DPAD)
        val dcx = cx(DPAD)
        val dcy = cy(DPAD)
        shade(false, th.dpad)
        c.drawCircle(dcx, dcy, dr * 1.15f, fill)
        c.drawCircle(dcx, dcy, dr * 1.15f, stroke)
        val a = dr * 0.42f
        val l = dr
        shade((t and InputMap.UP) != 0, th.dpad);    c.drawRect(dcx - a, dcy - l, dcx + a, dcy - a * 0.2f, fill)
        shade((t and InputMap.DOWN) != 0, th.dpad);  c.drawRect(dcx - a, dcy + a * 0.2f, dcx + a, dcy + l, fill)
        shade((t and InputMap.LEFT) != 0, th.dpad);  c.drawRect(dcx - l, dcy - a, dcx - a * 0.2f, dcy + a, fill)
        shade((t and InputMap.RIGHT) != 0, th.dpad); c.drawRect(dcx + a * 0.2f, dcy - a, dcx + l, dcy + a, fill)

        drawCircleBtn(BTN_A, (t and InputMap.A) != 0, "A")
        drawCircleBtn(BTN_B, (t and InputMap.B) != 0, "B")
        drawCircleBtn(TURBO_A, (t and InputMap.TA) != 0, "TA")
        drawCircleBtn(TURBO_B, (t and InputMap.TB) != 0, "TB")
        drawPill(SEL, (t and InputMap.SELECT) != 0, "SELECT")
        drawPill(STA, (t and InputMap.START) != 0, "START")

        // menu button
        val mr = radius(MENU)
        shade(false, th.menu)
        c.drawCircle(cx(MENU), cy(MENU), mr, fill)
        c.drawCircle(cx(MENU), cy(MENU), mr, stroke)
        for (k in -1..1) {
            val yy = cy(MENU) + k * mr * 0.3f
            c.drawLine(cx(MENU) - mr * 0.45f, yy, cx(MENU) + mr * 0.45f, yy, stroke)
        }

        if (editing) {
            if (selected >= 0) {
                when (selected) {
                    DPAD -> c.drawCircle(dcx, dcy, dr * 1.2f, hl)
                    SEL, STA -> { val rc = pillRect(selected, sz * 0.012f); c.drawRoundRect(rc, rc.height() / 2, rc.height() / 2, hl) }
                    else -> c.drawCircle(cx(selected), cy(selected), radius(selected) * 1.12f, hl)
                }
            }
            for (k in 0 until 4) {
                fill.color = 0xDD202020.toInt()
                c.drawRoundRect(editRects[k], sz * 0.02f, sz * 0.02f, fill)
                stroke.color = 0xFFFFFFFF.toInt()
                c.drawRoundRect(editRects[k], sz * 0.02f, sz * 0.02f, stroke)
                text.color = 0xFFFFFFFF.toInt()
                text.textSize = sz * 0.04f
                c.drawText(EDIT_LABELS[k], editRects[k].centerX(), editRects[k].centerY() + sz * 0.014f, text)
            }
            text.textSize = sz * 0.035f
            c.drawText("Drag a button to move it. Tap it, then Smaller / Bigger.", width / 2f, editRects[0].bottom + sz * 0.07f, text)
        }
    }
}
