package com.nestv

abstract class Mapper(val rom: Rom) {
    var mirror = rom.mirror
    val prgRam = ByteArray(0x2000)

    open val irq: Boolean get() = false

    abstract fun cpuRead(a: Int): Int
    abstract fun cpuWrite(a: Int, v: Int)

    private val prgMask = rom.prg.size.let { if ((it and (it - 1)) == 0) it - 1 else -1 }
    private val chrMask = rom.chr.size.let { if ((it and (it - 1)) == 0) it - 1 else -1 }

    open fun chrOff(a: Int): Int = a
    fun ppuRead(a: Int): Int {
        val o = chrOff(a)
        return rom.chr[if (chrMask >= 0) o and chrMask else o % rom.chr.size].toInt() and 0xFF
    }
    fun ppuWrite(a: Int, v: Int) {
        if (rom.chrRam) {
            val o = chrOff(a)
            rom.chr[if (chrMask >= 0) o and chrMask else o % rom.chr.size] = v.toByte()
        }
    }

    open fun debugInfo(): String = ""
    open fun cpuClock(n: Int) {}
    open fun scanline() {}

    open fun saveData(): ByteArray? = if (rom.battery) prgRam.copyOf() else null
    open fun loadData(b: ByteArray) {
        if (rom.battery && b.size == prgRam.size) b.copyInto(prgRam)
    }

    protected fun prg(off: Int): Int = rom.prg[if (prgMask >= 0) off and prgMask else off % rom.prg.size].toInt() and 0xFF
    protected fun ramRead(a: Int): Int = prgRam[a - 0x6000].toInt() and 0xFF
    protected fun ramWrite(a: Int, v: Int) { prgRam[a - 0x6000] = v.toByte() }
}

class Nrom(r: Rom) : Mapper(r) {
    override fun cpuRead(a: Int) = when {
        a >= 0x8000 -> prg(a - 0x8000)
        a >= 0x6000 -> ramRead(a)
        else -> 0
    }
    override fun cpuWrite(a: Int, v: Int) { if (a in 0x6000..0x7FFF) ramWrite(a, v) }
}

class Mmc1(r: Rom) : Mapper(r) {
    private var sr = 0x10
    private var ctrl = 0x0C
    private var c0 = 0
    private var c1 = 0
    private var pb = 0

    init { updateMirror() }

    private fun updateMirror() {
        mirror = when (ctrl and 3) { 0 -> 2; 1 -> 3; 2 -> 0; else -> 1 }
    }

    private fun prgOff(a: Int): Int {
        val b = pb and 0x0F
        return when ((ctrl shr 2) and 3) {
            0, 1 -> (b and 0xE) * 0x4000 + (a - 0x8000)
            2 -> if (a < 0xC000) a - 0x8000 else b * 0x4000 + (a - 0xC000)
            else -> if (a < 0xC000) b * 0x4000 + (a - 0x8000) else rom.prg.size - 0x4000 + (a - 0xC000)
        }
    }

    override fun cpuRead(a: Int) = when {
        a >= 0x8000 -> prg(prgOff(a))
        a >= 0x6000 -> ramRead(a)
        else -> 0
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x6000..0x7FFF) { ramWrite(a, v); return }
        if (a < 0x8000) return
        if ((v and 0x80) != 0) {
            sr = 0x10
            ctrl = ctrl or 0x0C
            updateMirror()
            return
        }
        val full = (sr and 1) == 1
        sr = (sr shr 1) or ((v and 1) shl 4)
        if (full) {
            when ((a shr 13) and 3) {
                0 -> { ctrl = sr; updateMirror() }
                1 -> c0 = sr
                2 -> c1 = sr
                else -> pb = sr
            }
            sr = 0x10
        }
    }

    override fun chrOff(a: Int): Int =
        if (((ctrl shr 4) and 1) == 0) (c0 and 0x1E) * 0x1000 + a
        else if (a < 0x1000) c0 * 0x1000 + a
        else c1 * 0x1000 + (a - 0x1000)
}

class Uxrom(r: Rom) : Mapper(r) {
    private var bank = 0
    override fun cpuRead(a: Int) = when {
        a >= 0xC000 -> prg(rom.prg.size - 0x4000 + (a - 0xC000))
        a >= 0x8000 -> prg(bank * 0x4000 + (a - 0x8000))
        a >= 0x6000 -> ramRead(a)
        else -> 0
    }
    override fun cpuWrite(a: Int, v: Int) {
        if (a >= 0x8000) bank = v and 0xFF else if (a >= 0x6000) ramWrite(a, v)
    }
}

class Cnrom(r: Rom) : Mapper(r) {
    private var bank = 0
    override fun cpuRead(a: Int) = when {
        a >= 0x8000 -> prg(a - 0x8000)
        a >= 0x6000 -> ramRead(a)
        else -> 0
    }
    override fun cpuWrite(a: Int, v: Int) {
        if (a >= 0x8000) bank = v and 0xFF else if (a >= 0x6000) ramWrite(a, v)
    }
    override fun chrOff(a: Int) = bank * 0x2000 + a
}

class Axrom(r: Rom) : Mapper(r) {
    private var bank = 0
    init { mirror = 2 }
    override fun cpuRead(a: Int) = if (a >= 0x8000) prg(bank * 0x8000 + (a - 0x8000)) else if (a >= 0x6000) ramRead(a) else 0
    override fun cpuWrite(a: Int, v: Int) {
        if (a >= 0x8000) {
            bank = v and 0x0F
            mirror = if ((v and 0x10) != 0) 3 else 2
        } else if (a >= 0x6000) ramWrite(a, v)
    }
}

class Gxrom(r: Rom) : Mapper(r) {
    private var pb = 0
    private var cb = 0
    override fun cpuRead(a: Int) = if (a >= 0x8000) prg(pb * 0x8000 + (a - 0x8000)) else 0
    override fun cpuWrite(a: Int, v: Int) {
        if (a >= 0x8000) { pb = (v shr 4) and 3; cb = v and 3 }
    }
    override fun chrOff(a: Int) = cb * 0x2000 + a
}

class Mmc3(r: Rom) : Mapper(r) {
    private val reg = IntArray(8)
    private var sel = 0
    private var latch = 0
    private var counter = 0
    private var reload = false
    private var irqEn = false
    private var irqFlag = false

    init { reg[7] = 1 }

    override val irq: Boolean get() = irqFlag

    private fun prgBank(slot: Int): Int {
        val n = rom.prg.size / 0x2000
        val m = (sel shr 6) and 1
        return when (slot) {
            0 -> if (m == 0) reg[6] else n - 2
            1 -> reg[7]
            2 -> if (m == 0) n - 2 else reg[6]
            else -> n - 1
        }
    }

    override fun cpuRead(a: Int) = when {
        a >= 0x8000 -> prg(prgBank((a - 0x8000) shr 13) * 0x2000 + (a and 0x1FFF))
        a >= 0x6000 -> ramRead(a)
        else -> 0
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x6000..0x7FFF) { ramWrite(a, v); return }
        if (a < 0x8000) return
        val even = (a and 1) == 0
        when (a and 0xE000) {
            0x8000 -> if (even) sel = v else reg[sel and 7] = v
            0xA000 -> if (even) mirror = if ((v and 1) == 0) 0 else 1
            0xC000 -> if (even) latch = v else { counter = 0; reload = true }
            else -> if (even) { irqEn = false; irqFlag = false } else irqEn = true
        }
    }

    override fun chrOff(a: Int): Int {
        var s = a shr 10
        if (((sel shr 7) and 1) == 1) s = s xor 4
        val bank = when (s) {
            0 -> reg[0] and 0xFE
            1 -> reg[0] or 1
            2 -> reg[1] and 0xFE
            3 -> reg[1] or 1
            else -> reg[s - 2]
        }
        return bank * 0x400 + (a and 0x3FF)
    }

    override fun scanline() {
        if (counter == 0 || reload) { counter = latch; reload = false } else counter--
        if (counter == 0 && irqEn) irqFlag = true
    }
}

/**
 * Bandai FCG-1/2 + LZ93D50 (iNES mapper 16, 159). Registers are decoded at both $6000-$7FFF and $8000-$FFFF.
 * Mapper 16 carries a 24C02 EEPROM, mapper 159 a 24C01. The EEPROM contents are what gets saved.
 */
class Bandai(r: Rom, id: Int) : Mapper(r) {
    private val chrReg = IntArray(8)
    private var prgBank = 0
    private var irqEn = false
    private var cnt = 0
    private var latch = 0
    private var line = false
    private var irqFired = 0
    private val eeprom: Eeprom? = when {
        id == 159 -> Eeprom(1)
        r.submapper == 4 -> null
        r.submapper == 5 -> Eeprom(2)
        else -> Eeprom(0)
    }

    override val irq: Boolean get() = line

    override fun cpuRead(a: Int): Int = when {
        a >= 0x8000 -> if (a < 0xC000) prg((prgBank and 0x0F) * 0x4000 + (a - 0x8000))
                       else prg(rom.prg.size - 0x4000 + (a - 0xC000))
        a >= 0x6000 -> (eeprom?.read() ?: 0) shl 4
        else -> 0
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a < 0x6000) return
        val lz = a >= 0x8000
        when (a and 0x0F) {
            in 0..7 -> chrReg[a and 7] = v and 0xFF
            8 -> prgBank = v and 0x0F
            9 -> mirror = v and 3
            0xA -> { irqEn = (v and 1) != 0; line = false; if (lz) cnt = latch }
            0xB -> if (lz) latch = (latch and 0xFF00) or v else cnt = (cnt and 0xFF00) or v
            0xC -> if (lz) latch = (latch and 0x00FF) or (v shl 8) else cnt = (cnt and 0x00FF) or (v shl 8)
            0xD -> eeprom?.write((v shr 5) and 1, (v shr 6) and 1)
        }
    }

    override fun chrOff(a: Int) = chrReg[a shr 10] * 0x400 + (a and 0x3FF)

    override fun cpuClock(n: Int) {
        if (!irqEn) return
        if (cnt < n) { line = true; irqFired++ }
        cnt = (cnt - n) and 0xFFFF
    }

    override fun debugInfo(): String {
        val e = eeprom
        val ee = if (e == null) "EEPROM: none" else
            "EEPROM: ${e.typeName}, starts=${e.starts}, bytes written=${e.bytesWritten}, read=${e.bytesRead}, rejected=${e.rejected}"
        return ee + "\nIRQ: enabled=$irqEn, counter=$cnt, fired=$irqFired\nPRG bank=$prgBank, mirror=$mirror"
    }

    override fun saveData(): ByteArray? = eeprom?.mem?.copyOf()
    override fun loadData(b: ByteArray) {
        val e = eeprom ?: return
        if (b.size == e.mem.size) b.copyInto(e.mem)
    }
}

fun createMapper(rom: Rom): Mapper = when (rom.mapperId) {
    0 -> Nrom(rom)
    1 -> Mmc1(rom)
    2 -> Uxrom(rom)
    3 -> Cnrom(rom)
    4 -> Mmc3(rom)
    7 -> Axrom(rom)
    16, 159 -> Bandai(rom, rom.mapperId)
    66 -> Gxrom(rom)
    else -> throw IllegalArgumentException("Unsupported mapper ${rom.mapperId}")
}
