package com.nestv

import java.util.Arrays

/** Dot-stepped PPU that renders one scanline at a time (sprite 0 hit is timed to its dot). */
class Ppu(private val m: Mapper) {
    val fb = IntArray(256 * 240)
    private val vram = IntArray(0x800)
    private val pal = IntArray(32)
    private val oam = IntArray(256)

    private var ctrl = 0
    private var mask = 0
    private var status = 0
    private var oamAddr = 0
    private var v = 0
    private var t = 0
    private var fx = 0
    private var w = 0
    private var readBuf = 0
    private var dot = 0
    private var scan = 0
    private var hitDot = -1

    fun debug() = "ctrl=%02X mask=%02X".format(ctrl, mask)

    var nmi = false
    var frameReady = false

    private val bg = IntArray(256)
    private val sp = IntArray(256)
    private val spFlag = IntArray(256)
    private var spCount = 0
    private var spZero = false
    private var lineActive = false
    private var lineY = 0
    private var tilesDone = 0
    private var pixDone = 0

    // ---- memory ----
    private fun ntIndex(a: Int): Int {
        val n = (a shr 10) and 3
        val page = when (m.mirror) { 0 -> n and 1; 1 -> n shr 1; 2 -> 0; else -> 1 }
        return (page shl 10) or (a and 0x3FF)
    }

    private fun palIdx(a: Int): Int {
        var i = a and 0x1F
        if ((i and 0x13) == 0x10) i -= 0x10
        return i
    }

    private fun read(a0: Int): Int {
        val a = a0 and 0x3FFF
        return when {
            a < 0x2000 -> m.ppuRead(a)
            a < 0x3F00 -> vram[ntIndex(a)]
            else -> pal[palIdx(a)]
        }
    }

    private fun write(a0: Int, d: Int) {
        val a = a0 and 0x3FFF
        when {
            a < 0x2000 -> m.ppuWrite(a, d)
            a < 0x3F00 -> vram[ntIndex(a)] = d
            else -> { pal[palIdx(a)] = d and 0x3F; pcValid = false }
        }
    }

    // ---- registers ----
    fun readReg(r: Int): Int {
        if (r == 7) sync()
        when (r) {
            2 -> {
                val s = status
                status = status and 0x7F
                w = 0
                return (s and 0xE0) or (readBuf and 0x1F)
            }
            4 -> return oam[oamAddr]
            7 -> {
                val a = v and 0x3FFF
                val res: Int
                if (a >= 0x3F00) {
                    res = pal[palIdx(a)]
                    readBuf = vram[ntIndex(a)]
                } else {
                    res = readBuf
                    readBuf = read(a)
                }
                v = (v + (if ((ctrl and 4) != 0) 32 else 1)) and 0x7FFF
                return res
            }
        }
        return 0
    }

    fun writeReg(r: Int, d: Int) {
        if (r == 0 || r == 1 || r >= 5) sync()
        when (r) {
            0 -> {
                val was = ctrl and 0x80
                ctrl = d
                t = (t and 0x73FF) or ((d and 3) shl 10)
                if (was == 0 && (d and 0x80) != 0 && (status and 0x80) != 0) nmi = true
            }
            1 -> { mask = d; pcValid = false }
            3 -> oamAddr = d
            4 -> { oam[oamAddr] = d; oamAddr = (oamAddr + 1) and 0xFF }
            5 -> if (w == 0) {
                fx = d and 7
                t = (t and 0x7FE0) or (d shr 3)
                w = 1
            } else {
                t = (t and 0x0C1F) or ((d and 7) shl 12) or ((d and 0xF8) shl 2)
                w = 0
            }
            6 -> if (w == 0) {
                t = (t and 0x00FF) or ((d and 0x3F) shl 8)
                w = 1
            } else {
                t = (t and 0x7F00) or d
                v = t
                w = 0
            }
            7 -> {
                write(v and 0x3FFF, d)
                v = (v + (if ((ctrl and 4) != 0) 32 else 1)) and 0x7FFF
            }
        }
    }

    fun save(sw: SW) {
        sw.ints(vram); sw.ints(pal); sw.ints(oam)
        sw.int(ctrl); sw.int(mask); sw.int(status); sw.int(oamAddr)
        sw.int(v); sw.int(t); sw.int(fx); sw.int(w); sw.int(readBuf)
        sw.int(dot); sw.int(scan); sw.int(hitDot); sw.bool(nmi)
    }

    fun load(r: SR) {
        r.ints(vram); r.ints(pal); r.ints(oam)
        ctrl = r.int(); mask = r.int(); status = r.int(); oamAddr = r.int()
        v = r.int(); t = r.int(); fx = r.int(); w = r.int(); readBuf = r.int()
        dot = r.int(); scan = r.int(); hitDot = r.int(); nmi = r.bool()
        frameReady = false
        lineActive = false
        tilesDone = 0
        pixDone = 0
        spCount = 0
        spZero = false
        pcValid = false
        Arrays.fill(sp, 0)
        Arrays.fill(spFlag, 0)
        computeStop()
    }

    fun dmaWrite(d: Int) {
        oam[oamAddr] = d
        oamAddr = (oamAddr + 1) and 0xFF
    }

    // ---- timing ----
    private val stops = intArrayOf(1, 257, 260, 280, 290)
    private var stopAt = 1

    private fun computeStop() {
        var t = 341
        for (e in stops) if (e > dot && e < t) t = e
        if (hitDot > dot && hitDot < t) t = hitDot
        stopAt = t
    }

    fun step(n: Int) {
        var left = n
        while (left > 0) {
            val room = stopAt - dot
            if (left < room) {
                dot += left
                return
            }
            dot += room
            left -= room
            if (stopAt == 341) {
                dot = 0
                scan++
                if (scan == 262) scan = 0
            } else event()
            computeStop()
        }
    }

    private fun event() {
        val rendering = (mask and 0x18) != 0
        if (scan < 240) {
            when (dot) {
                1 -> beginLine(scan)
                257 -> { finishLine(); if (rendering) { incY(); copyH() } }
                260 -> if (rendering) m.scanline()
                290 -> if (scan < 239) prepareSprites(scan + 1)
            }
            if (dot == hitDot) status = status or 0x40
        } else if (scan == 241) {
            if (dot == 1) {
                status = status or 0x80
                if ((ctrl and 0x80) != 0) nmi = true
                frameReady = true
            }
        } else if (scan == 261) {
            when (dot) {
                1 -> { status = status and 0x1F; hitDot = -1 }
                257 -> if (rendering) copyH()
                260 -> if (rendering) m.scanline()
                280 -> if (rendering) copyV()
                290 -> prepareSprites(0)
            }
        }
    }

    private fun incY() {
        if ((v and 0x7000) != 0x7000) {
            v += 0x1000
        } else {
            v = v and 0x7000.inv()
            var cy = (v and 0x03E0) shr 5
            if (cy == 29) { cy = 0; v = v xor 0x0800 } else if (cy == 31) cy = 0 else cy++
            v = (v and 0x03E0.inv()) or (cy shl 5)
        }
    }

    private fun copyH() { v = (v and 0x041F.inv()) or (t and 0x041F) }
    private fun copyV() { v = (v and 0x7BE0.inv()) or (t and 0x7BE0) }

    // ---- rendering ----
    // A visible line is drawn in pieces. Background tiles are fetched (and the scroll counter v advanced) at the
    // time the real PPU would fetch them, and pixels are coloured when they would be output, so register
    // or cartridge writes made part-way along a line (bank switches, scroll, palette) land on the right tile.
    private val pc = IntArray(32)
    private var pcValid = false

    /** Number of background tiles the PPU has fetched by dot d of a visible line. */
    private fun tilesFetchedAt(d: Int): Int = if (d < 5) 2 else minOf(33, (d - 5) / 8 + 3)

    /** Bring the picture up to date with the current dot. Call before anything that changes how it is drawn. */
    fun sync() {
        if (!lineActive || dot >= 257) return
        fetchTiles(tilesFetchedAt(dot))
        if (dot > 1) compose(dot - 1)
    }

    private fun beginLine(y: Int) {
        lineActive = true
        lineY = y
        tilesDone = 0
        pixDone = 0
        hitDot = -1
        Arrays.fill(bg, 0)
        if (spZero) predictHit()
        fetchTiles(2)
    }

    private fun finishLine() {
        if (!lineActive) return
        fetchTiles(33)
        compose(256)
        lineActive = false
    }

    private fun fetchTiles(upTo: Int) {
        val target = if (upTo > 33) 33 else upTo
        if ((mask and 0x18) == 0) {
            if (tilesDone < target) tilesDone = target
            return
        }
        while (tilesDone < target) {
            val vv = v
            val fy = (vv shr 12) and 7
            val nt = vram[ntIndex(0x2000 or (vv and 0x0FFF))]
            val at = vram[ntIndex(0x23C0 or (vv and 0x0C00) or ((vv shr 4) and 0x38) or ((vv shr 2) and 7))]
            val ps = ((at shr (((vv shr 4) and 4) or (vv and 2))) and 3) shl 2
            val base = (if ((ctrl and 0x10) != 0) 0x1000 else 0) + nt * 16 + fy
            val lo = m.ppuRead(base)
            val hi = m.ppuRead(base + 8)
            val px = tilesDone * 8 - fx
            if (px >= 0 && px <= 248) {
                for (b in 0..7) {
                    val sh = 7 - b
                    val c = ((lo shr sh) and 1) or (((hi shr sh) and 1) shl 1)
                    bg[px + b] = if (c != 0) ps or c else 0
                }
            } else {
                for (b in 0..7) {
                    val x = px + b
                    if (x in 0..255) {
                        val sh = 7 - b
                        val c = ((lo shr sh) and 1) or (((hi shr sh) and 1) shl 1)
                        bg[x] = if (c != 0) ps or c else 0
                    }
                }
            }
            v = if ((vv and 0x1F) == 31) (vv and 0x1F.inv()) xor 0x400 else vv + 1
            tilesDone++
        }
    }

    /** Colour pixels pixDone until xEnd using the palette and mask as they are right now. */
    private fun compose(xEnd: Int) {
        val x0 = pixDone
        if (xEnd <= x0) return
        fetchTiles((xEnd - 1 + fx) / 8 + 1)
        if (!pcValid) {
            val gray = if ((mask and 1) != 0) 0x30 else 0x3F
            for (i in 0 until 32) pc[i] = COLORS[pal[i] and gray]
            pcValid = true
        }
        val o = lineY * 256
        val showBg = (mask and 8) != 0
        val showSp = (mask and 0x10) != 0 && spCount > 0
        if ((mask and 0x18) == 0) {
            Arrays.fill(fb, o + x0, o + xEnd, pc[0])
        } else if (!showSp && showBg) {
            var x = x0
            if ((mask and 2) == 0) while (x < xEnd && x < 8) { fb[o + x] = pc[0]; x++ }
            while (x < xEnd) { fb[o + x] = pc[bg[x]]; x++ }
        } else {
            val bgClip = (mask and 2) == 0
            val spClip = (mask and 4) == 0
            for (x in x0 until xEnd) {
                val b = if (showBg && !(x < 8 && bgClip)) bg[x] else 0
                val s = if (showSp && !(x < 8 && spClip)) sp[x] else 0
                fb[o + x] = if (s == 0) pc[b]
                else if (b == 0) pc[s]
                else if ((spFlag[x] and 1) != 0) pc[b] else pc[s]
            }
        }
        pixDone = xEnd
    }

    /** Evaluate sprites for line y (the real PPU does this during the previous line). */
    private fun prepareSprites(y: Int) {
        Arrays.fill(sp, 0)
        Arrays.fill(spFlag, 0)
        spCount = 0
        spZero = false
        if ((mask and 0x18) == 0) return
        val h = if ((ctrl and 0x20) != 0) 16 else 8
        for (i in 0 until 64) {
            val row = y - (oam[i * 4] + 1)
            if (row < 0 || row >= h) continue
            if (spCount == 8) { status = status or 0x20; break }
            spCount++
            if (i == 0) spZero = true
            val tile = oam[i * 4 + 1]
            val attr = oam[i * 4 + 2]
            val ox = oam[i * 4 + 3]
            var r = if ((attr and 0x80) != 0) h - 1 - row else row
            val addr: Int
            if (h == 8) {
                addr = (if ((ctrl and 8) != 0) 0x1000 else 0) + tile * 16 + r
            } else {
                val bs = ((tile and 1) shl 12) + (tile and 0xFE) * 16
                if (r >= 8) { r -= 8; addr = bs + 16 + r } else addr = bs + r
            }
            val lo = m.ppuRead(addr)
            val hi = m.ppuRead(addr + 8)
            val pa = 0x10 or ((attr and 3) shl 2)
            val flipH = (attr and 0x40) != 0
            for (b in 0..7) {
                val x = ox + b
                if (x > 255) break
                val bit = if (flipH) b else 7 - b
                val c = ((lo shr bit) and 1) or (((hi shr bit) and 1) shl 1)
                if (c != 0 && sp[x] == 0) {
                    sp[x] = pa or c
                    spFlag[x] = (if ((attr and 0x20) != 0) 1 else 0) or (if (i == 0) 2 else 0)
                }
            }
        }
    }

    /** Work out where sprite 0 will hit the background on this line, so $2002 reads see it at the right dot. */
    private fun predictHit() {
        if ((mask and 0x18) != 0x18) return
        for (x in 0..254) {
            if ((spFlag[x] and 2) == 0) continue
            if (x < 8 && (mask and 6) != 6) continue
            if (bgOpaqueAt(x)) { hitDot = x + 2; return }
        }
    }

    private fun bgOpaqueAt(x: Int): Boolean {
        val fxp = x + fx
        val k = fxp shr 3
        val nx = (v and 0x1F) + k
        var vv = (v and 0x1F.inv()) or (nx and 0x1F)
        if (((nx shr 5) and 1) != 0) vv = vv xor 0x400
        val fy = (vv shr 12) and 7
        val nt = vram[ntIndex(0x2000 or (vv and 0x0FFF))]
        val base = (if ((ctrl and 0x10) != 0) 0x1000 else 0) + nt * 16 + fy
        val bit = 7 - (fxp and 7)
        val c = ((m.ppuRead(base) shr bit) and 1) or (((m.ppuRead(base + 8) shr bit) and 1) shl 1)
        return c != 0
    }

    companion object {
        val COLORS = intArrayOf(
            0x666666, 0x002A88, 0x1412A7, 0x3B00A4, 0x5C007E, 0x6E0040, 0x6C0600, 0x561D00,
            0x333500, 0x0B4800, 0x005200, 0x004F08, 0x00404D, 0x000000, 0x000000, 0x000000,
            0xADADAD, 0x155FD9, 0x4240FF, 0x7527FE, 0xA01ACC, 0xB71E7B, 0xB53120, 0x994E00,
            0x6B6D00, 0x388700, 0x0D9300, 0x008F32, 0x007C8D, 0x000000, 0x000000, 0x000000,
            0xFFFEFF, 0x64B0FF, 0x9290FF, 0xC676FF, 0xF36AFF, 0xFE6ECC, 0xFE8170, 0xEA9E22,
            0xBCBE00, 0x88D800, 0x5CE430, 0x45E082, 0x48CDDE, 0x4F4F4F, 0x000000, 0x000000,
            0xFFFEFF, 0xC0DFFF, 0xD3D2FF, 0xE8C8FF, 0xFBC2FF, 0xFEC4EA, 0xFECCC5, 0xF7D8A5,
            0xE4E594, 0xCFEF96, 0xBDF4AB, 0xB3F3CC, 0xB5EBF2, 0xB8B8B8, 0x000000, 0x000000
        ).map { it or (0xFF shl 24) }.toIntArray()
    }
}
