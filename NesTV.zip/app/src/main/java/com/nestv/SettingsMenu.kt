package com.nestv

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.view.Gravity
import android.view.KeyEvent
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/**
 * Settings that can be changed before a game is started (the same ones the in-game pause menu offers, except
 * moving the touch buttons, which needs the game screen). Everything is stored in the app's preferences and picked
 * up when a game starts.
 */
class SettingsMenu(private val act: Activity) {
    private val prefs = act.getSharedPreferences("nestv", Context.MODE_PRIVATE)
    private val gfx = GfxSettings(prefs, GfxParams())
    private val input = InputMap(act)
    private val isTv = act.packageManager.hasSystemFeature("android.software.leanback") ||
        act.packageManager.hasSystemFeature("android.hardware.type.television")

    fun show() = showMain()

    private fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_SHORT).show()

    // ---------- main ----------
    private fun showMain() {
        SettingsPanel(act, gfx, false, { showRemap() }, null, {}, {}).show()
    }

    private fun showOpacity() {
        val start = prefs.getInt("touch_alpha", 45)
        val label = TextView(act).apply { text = "$start%"; textSize = 22f; gravity = Gravity.CENTER; setPadding(0, 24, 0, 8) }
        val bar = SeekBar(act).apply { max = 90; progress = start - 10; setPadding(48, 24, 48, 24) }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { label.text = "${p + 10}%" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; addView(label); addView(bar) }
        AlertDialog.Builder(act)
            .setTitle("Touch button opacity")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> prefs.edit().putInt("touch_alpha", bar.progress + 10).apply() }
            .setNegativeButton("Cancel", null)
            .setOnDismissListener { showMain() }
            .show()
    }

    // ---------- graphics ----------
    private fun showGraphics() {
        val g = gfx
        val skip = prefs.getInt("frameskip", 1)
        val accurate = prefs.getBoolean("accurate", true)
        val irq = prefs.getInt("irq_offset", 0)
        val items = arrayOf(
            "Picture style: " + g.presetName() + "...",
            "Fine-tune effects...",
            "Aspect ratio: " + GfxPresets.ASPECTS[g.aspect],
            "Show FPS counter: " + (if (g.showFps) "ON" else "OFF"),
            "Frame skip: " + arrayOf("Off", "Auto (when slow)", "Every 2nd frame", "2 of every 3 frames")[skip],
            "Accurate mid-line drawing: " + (if (accurate) "ON" else "OFF"),
            "Split-screen timing: " + (if (irq > 0) "+" else "") + irq + " cycles...",
            "Back"
        )
        AlertDialog.Builder(act)
            .setTitle("Graphics")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showStyles()
                    1 -> showTune()
                    2 -> { g.aspect = (g.aspect + 1) % GfxPresets.ASPECTS.size; g.commit(); showGraphics() }
                    3 -> { g.showFps = !g.showFps; g.commit(); showGraphics() }
                    4 -> { prefs.edit().putInt("frameskip", (skip + 1) % 4).apply(); showGraphics() }
                    5 -> { prefs.edit().putBoolean("accurate", !accurate).apply(); showGraphics() }
                    6 -> showIrq()
                    else -> showMain()
                }
            }
            .setOnCancelListener { showMain() }
            .show()
    }

    private fun showStyles() {
        val g = gfx
        AlertDialog.Builder(act)
            .setTitle("Picture style")
            .setSingleChoiceItems(GfxPresets.NAMES, if (g.preset in GfxPresets.NAMES.indices) g.preset else -1) { d, which ->
                g.applyPreset(which)
                d.dismiss()
            }
            .setOnDismissListener { showGraphics() }
            .show()
    }

    private fun showTune() {
        val g = gfx
        val snap = g.snapshot()
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 10) }
        fun row(title: String, value: Int, set: (Int) -> Unit) {
            val label = TextView(act).apply { text = "$title: $value%"; textSize = 16f; setPadding(0, 16, 0, 0) }
            val bar = SeekBar(act).apply { max = 100; progress = value; keyProgressIncrement = 5 }
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = "$title: $p%"
                    set(p)
                    g.preview()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            box.addView(label)
            box.addView(bar)
        }
        row("Scanlines", g.scan) { g.scan = it }
        row("Phosphor mask", g.mask) { g.mask = it }
        row("Screen curve", g.curve) { g.curve = it }
        row("Blur (composite TV)", g.blur) { g.blur = it }
        row("Vignette (dark corners)", g.vig) { g.vig = it }
        val sharp = CheckBox(act).apply { text = "Sharp pixel scaling"; isChecked = g.sharp == 1 }
        sharp.setOnCheckedChangeListener { _, c -> g.sharp = if (c) 1 else 0; g.preview() }
        box.addView(sharp)
        AlertDialog.Builder(act)
            .setTitle("Fine-tune effects")
            .setView(ScrollView(act).apply { addView(box) })
            .setPositiveButton("OK") { _, _ -> g.commit() }
            .setNegativeButton("Cancel") { _, _ -> g.restore(snap) }
            .setOnCancelListener { g.restore(snap) }
            .setOnDismissListener { showGraphics() }
            .show()
    }

    private fun showIrq() {
        val start = prefs.getInt("irq_offset", 0)
        fun lab(v: Int) = "Split-screen timing: " + (if (v > 0) "+" else "") + v + " cycles"
        val label = TextView(act).apply { text = lab(start); textSize = 18f; gravity = Gravity.CENTER; setPadding(0, 24, 0, 8) }
        val note = TextView(act).apply {
            text = "For games that change the screen part-way down. Use this if lines flicker or tiles go missing where the screen splits. " +
                "Left = earlier, right = later. (It can also be changed live from the in-game menu.)"
            textSize = 13f
            setPadding(40, 0, 40, 0)
        }
        val bar = SeekBar(act).apply { max = 200; progress = start + 100; setPadding(48, 24, 48, 24) }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { label.text = lab(p - 100) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; addView(label); addView(bar); addView(note) }
        AlertDialog.Builder(act)
            .setTitle("Split-screen timing")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> prefs.edit().putInt("irq_offset", bar.progress - 100).apply() }
            .setNeutralButton("Reset") { _, _ -> prefs.edit().putInt("irq_offset", 0).apply() }
            .setNegativeButton("Cancel", null)
            .setOnDismissListener { showGraphics() }
            .show()
    }

    // ---------- remapping ----------
    private fun showRemap() {
        val count = InputMap.NAMES.size
        val items = ArrayList<String>()
        items.add("Guided setup (all NES buttons in order)")
        for (i in 0 until count) items.add(InputMap.NAMES[i] + ":   " + input.labelFor(InputMap.WIZARD_BITS[i]))
        items.add("Combo buttons (A+B, Right+B ...)...")
        items.add("Hold buttons (stay pressed until pressed again)...")
        items.add("Key release delay: " + (if (input.releaseMs == 0) "off" else "${input.releaseMs} ms"))
        items.add("Rollover assist (covers keys the remote drops): " + arrayOf("Off", "Normal", "Wide")[input.assistLevel])
        items.add("Left/Right keys toggle (tap to walk, tap again to stop): " + (if (input.toggleDirs) "ON" else "OFF"))
        items.add("Input test (how many keys does the remote send?)...")
        items.add("Reset all to defaults")
        items.add("Back")
        AlertDialog.Builder(act)
            .setTitle("Remap buttons")
            .setItems(items.toTypedArray()) { _, c ->
                when {
                    c == 0 -> guided(0)
                    c in 1..count -> capture(InputMap.WIZARD_BITS[c - 1], InputMap.NAMES[c - 1], { showRemap() }, { showRemap() })
                    c == count + 1 -> showBitList("Combo buttons", InputMap.COMBO_NAMES, InputMap.COMBO_BITS)
                    c == count + 2 -> showBitList("Hold buttons", InputMap.LATCH_NAMES, InputMap.LATCH_BITS)
                    c == count + 3 -> {
                        input.setRelease(when (input.releaseMs) { 0 -> 30; 30 -> 60; 60 -> 100; else -> 0 })
                        showRemap()
                    }
                    c == count + 4 -> { input.cycleAssist(); showRemap() }
                    c == count + 5 -> { input.changeToggleDirs(!input.toggleDirs); showRemap() }
                    c == count + 6 -> showInputTest()
                    c == count + 7 -> { input.reset(); toast("Controls reset to defaults"); showRemap() }
                    else -> showMain()
                }
            }
            .setOnCancelListener { showMain() }
            .show()
    }

    private fun guided(i: Int) {
        if (i >= InputMap.GUIDED) { toast("Controls saved"); showRemap(); return }
        capture(InputMap.WIZARD_BITS[i], InputMap.NAMES[i] + "   (" + (i + 1) + " of " + InputMap.GUIDED + ")", { guided(i + 1) }, { showRemap() })
    }

    private fun showBitList(title: String, names: Array<String>, bits: IntArray) {
        val items = Array(names.size) { i -> names[i] + ":   " + input.labelFor(bits[i]) }
        AlertDialog.Builder(act)
            .setTitle(title)
            .setItems(items) { _, c -> capture(bits[c], names[c], { showBitList(title, names, bits) }, { showBitList(title, names, bits) }) }
            .setOnCancelListener { showRemap() }
            .show()
    }

    /** Waits for one key press and binds it to [bit]. Back cancels. */
    private fun capture(bit: Int, name: String, then: () -> Unit, cancel: () -> Unit) {
        var done = false
        val dlg = AlertDialog.Builder(act)
            .setTitle("Press a key")
            .setMessage("Press the key (or gamepad button) to use for\n\n$name\n\nnow: " + input.labelFor(bit) + "\n\nBack = cancel")
            .setOnCancelListener { if (!done) cancel() }
            .create()
        dlg.setOnKeyListener { d, code, ev ->
            if (code == KeyEvent.KEYCODE_BACK) {
                false
            } else {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0 && !done) {
                    done = true
                    val map = input.custom()
                    map.entries.removeAll { it.value == bit || it.key == code }
                    map[code] = bit
                    input.save(map)
                    d.dismiss()
                    then()
                }
                true
            }
        }
        dlg.show()
    }

    private fun showInputTest() {
        val down = LinkedHashSet<Int>()
        val log = ArrayList<String>()
        val worked = LinkedHashSet<String>()
        val dropped = LinkedHashSet<String>()
        var t0 = -1L
        var most = 0
        var lastUpName = ""
        var lastUpAt = -1000L
        var lastDownName = ""
        var lastDownAt = -1000L
        val tv = TextView(act).apply { textSize = 15f; setPadding(48, 24, 48, 16) }
        fun nm(code: Int) = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
        fun refresh() {
            tv.text = "Hold several remote buttons together. Back closes this.\n\n" +
                "Keys down now (" + down.size + "): " + (if (down.isEmpty()) "-" else down.joinToString(", ") { nm(it) }) +
                "\nMost at the same time: " + most +
                "\n\nGroups of 3 or more that worked together:\n" + (if (worked.isEmpty()) "-" else worked.joinToString("\n")) +
                "\n\nKeys the remote dropped when another key went down:\n" + (if (dropped.isEmpty()) "-" else dropped.joinToString("\n")) +
                "\n\nLast events (newest first):\n" + (if (log.isEmpty()) "-" else log.joinToString("\n"))
        }
        refresh()
        val dlg = AlertDialog.Builder(act)
            .setTitle("Input test")
            .setView(ScrollView(act).apply { addView(tv) })
            .setOnDismissListener { showRemap() }
            .create()
        dlg.setOnKeyListener { _, code, ev ->
            if (code == KeyEvent.KEYCODE_BACK) {
                false
            } else {
                val name = nm(code)
                if (t0 < 0) t0 = ev.eventTime
                if (ev.action == KeyEvent.ACTION_DOWN) {
                    if (ev.repeatCount == 0) {
                        log.add(0, "+" + (ev.eventTime - t0) + " ms   DOWN " + name)
                        if (lastUpName.isNotEmpty() && lastUpName != name && ev.eventTime - lastUpAt <= 40)
                            dropped.add("$lastUpName was dropped when $name was pressed (" + (ev.eventTime - lastUpAt) + " ms apart)")
                        lastDownName = name
                        lastDownAt = ev.eventTime
                        down.add(code)
                        if (down.size > most) most = down.size
                        if (down.size >= 3) {
                            worked.add(down.map { nm(it) }.sorted().joinToString(" + "))
                            while (worked.size > 8) worked.remove(worked.first())
                        }
                    }
                } else if (ev.action == KeyEvent.ACTION_UP) {
                    log.add(0, "+" + (ev.eventTime - t0) + " ms   UP " + name)
                    if (lastDownName.isNotEmpty() && lastDownName != name && ev.eventTime - lastDownAt <= 40)
                        dropped.add("$name was dropped when $lastDownName was pressed (" + (ev.eventTime - lastDownAt) + " ms apart)")
                    lastUpName = name
                    lastUpAt = ev.eventTime
                    down.remove(code)
                }
                while (log.size > 8) log.removeAt(log.size - 1)
                while (dropped.size > 8) dropped.remove(dropped.first())
                refresh()
                true
            }
        }
        dlg.show()
    }
}
