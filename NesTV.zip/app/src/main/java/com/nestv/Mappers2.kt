package com.nestv

/** Color Dreams (mapper 11). */
class ColorDreams(r: Rom) : Mapper(r) {
    private var pb = 0
    private var cb = 0
    override fun cpuRead(a: Int) = if (a >= 0x8000) prg(pb * 0x8000 + (a - 0x8000)) else 0
    override fun cpuWrite(a: Int, v: Int) { if (a >= 0x8000) { pb = v and 3; cb = (v shr 4) and 0xF } }
    override fun chrOff(a: Int) = cb * 0x2000 + a
    override fun saveExtra(sw: SW) { sw.int(pb); sw.int(cb) }
    override fun loadExtra(r: SR) { pb = r.int(); cb = r.int() }
}

/** BNROM (CHR RAM) and NINA-001 (CHR ROM) boards, both mapper 34. */
class Bnrom(r: Rom) : Mapper(r) {
    private val nina = !r.chrRam
    private var pb = 0
    private var c0 = 0
    private var c1 = 0
    override fun cpuRead(a: Int) = when {
        a >= 0x8000 -> prg(pb * 0x8000 + (a - 0x8000))
        a >= 0x6000 && nina -> ramRead(a)
        else -> 0
    }
    override fun cpuWrite(a: Int, v: Int) {
        if (nina) {
            when (a) {
                0x7FFD -> pb = v and 3
                0x7FFE -> c0 = v and 0xF
                0x7FFF -> c1 = v and 0xF
                else -> if (a in 0x6000..0x7FFC) ramWrite(a, v)
            }
        } else if (a >= 0x8000) pb = v and 0xFF
    }
    override fun chrOff(a: Int): Int =
        if (!nina) a else if (a < 0x1000) c0 * 0x1000 + a else c1 * 0x1000 + (a - 0x1000)
    override fun saveExtra(sw: SW) { sw.int(pb); sw.int(c0); sw.int(c1) }
    override fun loadExtra(r: SR) { pb = r.int(); c0 = r.int(); c1 = r.int() }
}

/** Codemasters / Camerica (mapper 71). */
class Camerica(r: Rom) : Mapper(r) {
    private var bank = 0
    override fun cpuRead(a: Int) = when {
        a >= 0xC000 -> prg(rom.prg.size - 0x4000 + (a - 0xC000))
        a >= 0x8000 -> prg(bank * 0x4000 + (a - 0x8000))
        else -> 0
    }
    override fun cpuWrite(a: Int, v: Int) {
        if (a >= 0xC000) bank = v and 0xF
        else if (a in 0x9000..0x9FFF) mirror = if ((v and 0x10) != 0) 3 else 2
    }
    override fun saveExtra(sw: SW) { sw.int(bank) }
    override fun loadExtra(r: SR) { bank = r.int() }
}

/** NINA-003 / NINA-006 (mapper 79). */
class Nina003(r: Rom) : Mapper(r) {
    private var pb = 0
    private var cb = 0
    override fun cpuRead(a: Int) = if (a >= 0x8000) prg(pb * 0x8000 + (a - 0x8000)) else 0
    override fun cpuWrite(a: Int, v: Int) { if ((a and 0xE100) == 0x4100) { pb = (v shr 3) and 1; cb = v and 7 } }
    override fun chrOff(a: Int) = cb * 0x2000 + a
    override fun saveExtra(sw: SW) { sw.int(pb); sw.int(cb) }
    override fun loadExtra(r: SR) { pb = r.int(); cb = r.int() }
}

/** Jaleco / Konami CHR-bank latch at $6000 (mapper 87). */
class Mapper87(r: Rom) : Mapper(r) {
    private var cb = 0
    override fun cpuRead(a: Int) = if (a >= 0x8000) prg(a - 0x8000) else 0
    override fun cpuWrite(a: Int, v: Int) { if (a in 0x6000..0x7FFF) cb = ((v and 1) shl 1) or ((v shr 1) and 1) }
    override fun chrOff(a: Int) = cb * 0x2000 + a
    override fun saveExtra(sw: SW) { sw.int(cb) }
    override fun loadExtra(r: SR) { cb = r.int() }
}

/** Jaleco JF-11 / JF-14 (mapper 140). */
class Jaleco140(r: Rom) : Mapper(r) {
    private var pb = 0
    private var cb = 0
    override fun cpuRead(a: Int) = if (a >= 0x8000) prg(pb * 0x8000 + (a - 0x8000)) else 0
    override fun cpuWrite(a: Int, v: Int) { if (a in 0x6000..0x7FFF) { pb = (v shr 4) and 3; cb = v and 0xF } }
    override fun chrOff(a: Int) = cb * 0x2000 + a
    override fun saveExtra(sw: SW) { sw.int(pb); sw.int(cb) }
    override fun loadExtra(r: SR) { pb = r.int(); cb = r.int() }
}

/** UNROM with the fixed bank at $8000 instead of $C000 (mapper 180). */
class Unrom180(r: Rom) : Mapper(r) {
    private var bank = 0
    override fun cpuRead(a: Int) = when {
        a >= 0xC000 -> prg(bank * 0x4000 + (a - 0xC000))
        a >= 0x8000 -> prg(a - 0x8000)
        else -> 0
    }
    override fun cpuWrite(a: Int, v: Int) { if (a >= 0x8000) bank = v and 7 }
    override fun saveExtra(sw: SW) { sw.int(bank) }
    override fun loadExtra(r: SR) { bank = r.int() }
}

/** Sunsoft-1 (mapper 184). */
class Sunsoft1(r: Rom) : Mapper(r) {
    private var c0 = 0
    private var c1 = 4
    override fun cpuRead(a: Int) = if (a >= 0x8000) prg(a - 0x8000) else 0
    override fun cpuWrite(a: Int, v: Int) { if (a in 0x6000..0x7FFF) { c0 = v and 7; c1 = 4 or ((v shr 4) and 7) } }
    override fun chrOff(a: Int) = if (a < 0x1000) c0 * 0x1000 + a else c1 * 0x1000 + (a - 0x1000)
    override fun saveExtra(sw: SW) { sw.int(c0); sw.int(c1) }
    override fun loadExtra(r: SR) { c0 = r.int(); c1 = r.int() }
}

/** Namco 108 / DxROM (mapper 206): MMC3 banking without IRQ or mirroring control. */
class Namco108(r: Rom) : Mapper(r) {
    private val reg = IntArray(8)
    private var sel = 0
    init { reg[7] = 1 }
    override fun cpuRead(a: Int): Int {
        if (a < 0x8000) return if (a >= 0x6000) ramRead(a) else 0
        val n = rom.prg.size / 0x2000
        val bank = when ((a - 0x8000) shr 13) { 0 -> reg[6]; 1 -> reg[7]; 2 -> n - 2; else -> n - 1 }
        return prg(bank * 0x2000 + (a and 0x1FFF))
    }
    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x6000..0x7FFF) { ramWrite(a, v); return }
        if (a in 0x8000..0x9FFF) { if ((a and 1) == 0) sel = v and 7 else reg[sel] = v and 0x3F }
    }
    override fun chrOff(a: Int): Int {
        val s = a shr 10
        val bank = when (s) { 0 -> reg[0] and 0xFE; 1 -> reg[0] or 1; 2 -> reg[1] and 0xFE; 3 -> reg[1] or 1; else -> reg[s - 2] }
        return bank * 0x400 + (a and 0x3FF)
    }
    override fun saveExtra(sw: SW) { sw.ints(reg); sw.int(sel) }
    override fun loadExtra(r: SR) { r.ints(reg); sel = r.int() }
}

/** MMC2 (mapper 9, Punch-Out!!) and MMC4 (mapper 10): CHR banks switched by the PPU fetching certain tiles. */
class Mmc2(r: Rom, private val mmc4: Boolean) : Mapper(r) {
    private var prgBank = 0
    private var fd0 = 0
    private var fe0 = 0
    private var fd1 = 0
    private var fe1 = 0
    private var l0 = true   // true = latch holds $FE
    private var l1 = true

    override fun cpuRead(a: Int): Int {
        if (a < 0x8000) return if (a >= 0x6000) ramRead(a) else 0
        return if (!mmc4) {
            if (a < 0xA000) prg(prgBank * 0x2000 + (a - 0x8000)) else prg(rom.prg.size - 0x6000 + (a - 0xA000))
        } else {
            if (a < 0xC000) prg(prgBank * 0x4000 + (a - 0x8000)) else prg(rom.prg.size - 0x4000 + (a - 0xC000))
        }
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x6000..0x7FFF) { ramWrite(a, v); return }
        when (a and 0xF000) {
            0xA000 -> prgBank = v and 0xF
            0xB000 -> fd0 = v and 0x1F
            0xC000 -> fe0 = v and 0x1F
            0xD000 -> fd1 = v and 0x1F
            0xE000 -> fe1 = v and 0x1F
            0xF000 -> mirror = if ((v and 1) == 0) 0 else 1
        }
    }

    override fun chrOff(a: Int): Int =
        if (a < 0x1000) (if (l0) fe0 else fd0) * 0x1000 + a
        else (if (l1) fe1 else fd1) * 0x1000 + (a - 0x1000)

    override fun tileRow(a: Int): Int {
        val row = super.tileRow(a)
        when (a and 0x1FF0) {
            0x0FD0 -> l0 = false
            0x0FE0 -> l0 = true
            0x1FD0 -> l1 = false
            0x1FE0 -> l1 = true
        }
        return row
    }

    override fun saveExtra(sw: SW) { sw.int(prgBank); sw.int(fd0); sw.int(fe0); sw.int(fd1); sw.int(fe1); sw.bool(l0); sw.bool(l1) }
    override fun loadExtra(r: SR) { prgBank = r.int(); fd0 = r.int(); fe0 = r.int(); fd1 = r.int(); fe1 = r.int(); l0 = r.bool(); l1 = r.bool() }
}

/** Sunsoft FME-7 / 5A (mapper 69). The extra sound channels of the 5B are not emulated. */
class Fme7(r: Rom) : Mapper(r) {
    private var cmd = 0
    private val chr = IntArray(8)
    private var reg8 = 0
    private var p1 = 0
    private var p2 = 0
    private var p3 = 0
    private var irqEn = false
    private var cntEn = false
    private var counter = 0
    private var line = false

    override val irq: Boolean get() = line

    override fun cpuRead(a: Int): Int {
        if (a >= 0xE000) return prg(rom.prg.size - 0x2000 + (a - 0xE000))
        if (a >= 0xC000) return prg(p3 * 0x2000 + (a and 0x1FFF))
        if (a >= 0xA000) return prg(p2 * 0x2000 + (a and 0x1FFF))
        if (a >= 0x8000) return prg(p1 * 0x2000 + (a and 0x1FFF))
        if (a >= 0x6000) {
            return if ((reg8 and 0x40) != 0) (if ((reg8 and 0x80) != 0) ramRead(a) else 0)
            else prg((reg8 and 0x3F) * 0x2000 + (a - 0x6000))
        }
        return 0
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x6000..0x7FFF) { if ((reg8 and 0xC0) == 0xC0) ramWrite(a, v); return }
        if (a in 0x8000..0x9FFF) { cmd = v and 0xF; return }
        if (a in 0xA000..0xBFFF) {
            when (cmd) {
                in 0..7 -> chr[cmd] = v and 0xFF
                8 -> reg8 = v
                9 -> p1 = v and 0x3F
                0xA -> p2 = v and 0x3F
                0xB -> p3 = v and 0x3F
                0xC -> mirror = v and 3
                0xD -> { irqEn = (v and 1) != 0; cntEn = (v and 0x80) != 0; line = false }
                0xE -> counter = (counter and 0xFF00) or (v and 0xFF)
                0xF -> counter = (counter and 0x00FF) or ((v and 0xFF) shl 8)
            }
        }
    }

    override fun chrOff(a: Int) = chr[a shr 10] * 0x400 + (a and 0x3FF)

    override fun cpuClock(n: Int) {
        if (!cntEn) return
        if (counter < n && irqEn) line = true
        counter = (counter - n) and 0xFFFF
    }

    override fun saveExtra(sw: SW) {
        sw.int(cmd); sw.ints(chr); sw.int(reg8); sw.int(p1); sw.int(p2); sw.int(p3)
        sw.bool(irqEn); sw.bool(cntEn); sw.int(counter); sw.bool(line)
    }
    override fun loadExtra(r: SR) {
        cmd = r.int(); r.ints(chr); reg8 = r.int(); p1 = r.int(); p2 = r.int(); p3 = r.int()
        irqEn = r.bool(); cntEn = r.bool(); counter = r.int(); line = r.bool()
    }
}

/** Konami VRC3 (mapper 73, Salamander). */
class Vrc3(r: Rom) : Mapper(r) {
    private var pb = 0
    private var latch = 0
    private var counter = 0
    private var ackEn = false
    private var irqEn = false
    private var mode8 = false
    private var line = false

    override val irq: Boolean get() = line

    override fun cpuRead(a: Int) = when {
        a >= 0xC000 -> prg(rom.prg.size - 0x4000 + (a - 0xC000))
        a >= 0x8000 -> prg(pb * 0x4000 + (a - 0x8000))
        a >= 0x6000 -> ramRead(a)
        else -> 0
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x6000..0x7FFF) { ramWrite(a, v); return }
        when (a and 0xF000) {
            0x8000 -> latch = (latch and 0xFFF0) or (v and 0xF)
            0x9000 -> latch = (latch and 0xFF0F) or ((v and 0xF) shl 4)
            0xA000 -> latch = (latch and 0xF0FF) or ((v and 0xF) shl 8)
            0xB000 -> latch = (latch and 0x0FFF) or ((v and 0xF) shl 12)
            0xC000 -> {
                line = false
                ackEn = (v and 1) != 0
                irqEn = (v and 2) != 0
                mode8 = (v and 4) != 0
                if (irqEn) counter = latch
            }
            0xD000 -> { line = false; irqEn = ackEn }
            0xF000 -> pb = v and 7
        }
    }

    override fun cpuClock(n: Int) {
        if (!irqEn) return
        for (i in 0 until n) {
            if (mode8) {
                val lo = (counter and 0xFF) + 1
                if (lo > 0xFF) { counter = (counter and 0xFF00) or (latch and 0xFF); line = true }
                else counter = (counter and 0xFF00) or lo
            } else {
                if (counter == 0xFFFF) { counter = latch; line = true } else counter++
            }
        }
    }

    override fun saveExtra(sw: SW) {
        sw.int(pb); sw.int(latch); sw.int(counter); sw.bool(ackEn); sw.bool(irqEn); sw.bool(mode8); sw.bool(line)
    }
    override fun loadExtra(r: SR) {
        pb = r.int(); latch = r.int(); counter = r.int(); ackEn = r.bool(); irqEn = r.bool(); mode8 = r.bool(); line = r.bool()
    }
}

/** Konami VRC1 (mapper 75). */
class Vrc1(r: Rom) : Mapper(r) {
    private var p0 = 0
    private var p1 = 0
    private var p2 = 0
    private var c0 = 0
    private var c1 = 0
    private var h0 = 0
    private var h1 = 0

    override fun cpuRead(a: Int) = when {
        a >= 0xE000 -> prg(rom.prg.size - 0x2000 + (a - 0xE000))
        a >= 0xC000 -> prg(p2 * 0x2000 + (a and 0x1FFF))
        a >= 0xA000 -> prg(p1 * 0x2000 + (a and 0x1FFF))
        a >= 0x8000 -> prg(p0 * 0x2000 + (a and 0x1FFF))
        else -> 0
    }

    override fun cpuWrite(a: Int, v: Int) {
        when (a and 0xF000) {
            0x8000 -> p0 = v and 0xF
            0xA000 -> p1 = v and 0xF
            0xC000 -> p2 = v and 0xF
            0x9000 -> { mirror = if ((v and 1) != 0) 1 else 0; h0 = (v shr 1) and 1; h1 = (v shr 2) and 1 }
            0xE000 -> c0 = v and 0xF
            0xF000 -> c1 = v and 0xF
        }
    }

    override fun chrOff(a: Int) =
        if (a < 0x1000) ((h0 shl 4) or c0) * 0x1000 + a else ((h1 shl 4) or c1) * 0x1000 + (a - 0x1000)

    override fun saveExtra(sw: SW) { sw.int(p0); sw.int(p1); sw.int(p2); sw.int(c0); sw.int(c1); sw.int(h0); sw.int(h1) }
    override fun loadExtra(r: SR) { p0 = r.int(); p1 = r.int(); p2 = r.int(); c0 = r.int(); c1 = r.int(); h0 = r.int(); h1 = r.int() }
}

/**
 * Konami VRC2 / VRC4 (mappers 21, 22, 23, 25). The register address lines are wired differently on each
 * board, so each mapper number decodes the address bits its boards use.
 */
class Vrc24(r: Rom, private val id: Int) : Mapper(r) {
    private var prg0 = 0
    private var prg1 = 0
    private var swap = false
    private val chrLo = IntArray(8)
    private val chrHi = IntArray(8)
    private var latch = 0
    private var counter = 0
    private var prescaler = 341
    private var irqA = false
    private var irqE = false
    private var irqM = false
    private var line = false

    override val irq: Boolean get() = line

    private fun regOf(a: Int): Int {
        val lo: Int
        val hi: Int
        when (id) {
            21 -> { lo = ((a shr 1) and 1) or ((a shr 6) and 1); hi = ((a shr 2) and 1) or ((a shr 7) and 1) }
            22 -> { lo = (a shr 1) and 1; hi = a and 1 }
            23 -> { lo = (a and 1) or ((a shr 2) and 1); hi = ((a shr 1) and 1) or ((a shr 3) and 1) }
            else -> { lo = ((a shr 1) and 1) or ((a shr 3) and 1); hi = (a and 1) or ((a shr 2) and 1) }
        }
        return lo or (hi shl 1)
    }

    override fun cpuRead(a: Int): Int {
        if (a < 0x8000) return if (a >= 0x6000) ramRead(a) else 0
        val n = rom.prg.size / 0x2000
        val bank = when ((a - 0x8000) shr 13) {
            0 -> if (swap) n - 2 else prg0
            1 -> prg1
            2 -> if (swap) prg0 else n - 2
            else -> n - 1
        }
        return prg(bank * 0x2000 + (a and 0x1FFF))
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x6000..0x7FFF) { ramWrite(a, v); return }
        if (a < 0x8000) return
        val reg = regOf(a)
        when (a and 0xF000) {
            0x8000 -> prg0 = v and 0x1F
            0x9000 -> if (reg < 2) mirror = v and 3 else swap = (v and 2) != 0
            0xA000 -> prg1 = v and 0x1F
            0xB000, 0xC000, 0xD000, 0xE000 -> {
                val idx = (((a shr 12) - 0xB) * 2) + (reg shr 1)
                if ((reg and 1) == 0) chrLo[idx] = v and 0xF else chrHi[idx] = v and 0x1F
            }
            0xF000 -> when (reg) {
                0 -> latch = (latch and 0xF0) or (v and 0xF)
                1 -> latch = (latch and 0x0F) or ((v and 0xF) shl 4)
                2 -> {
                    line = false
                    irqA = (v and 1) != 0
                    irqE = (v and 2) != 0
                    irqM = (v and 4) != 0
                    if (irqE) { counter = latch; prescaler = 341 }
                }
                else -> { line = false; irqE = irqA }
            }
        }
    }

    override fun chrOff(a: Int): Int {
        val i = a shr 10
        var bank = chrLo[i] or (chrHi[i] shl 4)
        if (id == 22) bank = bank shr 1
        return bank * 0x400 + (a and 0x3FF)
    }

    private fun clockCounter() {
        if (counter == 0xFF) { counter = latch; line = true } else counter++
    }

    override fun cpuClock(n: Int) {
        if (!irqE) return
        for (i in 0 until n) {
            if (irqM) clockCounter()
            else {
                prescaler -= 3
                if (prescaler <= 0) { prescaler += 341; clockCounter() }
            }
        }
    }

    override fun saveExtra(sw: SW) {
        sw.int(prg0); sw.int(prg1); sw.bool(swap); sw.ints(chrLo); sw.ints(chrHi)
        sw.int(latch); sw.int(counter); sw.int(prescaler); sw.bool(irqA); sw.bool(irqE); sw.bool(irqM); sw.bool(line)
    }
    override fun loadExtra(r: SR) {
        prg0 = r.int(); prg1 = r.int(); swap = r.bool(); r.ints(chrLo); r.ints(chrHi)
        latch = r.int(); counter = r.int(); prescaler = r.int(); irqA = r.bool(); irqE = r.bool(); irqM = r.bool(); line = r.bool()
    }
}

/** Konami VRC6 (mappers 24 and 26). The three extra sound channels are not emulated. */
class Vrc6(r: Rom, private val id: Int) : Mapper(r) {
    private var p16 = 0
    private var p8 = 0
    private val chr = IntArray(8)
    private var latch = 0
    private var counter = 0
    private var prescaler = 341
    private var irqA = false
    private var irqE = false
    private var irqM = false
    private var line = false

    override val irq: Boolean get() = line

    private fun regOf(a: Int): Int =
        if (id == 26) ((a and 1) shl 1) or ((a shr 1) and 1) else a and 3

    override fun cpuRead(a: Int) = when {
        a >= 0xE000 -> prg(rom.prg.size - 0x2000 + (a - 0xE000))
        a >= 0xC000 -> prg(p8 * 0x2000 + (a and 0x1FFF))
        a >= 0x8000 -> prg(p16 * 0x4000 + (a - 0x8000))
        a >= 0x6000 -> ramRead(a)
        else -> 0
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x6000..0x7FFF) { ramWrite(a, v); return }
        if (a < 0x8000) return
        val reg = regOf(a)
        when (a and 0xF000) {
            0x8000 -> p16 = v and 0xF
            0xC000 -> p8 = v and 0x1F
            0xB000 -> if (reg == 3) mirror = (v shr 2) and 3
            0xD000 -> chr[reg] = v and 0xFF
            0xE000 -> chr[4 + reg] = v and 0xFF
            0xF000 -> when (reg) {
                0 -> latch = v and 0xFF
                1 -> {
                    line = false
                    irqA = (v and 1) != 0
                    irqE = (v and 2) != 0
                    irqM = (v and 4) != 0
                    if (irqE) { counter = latch; prescaler = 341 }
                }
                2 -> { line = false; irqE = irqA }
            }
        }
    }

    override fun chrOff(a: Int) = chr[a shr 10] * 0x400 + (a and 0x3FF)

    private fun clockCounter() {
        if (counter == 0xFF) { counter = latch; line = true } else counter++
    }

    override fun cpuClock(n: Int) {
        if (!irqE) return
        for (i in 0 until n) {
            if (irqM) clockCounter()
            else {
                prescaler -= 3
                if (prescaler <= 0) { prescaler += 341; clockCounter() }
            }
        }
    }

    override fun saveExtra(sw: SW) {
        sw.int(p16); sw.int(p8); sw.ints(chr); sw.int(latch); sw.int(counter); sw.int(prescaler)
        sw.bool(irqA); sw.bool(irqE); sw.bool(irqM); sw.bool(line)
    }
    override fun loadExtra(r: SR) {
        p16 = r.int(); p8 = r.int(); r.ints(chr); latch = r.int(); counter = r.int(); prescaler = r.int()
        irqA = r.bool(); irqE = r.bool(); irqM = r.bool(); line = r.bool()
    }
}

/**
 * Multicart mappers 225 and 255 (ET-4310 style, "52-in-1" / "64-in-1" ...): the banks are chosen by the ADDRESS of a write
 * to $8000-$FFFF, not by the data. Four nibbles of RAM at $5800-$5FFF are readable and writable.
 *   address bits: 1 B M O P P P P P P C C C C C C
 *   B = high bit of both banks, M = mirroring (0 vertical, 1 horizontal), O = 16K mode, P = 16K PRG bank, C = 8K CHR bank
 */
class Multicart225(r: Rom) : Mapper(r) {
    private var latch = 0
    private val nibbles = IntArray(4)

    override fun cpuRead(a: Int): Int {
        if (a in 0x5800..0x5FFF) return nibbles[a and 3] and 0xF
        if (a < 0x8000) return 0
        val prg16 = ((latch shr 6) and 0x3F) or (((latch shr 14) and 1) shl 6)
        return if (((latch shr 12) and 1) != 0) prg(prg16 * 0x4000 + (a and 0x3FFF))
        else prg((prg16 shr 1) * 0x8000 + (a - 0x8000))
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x5800..0x5FFF) { nibbles[a and 3] = v and 0xF; return }
        if (a >= 0x8000) {
            latch = a
            mirror = (a shr 13) and 1
        }
    }

    override fun chrOff(a: Int): Int {
        if (rom.chrRam) return a
        val chr = (latch and 0x3F) or (((latch shr 14) and 1) shl 6)
        return chr * 0x2000 + a
    }

    override fun saveExtra(sw: SW) { sw.int(latch); sw.ints(nibbles) }
    override fun loadExtra(r: SR) { latch = r.int(); r.ints(nibbles) }
}

/**
 * Multicart mapper 227 (700-in-1 / 1200-in-1): banks chosen by the address of a write to $8000-$FFFF.
 *   bit 0 S = 32K mode, bit 1 M = mirroring (0 vertical, 1 horizontal), bits 2-6 and 8 = 16K PRG bank,
 *   bit 7 O = NROM mode, bit 9 L = in the UNROM-like mode the upper half is the last (1) or first (0) bank of the 128K group.
 */
class Multicart227(r: Rom) : Mapper(r) {
    private var latch = 0

    override fun cpuRead(a: Int): Int {
        if (a < 0x8000) return if (a >= 0x6000) ramRead(a) else 0
        val s = latch and 1
        val p = ((latch shr 2) and 0x1F) or ((latch and 0x100) shr 3)
        val l = (latch shr 9) and 1
        val bank16: Int
        if (((latch shr 7) and 1) != 0) {
            // NROM modes: 32K (S = 1) or one 16K bank repeated
            if (s == 1) return prg((p shr 1) * 0x8000 + (a - 0x8000))
            bank16 = p
        } else {
            // UNROM-like modes: lower half switchable, upper half fixed within the 128K group
            bank16 = if (a < 0xC000) (if (s == 1) p and 0x3E else p) else (if (l == 1) p or 7 else p and 0x38)
        }
        return prg(bank16 * 0x4000 + (a and 0x3FFF))
    }

    override fun cpuWrite(a: Int, v: Int) {
        if (a in 0x6000..0x7FFF) { ramWrite(a, v); return }
        if (a >= 0x8000) {
            latch = a
            mirror = (a shr 1) and 1
        }
    }

    override fun saveExtra(sw: SW) { sw.int(latch) }
    override fun loadExtra(r: SR) { latch = r.int() }
}
