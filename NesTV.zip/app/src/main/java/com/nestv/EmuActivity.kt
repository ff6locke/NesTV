package com.nestv

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class EmuActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var input: InputMap
    @Volatile private var nes: Nes? = null
    private var romBytes = ByteArray(0)
    private var lastSaved: ByteArray? = null
    private var romName = "rom"
    private lateinit var saveFile: File
    private var emuThread: Thread? = null
    private var renderThread: Thread? = null
    private var overlay: TextView? = null
    private var touchPad: TouchPad? = null

    @Volatile private var holderRef: SurfaceHolder? = null
    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var fast = false
    @Volatile private var resetReq = false
    @Volatile private var saveReq = false
    @Volatile private var frameNew = false

    private val frameLock = Any()
    private val frameBuf = IntArray(256 * 240)
    private val bmp = Bitmap.createBitmap(256, 240, Bitmap.Config.ARGB_8888)
    private val prefs by lazy { getSharedPreferences("nestv", Context.MODE_PRIVATE) }
    private val isTv by lazy {
        packageManager.hasSystemFeature("android.software.leanback") ||
            packageManager.hasSystemFeature("android.hardware.type.television")
    }

    private var menuOpen = false
    private var remapPending = false
    private var infoPending = false
    private var wizStep = -1
    private val wizMap = HashMap<Int, Int>()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        input = InputMap(this)

        try {
            val path = intent.getStringExtra("path")
            val bytes: ByteArray
            if (path != null) {
                val f = File(path)
                bytes = RomLoader.fromFile(f)
                romName = f.name
            } else {
                val uri = intent.data ?: throw IllegalArgumentException("No ROM given")
                bytes = RomLoader.fromUri(this, uri)
                romName = intent.getStringExtra("name") ?: "rom"
            }
            romBytes = bytes
            val n = Nes(Rom(bytes))
            val safe = romName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_")
            saveFile = File(File(filesDir, "saves").also { it.mkdirs() }, "$safe.sav")
            if (saveFile.exists()) n.mapper.loadData(saveFile.readBytes())
            lastSaved = n.mapper.saveData()
            nes = n
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot load ROM: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val frame = FrameLayout(this)
        val sv = SurfaceView(this)
        sv.holder.addCallback(this)
        sv.holder.setFixedSize(256, 240) // the display hardware scales this up, far cheaper than scaling on the CPU
        frame.addView(sv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        frame.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val w = r - l
            val h = b - t
            if (w > 0 && h > 0) {
                var vh = h
                var vw = h * 4 / 3
                if (vw > w) { vw = w; vh = w * 3 / 4 }
                val lp = sv.layoutParams as FrameLayout.LayoutParams
                if (lp.width != vw || lp.height != vh) {
                    lp.width = vw
                    lp.height = vh
                    lp.gravity = Gravity.CENTER
                    sv.layoutParams = lp
                }
            }
        }

        val tp = TouchPad(this, input) { showMenu() }
        tp.visibility = if (prefs.getBoolean("touch", !isTv)) View.VISIBLE else View.GONE
        touchPad = tp
        frame.addView(tp, FrameLayout.LayoutParams(-1, -1))

        overlay = TextView(this).apply {
            textSize = 26f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC000000.toInt())
            setPadding(60, 40, 60, 40)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        frame.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(frame)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        if (!input.configured && isTv) startWizard()
        running = true
        emuThread = Thread({ emuLoop() }, "emu").also { it.start() }
        renderThread = Thread({ renderLoop() }, "render").also { it.start() }
    }

    override fun onResume() {
        super.onResume()
        if (!menuOpen && wizStep < 0) paused = false
    }

    override fun onPause() {
        super.onPause()
        paused = true
        saveReq = true
    }

    override fun onStop() {
        super.onStop()
        saveReq = true
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        emuThread?.join(1000)
        renderThread?.join(500)
        nes?.let { persist(it) }
    }

    override fun surfaceCreated(holder: SurfaceHolder) { holderRef = holder }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { holderRef = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder) { holderRef = null }

    // ---------- emulation thread ----------
    private fun persist(n: Nes) {
        val d = n.mapper.saveData() ?: return
        val last = lastSaved
        if (last == null || !d.contentEquals(last)) {
            try { saveFile.writeBytes(d) } catch (e: Exception) {}
            lastSaved = d
        }
    }

    private fun publish(n: Nes) {
        synchronized(frameLock) {
            System.arraycopy(n.ppu.fb, 0, frameBuf, 0, frameBuf.size)
            frameNew = true
        }
    }

    private fun emuLoop() {
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (e: Exception) {}
        var n = nes ?: return
        var track: AudioTrack? = null
        try {
            val min = AudioTrack.getMinBufferSize(Apu.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            @Suppress("DEPRECATION")
            val t = AudioTrack(
                AudioManager.STREAM_MUSIC, Apu.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 19200), AudioTrack.MODE_STREAM
            )
            val pre = ShortArray(4800) // ~100 ms of silence so playback never starts empty
            t.write(pre, 0, pre.size)
            t.play()
            track = t
        } catch (e: Exception) {
            track = null
        }

        val tmp = ShortArray(4096)
        var next = System.nanoTime()
        var lastSave = System.currentTimeMillis()

        while (running) {
            val now = System.currentTimeMillis()
            if (saveReq || now - lastSave > 1000) {
                saveReq = false
                lastSave = now
                persist(n)
            }
            if (paused) {
                try { Thread.sleep(30) } catch (e: InterruptedException) {}
                next = System.nanoTime()
                continue
            }
            if (resetReq) {
                resetReq = false
                // Full power-cycle style reset: fresh console, but the cartridge save data is kept.
                persist(n)
                val data = n.mapper.saveData()
                try {
                    val fresh = Nes(Rom(romBytes))
                    if (data != null) fresh.mapper.loadData(data)
                    nes = fresh
                    n = fresh
                } catch (e: Exception) {}
                continue
            }

            if (fast) {
                for (i in 0 until 4) {
                    n.pad = input.pad
                    n.runFrame()
                    n.apu.count = 0
                }
                publish(n)
                continue
            }

            n.pad = input.pad
            n.runFrame()
            publish(n)
            val cnt = n.apu.takeSamples(tmp)
            val t = track
            if (t != null) {
                if (t.write(tmp, 0, cnt) < 0) { t.release(); track = null }
            } else {
                next += 16_639_267L
                val d = next - System.nanoTime()
                if (d > 0) {
                    try { Thread.sleep(d / 1_000_000, (d % 1_000_000).toInt()) } catch (e: InterruptedException) {}
                } else if (d < -100_000_000L) next = System.nanoTime()
            }
        }
        track?.release()
    }

    // ---------- video thread (keeps vsync waits off the emulation thread) ----------
    private fun renderLoop() {
        while (running) {
            if (!frameNew) {
                try { Thread.sleep(2) } catch (e: InterruptedException) {}
                continue
            }
            synchronized(frameLock) {
                bmp.setPixels(frameBuf, 0, 256, 0, 0, 256, 240)
                frameNew = false
            }
            val h = holderRef ?: continue
            try {
                val c = h.lockCanvas() ?: continue
                try {
                    c.drawBitmap(bmp, 0f, 0f, null)
                } finally {
                    h.unlockCanvasAndPost(c)
                }
            } catch (e: Exception) {}
        }
    }

    // ---------- input ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (wizStep >= 0) { handleWizard(e); return true }
        val kc = e.keyCode
        if (kc == KeyEvent.KEYCODE_BACK || kc == KeyEvent.KEYCODE_BUTTON_MODE || kc == KeyEvent.KEYCODE_ESCAPE) {
            if (e.action == KeyEvent.ACTION_UP) showMenu()
            return true
        }
        if (input.onKey(e)) return true
        return super.dispatchKeyEvent(e)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != 0 && input.onMotion(e)) return true
        return super.onGenericMotionEvent(e)
    }

    private fun showMenu() {
        if (menuOpen || wizStep >= 0) return
        menuOpen = true
        paused = true
        input.keys = 0
        input.axes = 0
        input.touch = 0
        touchPad?.invalidate()
        val touchOn = prefs.getBoolean("touch", !isTv)
        val items = arrayOf(
            "Resume",
            "Reset",
            "Fast forward: " + (if (fast) "ON" else "OFF"),
            "Touch controls: " + (if (touchOn) "ON" else "OFF"),
            "Remap A / B / Select / Start",
            "Info (for troubleshooting)",
            "Exit"
        )
        AlertDialog.Builder(this)
            .setTitle(romName)
            .setItems(items) { _, which ->
                when (which) {
                    1 -> resetReq = true
                    2 -> fast = !fast
                    3 -> {
                        val on = !touchOn
                        prefs.edit().putBoolean("touch", on).apply()
                        touchPad?.visibility = if (on) View.VISIBLE else View.GONE
                    }
                    4 -> remapPending = true
                    5 -> infoPending = true
                    6 -> finish()
                }
            }
            .setOnDismissListener {
                menuOpen = false
                if (remapPending) { remapPending = false; startWizard() } else if (infoPending) { infoPending = false; showInfo() } else paused = false
            }
            .show()
    }

    private fun showInfo() {
        val n = nes ?: return
        val r = n.rom
        menuOpen = true
        paused = true
        val msg = "Mapper ${r.mapperId} (submapper ${r.submapper}), PRG ${r.prg.size / 1024}K, " +
            "CHR ${r.chr.size / 1024}K" + (if (r.chrRam) " RAM" else "") + ", battery flag=${r.battery}\n" +
            n.mapper.debugInfo() + "\nCPU PC=%04X  ".format(n.debugPc()) + n.ppu.debug()
        AlertDialog.Builder(this)
            .setTitle("Info")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .setOnDismissListener { menuOpen = false; paused = false }
            .show()
    }

    private fun startWizard() {
        wizStep = 0
        wizMap.clear()
        paused = true
        showWizardText(null)
    }

    private fun showWizardText(extra: String?) {
        val o = overlay ?: return
        o.visibility = View.VISIBLE
        o.text = "Press the remote button to use as  " + InputMap.NAMES[wizStep] +
            "\n(" + (wizStep + 1) + " of 4)   Back = cancel" + (if (extra != null) "\n$extra" else "")
    }

    private fun endWizard() {
        wizStep = -1
        overlay?.visibility = View.GONE
        paused = false
    }

    private fun handleWizard(e: KeyEvent) {
        if (e.action != KeyEvent.ACTION_DOWN || e.repeatCount > 0) return
        val kc = e.keyCode
        if (kc == KeyEvent.KEYCODE_BACK) {
            if (!input.configured) input.save(emptyMap())
            endWizard()
            return
        }
        if (wizMap.containsKey(kc)) { showWizardText("That key is already used, pick another"); return }
        wizMap[kc] = InputMap.WIZARD_BITS[wizStep]
        wizStep++
        if (wizStep >= InputMap.WIZARD_BITS.size) {
            input.save(wizMap)
            endWizard()
            Toast.makeText(this, "Controls saved", Toast.LENGTH_SHORT).show()
        } else showWizardText(null)
    }
}
