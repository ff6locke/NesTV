package com.nestv

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.locks.LockSupport

class EmuActivity : Activity() {
    private lateinit var input: InputMap
    @Volatile private var nes: Nes? = null
    private var romBytes = ByteArray(0)
    private var lastSaved: ByteArray? = null
    private var romName = "rom"
    private var saveDirs: List<File> = emptyList()
    private var safeName = "rom"
    private var emuThread: Thread? = null
    private var overlay: TextView? = null
    private var fpsView: TextView? = null
    private var touchPad: TouchPad? = null
    private var glView: GLSurfaceView? = null
    private val gfxParams = GfxParams()
    private lateinit var gfx: GfxSettings

    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var fast = false
    @Volatile private var resetReq = false
    @Volatile private var stateOp = 0      // 1 = save state, 2 = load state
    @Volatile private var stateSlot = 0
    @Volatile private var saveReq = false
    @Volatile private var frameNew = false

    private val frameLock = Any()
    private val frameBuf = IntArray(256 * 240)
    private val prefs by lazy { getSharedPreferences("nestv", Context.MODE_PRIVATE) }
    private val isTv by lazy {
        packageManager.hasSystemFeature("android.software.leanback") ||
            packageManager.hasSystemFeature("android.hardware.type.television")
    }

    private var menuOpen = false
    private var remapPending = false
    private var infoPending = false
    private var slotPending = 0
    private var pendingAction: (() -> Unit)? = null
    @Volatile private var turboHalf = 2
    private var frameCount = 0
    private var wizStep = -1
    private var wizSingle = false
    private var remapChoice = -1
    private var currentSlot = 0
    @Volatile private var compatAccurate = true
    @Volatile private var ffSpeed = 3     // fast forward: 2, 3, 4 = times normal speed, 0 = as fast as possible
    @Volatile private var frameSkip = 1   // 0 off, 1 auto, 2 skip every 2nd, 3 skip 2 of 3
    @Volatile private var irqOffset = 0
    private val wizMap = HashMap<Int, Int>()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        input = InputMap(this)
        input.onAction = { handleAction(it) }
        input.onLatch = { toast(latchText(it)) }

        try {
            val path = intent.getStringExtra("path")
            val bytes: ByteArray
            if (path != null) {
                val f = File(path)
                bytes = RomLoader.fromFile(f)
                romName = f.name
            } else {
                val uri = intent.data ?: throw IllegalArgumentException("No ROM given")
                bytes = RomLoader.fromUri(this, uri)
                romName = intent.getStringExtra("name") ?: "rom"
            }
            romBytes = bytes
            val n = Nes(Rom(bytes))
            safeName = romName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_")
            saveDirs = SaveStore.dirs(this, path)
            val existing = SaveStore.read(saveDirs, "$safeName.sav")
            if (existing != null) {
                n.mapper.loadData(existing)
                SaveStore.writeAll(saveDirs, "$safeName.sav", existing) // restore missing copies after a reinstall
            }
            lastSaved = n.mapper.saveData()
            if (saveDirs.size == 1 && saveDirs[0].absolutePath.startsWith(filesDir.absolutePath))
                Toast.makeText(this, "Saves are kept inside the app and are lost on uninstall. Allow 'all files access' to keep them.", Toast.LENGTH_LONG).show()
            currentSlot = prefs.getInt("slot", 0).coerceIn(0, 9)
            compatAccurate = prefs.getBoolean("accurate", true)
            frameSkip = prefs.getInt("frameskip", 1)
            ffSpeed = prefs.getInt("ff_speed", 3)
            irqOffset = prefs.getInt("irq_offset", 0)
            applyCompat(n)
            nes = n
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot load ROM: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        gfx = GfxSettings(prefs, gfxParams)
        val frame = FrameLayout(this)

        // The picture is drawn by a small OpenGL shader (scanlines, CRT effects) on its own thread.
        val renderer = NesRenderer(gfxParams) { b ->
            synchronized(frameLock) {
                if (frameNew) {
                    b.position(0)
                    b.put(frameBuf)
                    b.position(0)
                    frameNew = false
                    true
                } else false
            }
        }
        val gv = GLSurfaceView(this)
        gv.setEGLContextClientVersion(2)
        gv.setEGLConfigChooser(8, 8, 8, 0, 0, 0)
        gv.preserveEGLContextOnPause = true
        gv.setRenderer(renderer)
        gv.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        glView = gv
        gfx.onChange = { gv.requestRender() }
        frame.addView(gv, FrameLayout.LayoutParams(-1, -1))

        turboHalf = if (prefs.getBoolean("turbo_fast", false)) 1 else 2
        val tp = TouchPad(this, input, prefs) { showMenu() }
        tp.visibility = if (prefs.getBoolean("touch", !isTv)) View.VISIBLE else View.GONE
        touchPad = tp
        frame.addView(tp, FrameLayout.LayoutParams(-1, -1))

        val fv = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.YELLOW)
            setShadowLayer(3f, 1f, 1f, Color.BLACK)
            setPadding(24, 12, 24, 12)
            visibility = if (gfx.showFps) View.VISIBLE else View.GONE
        }
        fpsView = fv
        frame.addView(fv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        overlay = TextView(this).apply {
            textSize = 26f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC000000.toInt())
            setPadding(60, 40, 60, 40)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        frame.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(frame)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        if (!input.configured && isTv) startWizard()
        running = true
        emuThread = Thread({ emuLoop() }, "emu").also { it.start() }
    }

    override fun onResume() {
        super.onResume()
        glView?.onResume()
        if (!menuOpen && wizStep < 0 && touchPad?.editing != true) paused = false
    }

    override fun onPause() {
        glView?.onPause()
        super.onPause()
        paused = true
        saveReq = true
    }

    override fun onStop() {
        super.onStop()
        saveReq = true
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        emuThread?.join(1000)
        nes?.let { persist(it) }
    }

    // ---------- emulation thread ----------
    private fun applyCompat(n: Nes) {
        n.ppu.accurate = compatAccurate
        n.mapper.irqOffset = irqOffset
    }

    private fun changeSlot(d: Int) {
        currentSlot = (currentSlot + d + 10) % 10
        prefs.edit().putInt("slot", currentSlot).apply()
        toast("Save slot ${currentSlot + 1}")
    }

    private fun handleAction(bit: Int) {
        when (bit) {
            InputMap.FF -> { fast = !fast; toast(if (fast) "Fast forward ON" else "Fast forward OFF") }
            InputMap.SAVE -> { stateSlot = currentSlot; stateOp = 1 }
            InputMap.LOAD -> { stateSlot = currentSlot; stateOp = 2 }
            InputMap.SLOT_NEXT -> changeSlot(1)
            InputMap.SLOT_PREV -> changeSlot(-1)
            InputMap.MENU -> showMenu()
        }
    }

    private fun persist(n: Nes) {
        val d = n.mapper.saveData() ?: return
        val last = lastSaved
        if (last == null || !d.contentEquals(last)) {
            SaveStore.writeAll(saveDirs, "$safeName.sav", d)
            lastSaved = d
        }
    }

    private fun publish(n: Nes) {
        synchronized(frameLock) {
            System.arraycopy(n.ppu.fb, 0, frameBuf, 0, frameBuf.size)
            frameNew = true
        }
        glView?.requestRender()
    }

    private fun waitUntil(deadline: Long) {
        while (running) {
            val rem = deadline - System.nanoTime()
            if (rem <= 0) return
            if (rem > 2_000_000L) {
                try { Thread.sleep((rem - 1_500_000L) / 1_000_000L) } catch (e: InterruptedException) {}
            } else LockSupport.parkNanos(minOf(rem, 300_000L))
        }
    }

    private fun emuLoop() {
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (e: Exception) {}
        var n = nes ?: return
        var track: AudioTrack? = null
        var written = 0L
        val target = 3200L // samples we try to keep queued in the audio device (about 66 ms)
        try {
            val min = AudioTrack.getMinBufferSize(Apu.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            @Suppress("DEPRECATION")
            val t = AudioTrack(
                AudioManager.STREAM_MUSIC, Apu.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 19200), AudioTrack.MODE_STREAM
            )
            val pre = ShortArray(target.toInt())
            t.write(pre, 0, pre.size)
            written = pre.size.toLong()
            t.play()
            track = t
        } catch (e: Exception) {
            track = null
        }

        val tmp = ShortArray(4096)
        val frameNs = 16_639_267.0
        var next = System.nanoTime()
        var lastSave = System.currentTimeMillis()
        var statStart = System.nanoTime()
        var statFrames = 0
        var statNs = 0L
        var statSkipped = 0
        var skipRun = 0
        var wasIdle = false     // paused or fast-forwarding: the audio device has run dry
        var lastShown = 0L
        var ffNext = 0L

        while (running) {
            val now = System.currentTimeMillis()
            if (saveReq || now - lastSave > 1000) {
                saveReq = false
                lastSave = now
                persist(n)
            }
            val op = stateOp
            if (op != 0) {
                stateOp = 0
                val slot = stateSlot
                val fname = "$safeName.st$slot"
                if (op == 1) {
                    val ok = try { SaveStore.writeAll(saveDirs, fname, n.saveState()) } catch (e: Exception) { false }
                    toast(if (ok) "State saved to slot ${slot + 1}" else "Could not save state")
                } else {
                    val data = SaveStore.read(saveDirs, fname)
                    if (data == null) toast("Slot ${slot + 1} is empty")
                    else if (n.loadState(data)) toast("State loaded from slot ${slot + 1}")
                    else toast("Could not load slot ${slot + 1} (made by a different game?)")
                }
            }
            if (paused) {
                wasIdle = true
                try { Thread.sleep(30) } catch (e: InterruptedException) {}
                next = System.nanoTime()
                statStart = next
                statFrames = 0
                statNs = 0L
                continue
            }
            if (resetReq) {
                resetReq = false
                // Full power-cycle style reset: fresh console, but the cartridge save data is kept.
                persist(n)
                val data = n.mapper.saveData()
                try {
                    val fresh = Nes(Rom(romBytes))
                    if (data != null) fresh.mapper.loadData(data)
                    applyCompat(fresh)
                    nes = fresh
                    n = fresh
                } catch (e: Exception) {}
                continue
            }

            if (fast) {
                // Fast forward: emulate at the chosen speed, but only draw about 60 frames a second so the
                // picture stays smooth; the frames in between are emulated without being drawn. Sound is muted.
                val t0 = System.nanoTime()
                if (!wasIdle) { ffNext = t0; lastShown = 0L }
                wasIdle = true
                val drawNow = t0 - lastShown >= 15_000_000L
                input.turboPhase = (frameCount++ / turboHalf) and 1
                n.pad = input.pad
                n.ppu.skip = !drawNow
                n.runFrame()
                n.ppu.skip = false
                n.apu.count = 0
                if (drawNow) { publish(n); lastShown = t0 }
                val sp = ffSpeed
                if (sp > 0) {
                    ffNext += (frameNs / sp).toLong()
                    val d = ffNext - System.nanoTime()
                    if (d > 0) waitUntil(ffNext) else if (d < -60_000_000L) ffNext = System.nanoTime()
                } else {
                    ffNext = System.nanoTime()
                    Thread.yield()
                }
                next = System.nanoTime()
                continue
            }

            if (wasIdle) {
                // Coming back from pause or fast forward: refill the audio device at once instead of crackling
                // while the frame timer slowly catches up.
                wasIdle = false
                next = System.nanoTime()
                val ta = track
                if (ta != null) {
                    val head = ta.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                    val buffered = written - head
                    if (buffered < target) {
                        val need = (target - buffered).toInt()
                        val w = ta.write(ShortArray(need), 0, need)
                        if (w > 0) written += w
                    }
                }
            }

            val t0 = System.nanoTime()
            // Frame skip: when the device falls behind (auto) or by a fixed pattern, a frame is emulated
            // fully (timing, sound, game logic) but not drawn, which saves a large part of the work.
            val skipNow = when (frameSkip) {
                1 -> (t0 - next) > 20_000_000L && skipRun < 5
                2 -> (frameCount and 1) == 1
                3 -> frameCount % 3 != 0
                else -> false
            }
            input.turboPhase = (frameCount++ / turboHalf) and 1
            n.pad = input.pad
            n.ppu.skip = skipNow
            n.runFrame()
            n.ppu.skip = false
            if (skipNow) { skipRun++; statSkipped++ } else { skipRun = 0; publish(n) }
            statNs += System.nanoTime() - t0
            statFrames++

            // Audio goes to the device without blocking; its fill level nudges the frame timer slightly so
            // frames stay evenly spaced (smooth video) while sound and picture never drift apart.
            val cnt = n.apu.takeSamples(tmp)
            val t = track
            var adj = 0.0
            if (t != null) {
                val w = t.write(tmp, 0, cnt)
                if (w < 0) {
                    t.release()
                    track = null
                } else {
                    written += w
                    val head = t.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                    adj = ((written - head - target).toDouble() / target).coerceIn(-1.0, 1.0)
                }
            }
            next += (frameNs * (1.0 + 0.02 * adj)).toLong()
            val d = next - System.nanoTime()
            if (d > 0) waitUntil(next) else if (d < -60_000_000L) next = System.nanoTime()

            val nowN = System.nanoTime()
            if (nowN - statStart >= 1_000_000_000L) {
                if (gfx.showFps && statFrames > 0) {
                    val fps = statFrames * 1e9 / (nowN - statStart)
                    val ms = statNs / statFrames / 1e6
                    val shown = fps - statSkipped * 1e9 / (nowN - statStart)
                    runOnUiThread { fpsView?.text = "%.1f fps shown (%.1f emulated)   %.1f ms/frame".format(shown, fps, ms) }
                }
                statStart = nowN
                statFrames = 0
                statNs = 0L
                statSkipped = 0
            }
        }
        track?.release()
    }

    // ---------- input ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val tp = touchPad
        if (tp != null && tp.editing) {
            if (e.action == KeyEvent.ACTION_UP) tp.finishEdit()
            return true
        }
        if (wizStep >= 0) { handleWizard(e); return true }
        val kc = e.keyCode
        if (kc == KeyEvent.KEYCODE_BACK || kc == KeyEvent.KEYCODE_BUTTON_MODE || kc == KeyEvent.KEYCODE_ESCAPE) {
            if (e.action == KeyEvent.ACTION_UP) showMenu()
            return true
        }
        if (input.onKey(e)) return true
        return super.dispatchKeyEvent(e)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != 0 && input.onMotion(e)) return true
        return super.onGenericMotionEvent(e)
    }

    private fun showMenu() {
        if (menuOpen || wizStep >= 0) return
        menuOpen = true
        paused = true
        input.releaseAll()
        input.axes = 0
        input.touch = 0
        touchPad?.invalidate()
        val touchOn = prefs.getBoolean("touch", !isTv)
        val items = arrayOf(
            "Resume",
            "Reset",
            "Save state...",
            "Load state...",
            "Fast forward: " + (if (fast) "ON" else "OFF"),
            "Fast forward speed: " + (if (ffSpeed == 0) "Max" else "${ffSpeed}x"),
            "Graphics / CRT effects: " + gfx.presetName() + "...",
            "Touch controls: " + (if (touchOn) "ON" else "OFF"),
            "Touch opacity: " + prefs.getInt("touch_alpha", 45) + "%...",
            "Move / resize touch buttons",
            "Rapid fire speed: " + (if (turboHalf == 1) "30" else "15") + " Hz",
            "Remap buttons...",
            "Info (for troubleshooting)",
            "Exit"
        )
        AlertDialog.Builder(this)
            .setTitle(romName)
            .setItems(items) { _, which ->
                when (which) {
                    1 -> resetReq = true
                    2 -> slotPending = 1
                    3 -> slotPending = 2
                    4 -> fast = !fast
                    5 -> {
                        ffSpeed = when (ffSpeed) { 2 -> 3; 3 -> 4; 4 -> 0; else -> 2 }
                        prefs.edit().putInt("ff_speed", ffSpeed).apply()
                    }
                    6 -> pendingAction = { showGraphics() }
                    7 -> {
                        val on = !touchOn
                        prefs.edit().putBoolean("touch", on).apply()
                        touchPad?.visibility = if (on) View.VISIBLE else View.GONE
                    }
                    8 -> pendingAction = { showOpacity() }
                    9 -> pendingAction = { startLayoutEdit() }
                    10 -> {
                        val quick = turboHalf != 1
                        prefs.edit().putBoolean("turbo_fast", quick).apply()
                        turboHalf = if (quick) 1 else 2
                    }
                    11 -> remapPending = true
                    12 -> infoPending = true
                    13 -> finish()
                }
            }
            .setOnDismissListener {
                menuOpen = false
                val act = pendingAction
                pendingAction = null
                if (act != null) act()
                else if (slotPending != 0) { val op = slotPending; slotPending = 0; showSlots(op) }
                else if (remapPending) { remapPending = false; showRemapList() }
                else if (infoPending) { infoPending = false; showInfo() }
                else paused = false
            }
            .show()
    }

    // ---------- graphics options ----------
    private fun showGraphics() {
        val g = gfx
        menuOpen = true
        paused = true
        val items = arrayOf(
            "Picture style: " + g.presetName() + "...",
            "Fine-tune effects...",
            "Aspect ratio: " + GfxPresets.ASPECTS[g.aspect],
            "Show FPS counter: " + (if (g.showFps) "ON" else "OFF"),
            "Frame skip: " + arrayOf("Off", "Auto (when slow)", "Every 2nd frame", "2 of every 3 frames")[frameSkip] + "...",
            "Accurate mid-line drawing: " + (if (compatAccurate) "ON" else "OFF"),
            "Split-screen timing: " + (if (irqOffset > 0) "+" else "") + irqOffset + " cycles...",
            "Done"
        )
        AlertDialog.Builder(this)
            .setTitle("Graphics")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> pendingAction = { showStyles() }
                    1 -> pendingAction = { showTune() }
                    2 -> {
                        g.aspect = (g.aspect + 1) % GfxPresets.ASPECTS.size
                        g.commit()
                        pendingAction = { showGraphics() }
                    }
                    3 -> {
                        g.showFps = !g.showFps
                        g.commit()
                        fpsView?.visibility = if (g.showFps) View.VISIBLE else View.GONE
                        pendingAction = { showGraphics() }
                    }
                    4 -> {
                        frameSkip = (frameSkip + 1) % 4
                        prefs.edit().putInt("frameskip", frameSkip).apply()
                        pendingAction = { showGraphics() }
                    }
                    5 -> {
                        compatAccurate = !compatAccurate
                        prefs.edit().putBoolean("accurate", compatAccurate).apply()
                        nes?.ppu?.accurate = compatAccurate
                        pendingAction = { showGraphics() }
                    }
                    6 -> pendingAction = { showIrq() }
                }
            }
            .setOnDismissListener {
                menuOpen = false
                val act = pendingAction
                pendingAction = null
                if (act != null) act() else paused = false
            }
            .show()
    }

    private fun irqLabel(v: Int) = "Split-screen timing: " + (if (v > 0) "+" else "") + v + " cycles"

    private fun showIrq() {
        menuOpen = true
        paused = false   // keep the game running so the effect can be watched while adjusting
        val start = irqOffset
        val label = TextView(this).apply {
            text = irqLabel(start)
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 8)
        }
        val note = TextView(this).apply {
            text = "For games that change the screen part-way down (status bars, card panels). If lines flicker or tiles go missing " +
                "where the screen splits, move this slider while watching the game. Left = earlier, right = later."
            textSize = 13f
            setPadding(40, 0, 40, 0)
        }
        val bar = SeekBar(this).apply {
            max = 200
            progress = start + 100
            setPadding(48, 24, 48, 24)
        }
        fun setIrq(v: Int) {
            irqOffset = v
            nes?.mapper?.irqOffset = v
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = irqLabel(p - 100)
                setIrq(p - 100)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label)
            addView(bar)
            addView(note)
        }
        AlertDialog.Builder(this)
            .setTitle("Split-screen timing")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> prefs.edit().putInt("irq_offset", bar.progress - 100).apply() }
            .setNeutralButton("Reset") { _, _ -> setIrq(0); prefs.edit().putInt("irq_offset", 0).apply() }
            .setNegativeButton("Cancel") { _, _ -> setIrq(start) }
            .setOnCancelListener { setIrq(start) }
            .setOnDismissListener { menuOpen = false; showGraphics() }
            .show()
    }

    private fun showStyles() {
        val g = gfx
        menuOpen = true
        paused = true
        AlertDialog.Builder(this)
            .setTitle("Picture style")
            .setSingleChoiceItems(GfxPresets.NAMES, if (g.preset in GfxPresets.NAMES.indices) g.preset else -1) { d, which ->
                g.applyPreset(which)
                d.dismiss()
            }
            .setOnDismissListener { menuOpen = false; showGraphics() }
            .show()
    }

    private fun showTune() {
        val g = gfx
        menuOpen = true
        paused = true
        val snap = g.snapshot()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 10)
        }
        fun row(title: String, value: Int, set: (Int) -> Unit) {
            val label = TextView(this).apply {
                text = "$title: $value%"
                textSize = 16f
                setPadding(0, 16, 0, 0)
            }
            val bar = SeekBar(this).apply {
                max = 100
                progress = value
                keyProgressIncrement = 5
            }
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = "$title: $p%"
                    set(p)
                    g.preview()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            box.addView(label)
            box.addView(bar)
        }
        row("Scanlines", g.scan) { g.scan = it }
        row("Phosphor mask", g.mask) { g.mask = it }
        row("Screen curve", g.curve) { g.curve = it }
        row("Blur (composite TV)", g.blur) { g.blur = it }
        row("Vignette (dark corners)", g.vig) { g.vig = it }
        val sharp = CheckBox(this).apply {
            text = "Sharp pixel scaling"
            isChecked = g.sharp == 1
        }
        sharp.setOnCheckedChangeListener { _, c -> g.sharp = if (c) 1 else 0; g.preview() }
        box.addView(sharp)
        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this)
            .setTitle("Fine-tune effects")
            .setView(scroll)
            .setPositiveButton("OK") { _, _ -> g.commit() }
            .setNegativeButton("Cancel") { _, _ -> g.restore(snap) }
            .setOnCancelListener { g.restore(snap) }
            .setOnDismissListener { menuOpen = false; showGraphics() }
            .show()
    }

    // ---------- touch pad options ----------
    private fun showOpacity() {
        val tp = touchPad ?: return
        menuOpen = true
        paused = true
        if (tp.visibility != View.VISIBLE) {
            prefs.edit().putBoolean("touch", true).apply()
            tp.visibility = View.VISIBLE
        }
        val start = prefs.getInt("touch_alpha", 45)
        val label = TextView(this).apply {
            text = "$start%"
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 8)
        }
        val bar = SeekBar(this).apply {
            max = 90
            progress = start - 10
            setPadding(48, 24, 48, 24)
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "${p + 10}%"
                tp.opacity = (p + 10) / 100f
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label)
            addView(bar)
        }
        AlertDialog.Builder(this)
            .setTitle("Touch button opacity")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> prefs.edit().putInt("touch_alpha", bar.progress + 10).apply() }
            .setNegativeButton("Cancel") { _, _ -> tp.opacity = start / 100f }
            .setOnCancelListener { tp.opacity = start / 100f }
            .setOnDismissListener { menuOpen = false; paused = false }
            .show()
    }

    private fun startLayoutEdit() {
        val tp = touchPad ?: return
        prefs.edit().putBoolean("touch", true).apply()
        tp.visibility = View.VISIBLE
        paused = true
        tp.startEdit { paused = false }
    }

    private fun toast(m: String) {
        runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    // ---------- save states / info ----------
    private fun showSlots(op: Int) {
        menuOpen = true
        paused = true
        val fmt = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        val labels = Array(10) { i ->
            val t = SaveStore.modified(saveDirs, "$safeName.st$i")
            "Slot ${i + 1}:   " + (if (t == null) "empty" else fmt.format(Date(t)))
        }
        AlertDialog.Builder(this)
            .setTitle(if (op == 1) "Save state" else "Load state")
            .setItems(labels) { _, which ->
                stateSlot = which
                stateOp = op
                currentSlot = which
                prefs.edit().putInt("slot", which).apply()
            }
            .setOnDismissListener { menuOpen = false; paused = false }
            .show()
    }

    private fun showInfo() {
        val n = nes ?: return
        val r = n.rom
        menuOpen = true
        paused = true
        val msg = "Mapper ${r.mapperId} (submapper ${r.submapper}), PRG ${r.prg.size / 1024}K, " +
            "CHR ${r.chr.size / 1024}K" + (if (r.chrRam) " RAM" else "") + ", battery flag=${r.battery}\n" +
            n.mapper.debugInfo() + "\nSave folder: ${saveDirs.firstOrNull()?.absolutePath}" +
            (if (saveDirs.size == 1 && saveDirs[0].absolutePath.startsWith(filesDir.absolutePath)) "  (inside app: lost on uninstall)" else "  (+${saveDirs.size - 1} more copies)") +
            "\nCPU PC=%04X  ".format(n.debugPc()) + n.ppu.debug()
        AlertDialog.Builder(this)
            .setTitle("Info")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .setOnDismissListener { menuOpen = false; paused = false }
            .show()
    }

    // ---------- button remapping (every button, including directions) ----------
    private var wizBit = 0
    private var wizName = ""
    private var wizReturn: (() -> Unit)? = null

    private fun latchText(m: Int): String {
        val parts = ArrayList<String>()
        for (i in 0 until 8) if ((m and (1 shl i)) != 0) parts.add(InputMap.NAMES[i])
        return if (parts.isEmpty()) "No buttons held" else "Holding: " + parts.joinToString(" + ")
    }

    private fun showRemapList() {
        menuOpen = true
        paused = true
        val count = InputMap.NAMES.size
        val items = ArrayList<String>()
        items.add("Guided setup (all NES buttons in order)")
        for (i in 0 until count) items.add(InputMap.NAMES[i] + ":   " + input.labelFor(InputMap.WIZARD_BITS[i]))
        items.add("Combo buttons (A+B, Right+B ...)...")
        items.add("Hold buttons (stay pressed until pressed again)...")
        items.add("Key release delay: " + (if (input.releaseMs == 0) "off" else "${input.releaseMs} ms"))
        items.add("Rollover assist (covers keys the remote drops): " + arrayOf("Off", "Normal", "Wide")[input.assistLevel] + "...")
        items.add("Input test (how many keys does the remote send?)...")
        items.add("Reset all to defaults")
        remapChoice = -1
        AlertDialog.Builder(this)
            .setTitle("Remap buttons")
            .setItems(items.toTypedArray()) { _, which -> remapChoice = which }
            .setOnDismissListener {
                menuOpen = false
                val c = remapChoice
                remapChoice = -1
                when {
                    c == 0 -> startWizard()
                    c in 1..count -> startSingle(InputMap.WIZARD_BITS[c - 1], InputMap.NAMES[c - 1]) { showRemapList() }
                    c == count + 1 -> showBitList("Combo buttons", InputMap.COMBO_NAMES, InputMap.COMBO_BITS)
                    c == count + 2 -> showBitList("Hold buttons", InputMap.LATCH_NAMES, InputMap.LATCH_BITS)
                    c == count + 3 -> {
                        input.setRelease(when (input.releaseMs) { 0 -> 30; 30 -> 60; 60 -> 100; else -> 0 })
                        showRemapList()
                    }
                    c == count + 4 -> { input.cycleAssist(); showRemapList() }
                    c == count + 5 -> showInputTest()
                    c == count + 6 -> { input.reset(); toast("Controls reset to defaults"); showRemapList() }
                    else -> paused = false
                }
            }
            .show()
    }

    private fun showBitList(title: String, names: Array<String>, bits: IntArray) {
        menuOpen = true
        paused = true
        val items = Array(names.size) { i -> names[i] + ":   " + input.labelFor(bits[i]) }
        remapChoice = -1
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(items) { _, which -> remapChoice = which }
            .setOnDismissListener {
                menuOpen = false
                val c = remapChoice
                remapChoice = -1
                if (c in names.indices) startSingle(bits[c], names[c]) { showBitList(title, names, bits) }
                else showRemapList()
            }
            .show()
    }

    /** Shows which keys are down right now and the most that were down together, to check a remote's limit. */
    private fun showInputTest() {
        menuOpen = true
        paused = true
        val down = LinkedHashSet<Int>()
        val log = ArrayList<String>()
        val worked = LinkedHashSet<String>()
        val dropped = LinkedHashSet<String>()
        var t0 = -1L
        var most = 0
        var lastUpName = ""
        var lastUpAt = -1000L
        var lastDownName = ""
        var lastDownAt = -1000L
        val tv = TextView(this).apply {
            textSize = 15f
            setPadding(48, 24, 48, 16)
        }
        fun nm(code: Int) = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
        fun refresh() {
            tv.text = "Hold several remote buttons together. Back closes this.\n\n" +
                "Keys down now (" + down.size + "): " + (if (down.isEmpty()) "-" else down.joinToString(", ") { nm(it) }) +
                "\nMost at the same time: " + most +
                "\n\nGroups of 3 or more that worked together:\n" + (if (worked.isEmpty()) "-" else worked.joinToString("\n")) +
                "\n\nKeys the remote dropped when another key went down:\n" + (if (dropped.isEmpty()) "-" else dropped.joinToString("\n")) +
                "\n\nLast events (newest first):\n" + (if (log.isEmpty()) "-" else log.joinToString("\n")) +
                (if (dropped.isNotEmpty()) "\n\nThis remote drops keys. Turn on Rollover assist (Normal, or Wide if it still drops) in Remap buttons." else "") +
                "\n\nBind your three functions (for example Right, A and B) to keys that appear together in the list above. " +
                "To need fewer keys at once, use Combo buttons."
        }
        refresh()
        val scroll = ScrollView(this).apply { addView(tv) }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Input test")
            .setView(scroll)
            .setOnDismissListener { menuOpen = false; showRemapList() }
            .create()
        dlg.setOnKeyListener { _, code, ev ->
            if (code == KeyEvent.KEYCODE_BACK) {
                false
            } else {
                val name = nm(code)
                if (t0 < 0) t0 = ev.eventTime
                if (ev.action == KeyEvent.ACTION_DOWN) {
                    if (ev.repeatCount == 0) {
                        log.add(0, "+" + (ev.eventTime - t0) + " ms   DOWN " + name)
                        if (lastUpName.isNotEmpty() && lastUpName != name && ev.eventTime - lastUpAt <= 40)
                            dropped.add("$lastUpName was dropped when $name was pressed")
                        lastDownName = name
                        lastDownAt = ev.eventTime
                        down.add(code)
                        if (down.size > most) most = down.size
                        if (down.size >= 3) {
                            worked.add(down.map { nm(it) }.sorted().joinToString(" + "))
                            while (worked.size > 8) worked.remove(worked.first())
                        }
                    }
                } else if (ev.action == KeyEvent.ACTION_UP) {
                    log.add(0, "+" + (ev.eventTime - t0) + " ms   UP " + name)
                    if (lastDownName.isNotEmpty() && lastDownName != name && ev.eventTime - lastDownAt <= 40)
                        dropped.add("$name was dropped when $lastDownName was pressed")
                    lastUpName = name
                    lastUpAt = ev.eventTime
                    down.remove(code)
                }
                while (log.size > 8) log.removeAt(log.size - 1)
                while (dropped.size > 8) dropped.remove(dropped.first())
                refresh()
                true
            }
        }
        dlg.show()
    }

    private fun startWizard() {
        wizSingle = false
        wizStep = 0
        wizBit = InputMap.WIZARD_BITS[0]
        wizName = InputMap.NAMES[0]
        wizReturn = null
        wizMap.clear()
        wizMap.putAll(input.custom())
        paused = true
        showWizardText(null)
    }

    private fun startSingle(bit: Int, name: String, back: () -> Unit) {
        wizSingle = true
        wizStep = 0
        wizBit = bit
        wizName = name
        wizReturn = back
        wizMap.clear()
        wizMap.putAll(input.custom())
        paused = true
        showWizardText(null)
    }

    private fun showWizardText(extra: String?) {
        val o = overlay ?: return
        o.visibility = View.VISIBLE
        o.text = "Press the key to use for  $wizName\n(now: " + input.labelFor(wizBit) + ")\n" +
            (if (wizSingle) "Back = cancel"
            else "(" + (wizStep + 1) + " of " + InputMap.GUIDED + ")   Back = finish and keep the rest") +
            (if (extra != null) "\n$extra" else "")
    }

    private fun endWizard(resume: Boolean) {
        wizStep = -1
        overlay?.visibility = View.GONE
        if (resume) paused = false
    }

    private fun handleWizard(e: KeyEvent) {
        if (e.action != KeyEvent.ACTION_DOWN || e.repeatCount > 0) return
        val kc = e.keyCode
        if (kc == KeyEvent.KEYCODE_BACK) {
            if (wizSingle) {
                endWizard(false)
                wizReturn?.invoke()
            } else {
                input.save(wizMap)
                endWizard(true)
                Toast.makeText(this, "Controls saved", Toast.LENGTH_SHORT).show()
            }
            return
        }
        val bit = wizBit
        wizMap.entries.removeAll { it.value == bit || it.key == kc }
        wizMap[kc] = bit
        if (wizSingle) {
            input.save(wizMap)
            endWizard(false)
            wizReturn?.invoke()
        } else {
            wizStep++
            if (wizStep >= InputMap.GUIDED) {
                input.save(wizMap)
                endWizard(true)
                Toast.makeText(this, "Controls saved", Toast.LENGTH_SHORT).show()
            } else {
                wizBit = InputMap.WIZARD_BITS[wizStep]
                wizName = InputMap.NAMES[wizStep]
                showWizardText(null)
            }
        }
    }
}
