package com.nestv

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.locks.LockSupport

class EmuActivity : Activity() {
    private lateinit var input: InputMap
    @Volatile private var nes: Nes? = null
    private var romBytes = ByteArray(0)
    private var lastSaved: ByteArray? = null
    private var romName = "rom"
    private var saveDirs: List<File> = emptyList()
    private var safeName = "rom"
    private var emuThread: Thread? = null
    private var overlay: TextView? = null
    private var fpsView: TextView? = null
    private var touchPad: TouchPad? = null
    private var glView: GLSurfaceView? = null
    private val gfxParams = GfxParams()
    private lateinit var gfx: GfxSettings

    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var fast = false
    @Volatile private var resetReq = false
    @Volatile private var stateOp = 0      // 1 = save state, 2 = load state
    @Volatile private var stateSlot = 0
    @Volatile private var saveReq = false
    @Volatile private var frameNew = false

    private val frameLock = Any()
    private val frameBuf = IntArray(256 * 240)
    private val prefs by lazy { getSharedPreferences("nestv", Context.MODE_PRIVATE) }
    private val isTv by lazy {
        packageManager.hasSystemFeature("android.software.leanback") ||
            packageManager.hasSystemFeature("android.hardware.type.television")
    }

    private var menuOpen = false
    private var remapPending = false
    private var infoPending = false
    private var slotPending = 0
    private var pendingAction: (() -> Unit)? = null
    @Volatile private var turboHalf = 2
    private var frameCount = 0
    private var wizStep = -1
    private var wizSingle = false
    private var remapChoice = -1
    private val wizMap = HashMap<Int, Int>()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        input = InputMap(this)

        try {
            val path = intent.getStringExtra("path")
            val bytes: ByteArray
            if (path != null) {
                val f = File(path)
                bytes = RomLoader.fromFile(f)
                romName = f.name
            } else {
                val uri = intent.data ?: throw IllegalArgumentException("No ROM given")
                bytes = RomLoader.fromUri(this, uri)
                romName = intent.getStringExtra("name") ?: "rom"
            }
            romBytes = bytes
            val n = Nes(Rom(bytes))
            safeName = romName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_")
            saveDirs = SaveStore.dirs(this, path)
            val existing = SaveStore.read(saveDirs, "$safeName.sav")
            if (existing != null) {
                n.mapper.loadData(existing)
                SaveStore.writeAll(saveDirs, "$safeName.sav", existing) // restore missing copies after a reinstall
            }
            lastSaved = n.mapper.saveData()
            if (saveDirs.size == 1 && saveDirs[0].absolutePath.startsWith(filesDir.absolutePath))
                Toast.makeText(this, "Saves are kept inside the app and are lost on uninstall. Allow 'all files access' to keep them.", Toast.LENGTH_LONG).show()
            nes = n
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot load ROM: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        gfx = GfxSettings(prefs, gfxParams)
        val frame = FrameLayout(this)

        // The picture is drawn by a small OpenGL shader (scanlines, CRT effects) on its own thread.
        val renderer = NesRenderer(gfxParams) { b ->
            synchronized(frameLock) {
                if (frameNew) {
                    b.position(0)
                    b.put(frameBuf)
                    b.position(0)
                    frameNew = false
                    true
                } else false
            }
        }
        val gv = GLSurfaceView(this)
        gv.setEGLContextClientVersion(2)
        gv.setEGLConfigChooser(8, 8, 8, 0, 0, 0)
        gv.preserveEGLContextOnPause = true
        gv.setRenderer(renderer)
        gv.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        glView = gv
        gfx.onChange = { gv.requestRender() }
        frame.addView(gv, FrameLayout.LayoutParams(-1, -1))

        turboHalf = if (prefs.getBoolean("turbo_fast", false)) 1 else 2
        val tp = TouchPad(this, input, prefs) { showMenu() }
        tp.visibility = if (prefs.getBoolean("touch", !isTv)) View.VISIBLE else View.GONE
        touchPad = tp
        frame.addView(tp, FrameLayout.LayoutParams(-1, -1))

        val fv = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.YELLOW)
            setShadowLayer(3f, 1f, 1f, Color.BLACK)
            setPadding(24, 12, 24, 12)
            visibility = if (gfx.showFps) View.VISIBLE else View.GONE
        }
        fpsView = fv
        frame.addView(fv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        overlay = TextView(this).apply {
            textSize = 26f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC000000.toInt())
            setPadding(60, 40, 60, 40)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        frame.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(frame)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        if (!input.configured && isTv) startWizard()
        running = true
        emuThread = Thread({ emuLoop() }, "emu").also { it.start() }
    }

    override fun onResume() {
        super.onResume()
        glView?.onResume()
        if (!menuOpen && wizStep < 0 && touchPad?.editing != true) paused = false
    }

    override fun onPause() {
        glView?.onPause()
        super.onPause()
        paused = true
        saveReq = true
    }

    override fun onStop() {
        super.onStop()
        saveReq = true
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        emuThread?.join(1000)
        nes?.let { persist(it) }
    }

    // ---------- emulation thread ----------
    private fun persist(n: Nes) {
        val d = n.mapper.saveData() ?: return
        val last = lastSaved
        if (last == null || !d.contentEquals(last)) {
            SaveStore.writeAll(saveDirs, "$safeName.sav", d)
            lastSaved = d
        }
    }

    private fun publish(n: Nes) {
        synchronized(frameLock) {
            System.arraycopy(n.ppu.fb, 0, frameBuf, 0, frameBuf.size)
            frameNew = true
        }
        glView?.requestRender()
    }

    private fun waitUntil(deadline: Long) {
        while (running) {
            val rem = deadline - System.nanoTime()
            if (rem <= 0) return
            if (rem > 2_000_000L) {
                try { Thread.sleep((rem - 1_500_000L) / 1_000_000L) } catch (e: InterruptedException) {}
            } else LockSupport.parkNanos(minOf(rem, 300_000L))
        }
    }

    private fun emuLoop() {
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (e: Exception) {}
        var n = nes ?: return
        var track: AudioTrack? = null
        var written = 0L
        val target = 3200L // samples we try to keep queued in the audio device (about 66 ms)
        try {
            val min = AudioTrack.getMinBufferSize(Apu.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            @Suppress("DEPRECATION")
            val t = AudioTrack(
                AudioManager.STREAM_MUSIC, Apu.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 19200), AudioTrack.MODE_STREAM
            )
            val pre = ShortArray(target.toInt())
            t.write(pre, 0, pre.size)
            written = pre.size.toLong()
            t.play()
            track = t
        } catch (e: Exception) {
            track = null
        }

        val tmp = ShortArray(4096)
        val frameNs = 16_639_267.0
        var next = System.nanoTime()
        var lastSave = System.currentTimeMillis()
        var statStart = System.nanoTime()
        var statFrames = 0
        var statNs = 0L

        while (running) {
            val now = System.currentTimeMillis()
            if (saveReq || now - lastSave > 1000) {
                saveReq = false
                lastSave = now
                persist(n)
            }
            val op = stateOp
            if (op != 0) {
                stateOp = 0
                val slot = stateSlot
                val fname = "$safeName.st$slot"
                if (op == 1) {
                    val ok = try { SaveStore.writeAll(saveDirs, fname, n.saveState()) } catch (e: Exception) { false }
                    toast(if (ok) "State saved to slot ${slot + 1}" else "Could not save state")
                } else {
                    val data = SaveStore.read(saveDirs, fname)
                    if (data == null) toast("Slot ${slot + 1} is empty")
                    else if (n.loadState(data)) toast("State loaded from slot ${slot + 1}")
                    else toast("Could not load slot ${slot + 1} (made by a different game?)")
                }
            }
            if (paused) {
                try { Thread.sleep(30) } catch (e: InterruptedException) {}
                next = System.nanoTime()
                statStart = next
                statFrames = 0
                statNs = 0L
                continue
            }
            if (resetReq) {
                resetReq = false
                // Full power-cycle style reset: fresh console, but the cartridge save data is kept.
                persist(n)
                val data = n.mapper.saveData()
                try {
                    val fresh = Nes(Rom(romBytes))
                    if (data != null) fresh.mapper.loadData(data)
                    nes = fresh
                    n = fresh
                } catch (e: Exception) {}
                continue
            }

            if (fast) {
                for (i in 0 until 4) {
                    input.turboPhase = (frameCount++ / turboHalf) and 1
                    n.pad = input.pad
                    n.runFrame()
                    n.apu.count = 0
                }
                publish(n)
                next = System.nanoTime()
                continue
            }

            val t0 = System.nanoTime()
            input.turboPhase = (frameCount++ / turboHalf) and 1
            n.pad = input.pad
            n.runFrame()
            publish(n)
            statNs += System.nanoTime() - t0
            statFrames++

            // Audio goes to the device without blocking; its fill level nudges the frame timer slightly so
            // frames stay evenly spaced (smooth video) while sound and picture never drift apart.
            val cnt = n.apu.takeSamples(tmp)
            val t = track
            var adj = 0.0
            if (t != null) {
                val w = t.write(tmp, 0, cnt)
                if (w < 0) {
                    t.release()
                    track = null
                } else {
                    written += w
                    val head = t.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                    adj = ((written - head - target).toDouble() / target).coerceIn(-1.0, 1.0)
                }
            }
            next += (frameNs * (1.0 + 0.02 * adj)).toLong()
            val d = next - System.nanoTime()
            if (d > 0) waitUntil(next) else if (d < -60_000_000L) next = System.nanoTime()

            val nowN = System.nanoTime()
            if (nowN - statStart >= 1_000_000_000L) {
                if (gfx.showFps && statFrames > 0) {
                    val fps = statFrames * 1e9 / (nowN - statStart)
                    val ms = statNs / statFrames / 1e6
                    runOnUiThread { fpsView?.text = "%.1f fps   emulation %.1f ms/frame".format(fps, ms) }
                }
                statStart = nowN
                statFrames = 0
                statNs = 0L
            }
        }
        track?.release()
    }

    // ---------- input ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val tp = touchPad
        if (tp != null && tp.editing) {
            if (e.action == KeyEvent.ACTION_UP) tp.finishEdit()
            return true
        }
        if (wizStep >= 0) { handleWizard(e); return true }
        val kc = e.keyCode
        if (kc == KeyEvent.KEYCODE_BACK || kc == KeyEvent.KEYCODE_BUTTON_MODE || kc == KeyEvent.KEYCODE_ESCAPE) {
            if (e.action == KeyEvent.ACTION_UP) showMenu()
            return true
        }
        if (input.onKey(e)) return true
        return super.dispatchKeyEvent(e)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != 0 && input.onMotion(e)) return true
        return super.onGenericMotionEvent(e)
    }

    private fun showMenu() {
        if (menuOpen || wizStep >= 0) return
        menuOpen = true
        paused = true
        input.keys = 0
        input.axes = 0
        input.touch = 0
        touchPad?.invalidate()
        val touchOn = prefs.getBoolean("touch", !isTv)
        val items = arrayOf(
            "Resume",
            "Reset",
            "Save state...",
            "Load state...",
            "Fast forward: " + (if (fast) "ON" else "OFF"),
            "Graphics / CRT effects: " + gfx.presetName() + "...",
            "Touch controls: " + (if (touchOn) "ON" else "OFF"),
            "Touch opacity: " + prefs.getInt("touch_alpha", 45) + "%...",
            "Move / resize touch buttons",
            "Rapid fire speed: " + (if (turboHalf == 1) "30" else "15") + " Hz",
            "Remap buttons...",
            "Info (for troubleshooting)",
            "Exit"
        )
        AlertDialog.Builder(this)
            .setTitle(romName)
            .setItems(items) { _, which ->
                when (which) {
                    1 -> resetReq = true
                    2 -> slotPending = 1
                    3 -> slotPending = 2
                    4 -> fast = !fast
                    5 -> pendingAction = { showGraphics() }
                    6 -> {
                        val on = !touchOn
                        prefs.edit().putBoolean("touch", on).apply()
                        touchPad?.visibility = if (on) View.VISIBLE else View.GONE
                    }
                    7 -> pendingAction = { showOpacity() }
                    8 -> pendingAction = { startLayoutEdit() }
                    9 -> {
                        val quick = turboHalf != 1
                        prefs.edit().putBoolean("turbo_fast", quick).apply()
                        turboHalf = if (quick) 1 else 2
                    }
                    10 -> remapPending = true
                    11 -> infoPending = true
                    12 -> finish()
                }
            }
            .setOnDismissListener {
                menuOpen = false
                val act = pendingAction
                pendingAction = null
                if (act != null) act()
                else if (slotPending != 0) { val op = slotPending; slotPending = 0; showSlots(op) }
                else if (remapPending) { remapPending = false; showRemapList() }
                else if (infoPending) { infoPending = false; showInfo() }
                else paused = false
            }
            .show()
    }

    // ---------- graphics options ----------
    private fun showGraphics() {
        val g = gfx
        menuOpen = true
        paused = true
        val items = arrayOf(
            "Picture style: " + g.presetName() + "...",
            "Fine-tune effects...",
            "Aspect ratio: " + GfxPresets.ASPECTS[g.aspect],
            "Show FPS counter: " + (if (g.showFps) "ON" else "OFF"),
            "Done"
        )
        AlertDialog.Builder(this)
            .setTitle("Graphics")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> pendingAction = { showStyles() }
                    1 -> pendingAction = { showTune() }
                    2 -> {
                        g.aspect = (g.aspect + 1) % GfxPresets.ASPECTS.size
                        g.commit()
                        pendingAction = { showGraphics() }
                    }
                    3 -> {
                        g.showFps = !g.showFps
                        g.commit()
                        fpsView?.visibility = if (g.showFps) View.VISIBLE else View.GONE
                        pendingAction = { showGraphics() }
                    }
                }
            }
            .setOnDismissListener {
                menuOpen = false
                val act = pendingAction
                pendingAction = null
                if (act != null) act() else paused = false
            }
            .show()
    }

    private fun showStyles() {
        val g = gfx
        menuOpen = true
        paused = true
        AlertDialog.Builder(this)
            .setTitle("Picture style")
            .setSingleChoiceItems(GfxPresets.NAMES, if (g.preset in GfxPresets.NAMES.indices) g.preset else -1) { d, which ->
                g.applyPreset(which)
                d.dismiss()
            }
            .setOnDismissListener { menuOpen = false; showGraphics() }
            .show()
    }

    private fun showTune() {
        val g = gfx
        menuOpen = true
        paused = true
        val snap = g.snapshot()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 10)
        }
        fun row(title: String, value: Int, set: (Int) -> Unit) {
            val label = TextView(this).apply {
                text = "$title: $value%"
                textSize = 16f
                setPadding(0, 16, 0, 0)
            }
            val bar = SeekBar(this).apply {
                max = 100
                progress = value
                keyProgressIncrement = 5
            }
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = "$title: $p%"
                    set(p)
                    g.preview()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            box.addView(label)
            box.addView(bar)
        }
        row("Scanlines", g.scan) { g.scan = it }
        row("Phosphor mask", g.mask) { g.mask = it }
        row("Screen curve", g.curve) { g.curve = it }
        row("Blur (composite TV)", g.blur) { g.blur = it }
        row("Vignette (dark corners)", g.vig) { g.vig = it }
        val sharp = CheckBox(this).apply {
            text = "Sharp pixel scaling"
            isChecked = g.sharp == 1
        }
        sharp.setOnCheckedChangeListener { _, c -> g.sharp = if (c) 1 else 0; g.preview() }
        box.addView(sharp)
        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this)
            .setTitle("Fine-tune effects")
            .setView(scroll)
            .setPositiveButton("OK") { _, _ -> g.commit() }
            .setNegativeButton("Cancel") { _, _ -> g.restore(snap) }
            .setOnCancelListener { g.restore(snap) }
            .setOnDismissListener { menuOpen = false; showGraphics() }
            .show()
    }

    // ---------- touch pad options ----------
    private fun showOpacity() {
        val tp = touchPad ?: return
        menuOpen = true
        paused = true
        if (tp.visibility != View.VISIBLE) {
            prefs.edit().putBoolean("touch", true).apply()
            tp.visibility = View.VISIBLE
        }
        val start = prefs.getInt("touch_alpha", 45)
        val label = TextView(this).apply {
            text = "$start%"
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 8)
        }
        val bar = SeekBar(this).apply {
            max = 90
            progress = start - 10
            setPadding(48, 24, 48, 24)
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "${p + 10}%"
                tp.opacity = (p + 10) / 100f
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label)
            addView(bar)
        }
        AlertDialog.Builder(this)
            .setTitle("Touch button opacity")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> prefs.edit().putInt("touch_alpha", bar.progress + 10).apply() }
            .setNegativeButton("Cancel") { _, _ -> tp.opacity = start / 100f }
            .setOnCancelListener { tp.opacity = start / 100f }
            .setOnDismissListener { menuOpen = false; paused = false }
            .show()
    }

    private fun startLayoutEdit() {
        val tp = touchPad ?: return
        prefs.edit().putBoolean("touch", true).apply()
        tp.visibility = View.VISIBLE
        paused = true
        tp.startEdit { paused = false }
    }

    private fun toast(m: String) {
        runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    // ---------- save states / info ----------
    private fun showSlots(op: Int) {
        menuOpen = true
        paused = true
        val fmt = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        val labels = Array(10) { i ->
            val t = SaveStore.modified(saveDirs, "$safeName.st$i")
            "Slot ${i + 1}:   " + (if (t == null) "empty" else fmt.format(Date(t)))
        }
        AlertDialog.Builder(this)
            .setTitle(if (op == 1) "Save state" else "Load state")
            .setItems(labels) { _, which -> stateSlot = which; stateOp = op }
            .setOnDismissListener { menuOpen = false; paused = false }
            .show()
    }

    private fun showInfo() {
        val n = nes ?: return
        val r = n.rom
        menuOpen = true
        paused = true
        val msg = "Mapper ${r.mapperId} (submapper ${r.submapper}), PRG ${r.prg.size / 1024}K, " +
            "CHR ${r.chr.size / 1024}K" + (if (r.chrRam) " RAM" else "") + ", battery flag=${r.battery}\n" +
            n.mapper.debugInfo() + "\nSave folder: ${saveDirs.firstOrNull()?.absolutePath}" +
            (if (saveDirs.size == 1 && saveDirs[0].absolutePath.startsWith(filesDir.absolutePath)) "  (inside app: lost on uninstall)" else "  (+${saveDirs.size - 1} more copies)") +
            "\nCPU PC=%04X  ".format(n.debugPc()) + n.ppu.debug()
        AlertDialog.Builder(this)
            .setTitle("Info")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .setOnDismissListener { menuOpen = false; paused = false }
            .show()
    }

    // ---------- button remapping (every button, including directions) ----------
    private fun showRemapList() {
        menuOpen = true
        paused = true
        val count = InputMap.NAMES.size
        val items = ArrayList<String>()
        items.add("Guided setup (all buttons in order)")
        for (i in 0 until count) items.add(InputMap.NAMES[i] + ":   " + input.labelFor(InputMap.WIZARD_BITS[i]))
        items.add("Reset all to defaults")
        remapChoice = -1
        AlertDialog.Builder(this)
            .setTitle("Remap buttons")
            .setItems(items.toTypedArray()) { _, which -> remapChoice = which }
            .setOnDismissListener {
                menuOpen = false
                val c = remapChoice
                remapChoice = -1
                when {
                    c == 0 -> startWizard()
                    c in 1..count -> startSingle(c - 1)
                    c == count + 1 -> { input.reset(); toast("Controls reset to defaults"); showRemapList() }
                    else -> paused = false
                }
            }
            .show()
    }

    private fun startWizard() {
        wizSingle = false
        wizStep = 0
        wizMap.clear()
        wizMap.putAll(input.custom())
        paused = true
        showWizardText(null)
    }

    private fun startSingle(i: Int) {
        wizSingle = true
        wizStep = i
        wizMap.clear()
        wizMap.putAll(input.custom())
        paused = true
        showWizardText(null)
    }

    private fun showWizardText(extra: String?) {
        val o = overlay ?: return
        o.visibility = View.VISIBLE
        val name = InputMap.NAMES[wizStep]
        val now = input.labelFor(InputMap.WIZARD_BITS[wizStep])
        o.text = "Press the key to use for  $name\n(now: $now)\n" +
            (if (wizSingle) "Back = cancel"
            else "(" + (wizStep + 1) + " of " + InputMap.NAMES.size + ")   Back = finish and keep the rest") +
            (if (extra != null) "\n$extra" else "")
    }

    private fun endWizard(resume: Boolean) {
        wizStep = -1
        overlay?.visibility = View.GONE
        if (resume) paused = false
    }

    private fun handleWizard(e: KeyEvent) {
        if (e.action != KeyEvent.ACTION_DOWN || e.repeatCount > 0) return
        val kc = e.keyCode
        if (kc == KeyEvent.KEYCODE_BACK) {
            if (wizSingle) {
                endWizard(false)
                showRemapList()
            } else {
                input.save(wizMap)
                endWizard(true)
                Toast.makeText(this, "Controls saved", Toast.LENGTH_SHORT).show()
            }
            return
        }
        val bit = InputMap.WIZARD_BITS[wizStep]
        wizMap.entries.removeAll { it.value == bit || it.key == kc }
        wizMap[kc] = bit
        if (wizSingle) {
            input.save(wizMap)
            endWizard(false)
            showRemapList()
        } else {
            wizStep++
            if (wizStep >= InputMap.WIZARD_BITS.size) {
                input.save(wizMap)
                endWizard(true)
                Toast.makeText(this, "Controls saved", Toast.LENGTH_SHORT).show()
            } else showWizardText(null)
        }
    }
}
