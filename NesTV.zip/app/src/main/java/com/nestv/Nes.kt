package com.nestv

class Nes(val rom: Rom) {
    val mapper: Mapper = createMapper(rom)
    val ppu = Ppu(mapper)
    val apu = Apu(this)
    private val cpu = Cpu(this)
    private val ram = IntArray(0x800)

    @Volatile var pad = 0
    var stall = 0
    private var strobe = false
    private var shiftReg = 0
    private var apuPending = 0

    init { cpu.reset() }

    fun debugPc() = cpu.pcValue()

    fun irqLine() = mapper.irq || apu.irq

    private fun syncApu() {
        if (apuPending > 0) {
            val p = apuPending
            apuPending = 0
            apu.step(p)
        }
    }

    fun read(a: Int): Int = when {
        a >= 0x8000 -> mapper.cpuRead(a)
        a < 0x2000 -> ram[a and 0x7FF]
        a < 0x4000 -> ppu.readReg(a and 7)
        a == 0x4015 -> { syncApu(); apu.readStatus() }
        a == 0x4016 -> {
            if (strobe) (pad and 1) or 0x40
            else {
                val b = shiftReg and 1
                shiftReg = (shiftReg shr 1) or 0x80
                b or 0x40
            }
        }
        a < 0x4020 -> 0
        else -> mapper.cpuRead(a)
    }

    fun write(a: Int, v: Int) {
        when {
            a >= 0x4020 -> mapper.cpuWrite(a, v)
            a < 0x2000 -> ram[a and 0x7FF] = v
            a < 0x4000 -> ppu.writeReg(a and 7, v)
            a == 0x4014 -> {
                val base = v shl 8
                for (i in 0 until 256) ppu.dmaWrite(read(base + i))
                stall += 513
            }
            a == 0x4016 -> {
                strobe = (v and 1) != 0
                if (strobe) shiftReg = pad
            }
            a < 0x4018 -> { syncApu(); apu.write(a, v) }
        }
    }

    fun runFrame() {
        ppu.frameReady = false
        while (!ppu.frameReady) {
            var c = cpu.step()
            if (stall > 0) { c += stall; stall = 0 }
            mapper.cpuClock(c)
            apuPending += c
            if (apuPending >= 32) {
                val p = apuPending
                apuPending = 0
                apu.step(p)
            }
            ppu.step(c * 3)
        }
    }
}
