package com.nestv

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** D-pad friendly ROM list for Google TV. */
class MainActivity : Activity() {
    private class Item(val label: String, val file: File?, val action: Int) // 0 rom, 1 picker, 2 all-files permission, 3 choose folder, 4 open dir, 5 use dir, 6 up, 7 info

    private val items = ArrayList<Item>()
    private var browse = false
    private var cur: File? = null
    private val prefs by lazy { getSharedPreferences("nestv", Context.MODE_PRIVATE) }
    private lateinit var list: ListView
    private lateinit var hint: TextView

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val tv = (convertView as? TextView) ?: TextView(this@MainActivity).apply {
                textSize = 22f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(32, 22, 32, 22)
            }
            tv.text = items[position].label
            return tv
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(96, 48, 96, 48)
            setBackgroundColor(0xFF101010.toInt())
        }
        root.addView(TextView(this).apply {
            text = "NES TV"
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
        })
        hint = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFAAAAAA.toInt())
            setPadding(0, 8, 0, 24)
        }
        root.addView(hint)
        list = ListView(this)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onItem(items[pos]) }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT in 23..32 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
    }

    override fun onResume() {
        super.onResume()
        if (browse) showBrowse() else refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (browse) showBrowse() else refresh()
    }

    private fun romDir(): File? {
        val base = getExternalFilesDir(null) ?: return null
        val d = File(base, "roms")
        d.mkdirs()
        return d
    }

    private fun refresh() {
        items.clear()
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        if (picker.resolveActivity(packageManager) != null) items.add(Item("Open file picker...", null, 1))
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager())
            items.add(Item("Allow access to all files (shows ROMs in Download, USB...)", null, 2))

        items.add(Item("Choose ROM folder...", null, 3))

        val roots = LinkedHashSet<File>()
        prefs.getString("romdir", null)?.let { roots.add(File(it)) }
        romDir()?.let { roots.add(it) }
        @Suppress("DEPRECATION")
        val ext = Environment.getExternalStorageDirectory()
        for (n in listOf("Roms", "ROMs", "roms", "NES", "nes", "Download", "Downloads")) roots.add(File(ext, n))
        File("/storage").listFiles()?.forEach { if (it.name != "emulated" && it.name != "self") roots.add(it) }

        val found = ArrayList<File>()
        for (r in roots) walk(r, 0, found)
        found.sortBy { it.name.lowercase() }
        for (f in found) items.add(Item(f.name, f, 0))

        hint.text = "ROM folder: ${prefs.getString("romdir", null) ?: romDir()?.absolutePath ?: "?"}\n" +
            "Use 'Choose ROM folder' to pick any folder (internal storage or USB stick). Back button inside a game opens the menu."
        adapter.notifyDataSetChanged()
        list.requestFocus()
    }

    private fun walk(dir: File, depth: Int, out: ArrayList<File>) {
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (out.size >= 500) return
            if (f.isDirectory) { if (depth < 3) walk(f, depth + 1, out) }
            else {
                val n = f.name.lowercase()
                if (n.endsWith(".nes") || n.endsWith(".zip")) out.add(f)
            }
        }
    }

    private fun showBrowse() {
        browse = true
        items.clear()
        val c = cur
        if (c == null) {
            hint.text = "Choose where your ROMs are. Pick a storage location:"
            @Suppress("DEPRECATION")
            val ext = Environment.getExternalStorageDirectory()
            items.add(Item("Internal storage  (${ext.absolutePath})", ext, 4))
            romDir()?.let { items.add(Item("App folder  (${it.absolutePath})", it, 4)) }
            File("/storage").listFiles()?.forEach {
                if (it.name != "emulated" && it.name != "self") items.add(Item("USB / SD card: ${it.name}", it, 4))
            }
            items.add(Item("Cancel", null, 7))
        } else {
            hint.text = "Browsing: ${c.absolutePath}"
            items.add(Item("USE THIS FOLDER", c, 5))
            items.add(Item(".. (up)", c.parentFile, 6))
            val dirs = c.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name.lowercase() }
            if (dirs == null) items.add(Item("Cannot read this folder (try 'Allow access to all files')", null, 7))
            else for (d in dirs) items.add(Item(d.name + "/", d, 4))
        }
        adapter.notifyDataSetChanged()
        list.setSelection(0)
        list.requestFocus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (browse) {
            val p = cur?.parentFile
            if (cur == null) { browse = false; refresh() } else { cur = if (p != null && p.canRead()) p else null; showBrowse() }
        } else super.onBackPressed()
    }

    private fun onItem(it: Item) {
        when (it.action) {
            3 -> { cur = null; showBrowse() }
            4 -> { cur = it.file; showBrowse() }
            5 -> {
                prefs.edit().putString("romdir", it.file!!.absolutePath).apply()
                browse = false
                refresh()
                Toast.makeText(this, "ROM folder set", Toast.LENGTH_SHORT).show()
            }
            6 -> {
                val p = it.file
                cur = if (p != null && p.canRead()) p else null
                showBrowse()
            }
            7 -> { if (browse) { browse = false; refresh() } }
            0 -> startActivity(Intent(this, EmuActivity::class.java).putExtra("path", it.file!!.absolutePath))
            1 -> {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                startActivityForResult(i, 42)
            }
            2 -> {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    } catch (e2: Exception) {
                        Toast.makeText(this, "Not available on this device. Use the ROM folder shown above.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 42 && resultCode == RESULT_OK && uri != null) {
            val i = Intent(this, EmuActivity::class.java)
            i.data = uri
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            i.putExtra("name", RomLoader.displayName(this, uri))
            startActivity(i)
        }
    }
}
