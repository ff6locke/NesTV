package com.nestv

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView

/**
 * One settings screen with a dropdown (or slider) for every option, so a value can be picked directly instead of being
 * cycled with repeated taps. Used both on the start screen and inside a game; [onApply] is called after every change so a
 * running game can pick it up straight away.
 */
class SettingsPanel(
    private val act: Activity,
    private val gfx: GfxSettings,
    private val inGame: Boolean,
    private val onRemap: () -> Unit,
    private val onEditLayout: (() -> Unit)?,
    private val onApply: () -> Unit,
    private val onClose: () -> Unit
) {
    private val prefs = act.getSharedPreferences("nestv", Context.MODE_PRIVATE)
    private val isTv = act.packageManager.hasSystemFeature("android.software.leanback") ||
        act.packageManager.hasSystemFeature("android.hardware.type.television")
    private val holder = ScrollView(act)
    private var pending: (() -> Unit)? = null
    private lateinit var dialog: AlertDialog

    fun show() {
        holder.addView(makeBox())
        dialog = AlertDialog.Builder(act)
            .setTitle("Settings")
            .setView(holder)
            .setPositiveButton("Close", null)
            .setOnDismissListener {
                gfx.commit()
                onApply()
                val p = pending
                pending = null
                if (p != null) p() else onClose()
            }
            .create()
        dialog.show()
    }

    private fun rebuild() {
        val y = holder.scrollY
        holder.removeAllViews()
        holder.addView(makeBox())
        holder.post { holder.scrollTo(0, y) }
    }

    private fun header(box: LinearLayout, t: String) {
        box.addView(TextView(act).apply {
            text = t
            textSize = 18f
            setTextColor(0xFFFFC107.toInt())
            setPadding(0, 30, 0, 4)
        })
    }

    private fun spinner(box: LinearLayout, title: String, names: Array<String>, current: Int, onPick: (Int) -> Unit) {
        box.addView(TextView(act).apply { text = title; textSize = 14f; setPadding(0, 14, 0, 0) })
        val sp = Spinner(act)
        val ad = ArrayAdapter(act, android.R.layout.simple_spinner_item, names)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        val start = current.coerceIn(0, names.size - 1)
        sp.setSelection(start, false)
        var last = start
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != last) {
                    last = pos
                    onPick(pos)
                    onApply()
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        box.addView(sp)
    }

    private fun slider(box: LinearLayout, title: String, value: Int, lo: Int, hi: Int, unit: String, onPick: (Int) -> Unit) {
        val label = TextView(act).apply { text = "$title: $value$unit"; textSize = 14f; setPadding(0, 14, 0, 0) }
        val bar = SeekBar(act)
        bar.max = hi - lo
        bar.progress = value - lo
        bar.keyProgressIncrement = maxOf(1, (hi - lo) / 20)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                label.text = "$title: $v$unit"
                if (fromUser) {
                    onPick(v)
                    onApply()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(label)
        box.addView(bar)
    }

    private fun button(box: LinearLayout, title: String, action: () -> Unit) {
        box.addView(Button(act).apply {
            text = title
            setOnClickListener { pending = action; dialog.dismiss() }
        })
    }

    private fun yesNo(b: Boolean) = if (b) 0 else 1

    private fun makeBox(): LinearLayout {
        val g = gfx
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 8, 40, 16)
        }
        val onOff = arrayOf("On", "Off")

        header(box, "Graphics")
        val styleNames = Array(GfxPresets.NAMES.size + 1) { i -> if (i < GfxPresets.NAMES.size) GfxPresets.NAMES[i] else "Custom" }
        spinner(box, "Picture style", styleNames, if (g.preset in GfxPresets.NAMES.indices) g.preset else GfxPresets.NAMES.size) { i ->
            if (i < GfxPresets.NAMES.size) { g.applyPreset(i); rebuild() }
        }
        spinner(box, "Aspect ratio", GfxPresets.ASPECTS, g.aspect) { g.aspect = it; g.commit() }
        spinner(box, "Frame skip", arrayOf("Off", "Auto (only when slow)", "Every 2nd frame", "2 of every 3 frames"),
            prefs.getInt("frameskip", 1)) { prefs.edit().putInt("frameskip", it).apply() }
        spinner(box, "Accurate mid-line drawing", onOff, yesNo(prefs.getBoolean("accurate", true))) {
            prefs.edit().putBoolean("accurate", it == 0).apply()
        }
        spinner(box, "Show FPS counter", onOff, yesNo(g.showFps)) { g.showFps = it == 0; g.commit() }
        slider(box, "Scanlines", g.scan, 0, 100, "%") { g.scan = it; g.preview() }
        slider(box, "Phosphor mask", g.mask, 0, 100, "%") { g.mask = it; g.preview() }
        slider(box, "Screen curve", g.curve, 0, 100, "%") { g.curve = it; g.preview() }
        slider(box, "Blur (composite TV)", g.blur, 0, 100, "%") { g.blur = it; g.preview() }
        slider(box, "Vignette (dark corners)", g.vig, 0, 100, "%") { g.vig = it; g.preview() }
        spinner(box, "Sharp pixel scaling", onOff, yesNo(g.sharp == 1)) { g.sharp = if (it == 0) 1 else 0; g.preview() }
        slider(box, "Split-screen timing", prefs.getInt("irq_offset", 0), -100, 100, " cycles") {
            prefs.edit().putInt("irq_offset", it).apply()
        }

        header(box, "Speed")
        val ffValues = intArrayOf(2, 3, 4, 0)
        spinner(box, "Fast forward speed", arrayOf("2x", "3x", "4x", "As fast as possible"),
            ffValues.indexOf(prefs.getInt("ff_speed", 3)).coerceAtLeast(0)) { prefs.edit().putInt("ff_speed", ffValues[it]).apply() }
        spinner(box, "Rapid fire speed", arrayOf("15 per second", "30 per second"),
            if (prefs.getBoolean("turbo_fast", false)) 1 else 0) { prefs.edit().putBoolean("turbo_fast", it == 1).apply() }

        header(box, "Touch controls")
        spinner(box, "Touch controls", onOff, yesNo(prefs.getBoolean("touch", !isTv))) {
            prefs.edit().putBoolean("touch", it == 0).apply()
        }
        spinner(box, "Touch theme", TouchThemes.NAMES, prefs.getInt("touch_theme", 0)) {
            prefs.edit().putInt("touch_theme", it).apply()
        }
        slider(box, "Touch opacity", prefs.getInt("touch_alpha", 45), 10, 100, "%") {
            prefs.edit().putInt("touch_alpha", it).apply()
        }
        val edit = onEditLayout
        if (inGame && edit != null) button(box, "Move / resize touch buttons...") { edit() }

        header(box, "Controls")
        button(box, "Remap buttons...") { onRemap() }
        return box
    }
}

/** Colour sets for the on-screen touch controller. Colours are RGB; opacity is applied separately. */
class TouchTheme(
    val name: String,
    val dpad: Int, val a: Int, val b: Int, val ta: Int, val tb: Int, val pill: Int, val menu: Int,
    val text: Int,
    val stroke: Int,       // -1 = use each control's own colour for its outline
    val fillK: Float,      // how solid the idle fill is (0 = outline only)
    val square: Boolean    // rounded squares instead of circles for A / B / turbo
)

object TouchThemes {
    val LIST = arrayOf(
        TouchTheme("Classic (glass)", 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 1f, false),
        TouchTheme("Dark", 0x303030, 0x303030, 0x303030, 0x303030, 0x303030, 0x303030, 0x303030, 0xFFFFFF, 0xFFFFFF, 2.2f, false),
        TouchTheme("NES controller", 0x2B2B2B, 0xC62828, 0xC62828, 0x8E1B1B, 0x8E1B1B, 0x6B6B6B, 0x2B2B2B, 0xFFFFFF, 0xE0E0E0, 2.4f, false),
        TouchTheme("Colour buttons", 0x707070, 0xD32F2F, 0xF9A825, 0x388E3C, 0x1976D2, 0x707070, 0x505050, 0xFFFFFF, 0xFFFFFF, 2.2f, false),
        TouchTheme("Neon", 0x00E5FF, 0xFF4081, 0xFFEA00, 0x69F0AE, 0xB388FF, 0x00E5FF, 0x00E5FF, 0xFFFFFF, -1, 0.4f, false),
        TouchTheme("Outline only", 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0f, false),
        TouchTheme("Square buttons", 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 1f, true)
    )
    val NAMES: Array<String> = Array(LIST.size) { LIST[it].name }
}
