package com.nestv

/** 2A03 CPU core (official opcodes plus the common undocumented ones). step() returns the cycles used. */
class Cpu(private val nes: Nes) {
    private var a = 0
    private var x = 0
    private var y = 0
    private var sp = 0xFD
    private var pc = 0
    private var fC = 0
    private var fZ = 0
    private var fI = 1
    private var fD = 0
    private var fV = 0
    private var fN = 0
    private var cyc = 0

    private val cRead = intArrayOf(6, 3, 2, 4, 5, 4, 4, 4, 4)
    private val cWrite = intArrayOf(6, 3, 2, 4, 6, 4, 5, 5, 4)
    private val cRmw = intArrayOf(8, 5, 2, 6, 8, 6, 7, 7, 6)

    fun pcValue() = pc

    fun reset() {
        pc = rd(0xFFFC) or (rd(0xFFFD) shl 8)
        sp = 0xFD
        setP(0x24)
    }

    private fun rd(ad: Int) = nes.read(ad)
    private fun wr(ad: Int, v: Int) = nes.write(ad, v)

    private fun fetch(): Int {
        val v = rd(pc)
        pc = (pc + 1) and 0xFFFF
        return v
    }

    private fun push(v: Int) { wr(0x100 + sp, v); sp = (sp - 1) and 0xFF }
    private fun pull(): Int { sp = (sp + 1) and 0xFF; return rd(0x100 + sp) }

    private fun getP(b: Int) = fC or (fZ shl 1) or (fI shl 2) or (fD shl 3) or b or 0x20 or (fV shl 6) or (fN shl 7)

    private fun setP(v: Int) {
        fC = v and 1; fZ = (v shr 1) and 1; fI = (v shr 2) and 1
        fD = (v shr 3) and 1; fV = (v shr 6) and 1; fN = (v shr 7) and 1
    }

    private fun nz(v: Int) { fZ = if (v == 0) 1 else 0; fN = (v shr 7) and 1 }

    private fun interrupt(vec: Int, brk: Boolean) {
        push(pc shr 8)
        push(pc and 0xFF)
        push(getP(if (brk) 0x10 else 0))
        fI = 1
        pc = rd(vec) or (rd(vec + 1) shl 8)
    }

    private fun adc(v: Int) {
        val s = a + v + fC
        fV = if (((a xor s) and (v xor s) and 0x80) != 0) 1 else 0
        fC = if (s > 0xFF) 1 else 0
        a = s and 0xFF
        nz(a)
    }

    private fun cmp(r: Int, v: Int) {
        fC = if (r >= v) 1 else 0
        nz((r - v) and 0xFF)
    }

    /** Effective address. kind: 0 read, 1 write, 2 read-modify-write. */
    private fun ea(mode: Int, kind: Int): Int {
        when (mode) {
            2 -> { val r = pc; pc = (pc + 1) and 0xFFFF; return r }
            1 -> return fetch()
            5 -> return (fetch() + x) and 0xFF
            8 -> return (fetch() + y) and 0xFF
            3 -> { val lo = fetch(); return lo or (fetch() shl 8) }
            7, 6 -> {
                val lo = fetch()
                val base = lo or (fetch() shl 8)
                val r = (base + (if (mode == 7) x else y)) and 0xFFFF
                if (kind == 0 && (base and 0xFF00) != (r and 0xFF00)) cyc++
                return r
            }
            0 -> {
                val z = (fetch() + x) and 0xFF
                return rd(z) or (rd((z + 1) and 0xFF) shl 8)
            }
            else -> {
                val z = fetch()
                val base = rd(z) or (rd((z + 1) and 0xFF) shl 8)
                val r = (base + y) and 0xFFFF
                if (kind == 0 && (base and 0xFF00) != (r and 0xFF00)) cyc++
                return r
            }
        }
    }

    private fun base(mode: Int, kind: Int) = when (kind) {
        0 -> cRead[mode]
        1 -> cWrite[mode]
        else -> cRmw[mode]
    }

    fun step(): Int {
        if (nes.ppu.nmi) {
            nes.ppu.nmi = false
            interrupt(0xFFFA, false)
            return 7
        }
        if (fI == 0 && nes.irqLine()) {
            interrupt(0xFFFE, false)
            return 7
        }
        cyc = 0
        val op = fetch()
        val bbb = (op shr 2) and 7
        val aaa = op shr 5
        when (op and 3) {
            1 -> g1(aaa, bbb)
            2 -> g2(aaa, bbb)
            0 -> g0(aaa, bbb)
            else -> g3(aaa, bbb)
        }
        return cyc
    }

    private fun g1(aaa: Int, bbb: Int) {
        val kind = if (aaa == 4) 1 else 0
        cyc = base(bbb, kind)
        val ad = ea(bbb, kind)
        when (aaa) {
            0 -> { a = a or rd(ad); nz(a) }
            1 -> { a = a and rd(ad); nz(a) }
            2 -> { a = a xor rd(ad); nz(a) }
            3 -> adc(rd(ad))
            4 -> if (bbb != 2) wr(ad, a)
            5 -> { a = rd(ad); nz(a) }
            6 -> cmp(a, rd(ad))
            else -> adc(rd(ad) xor 0xFF)
        }
    }

    /** Shift/rotate/inc/dec helper shared by group 2 and the undocumented RMW opcodes. */
    private fun rmw(aaa: Int, v: Int): Int {
        val r = when (aaa) {
            0 -> { fC = v shr 7; (v shl 1) and 0xFF }
            1 -> { val c = fC; fC = v shr 7; ((v shl 1) or c) and 0xFF }
            2 -> { fC = v and 1; v shr 1 }
            3 -> { val c = fC; fC = v and 1; (v shr 1) or (c shl 7) }
            6 -> (v - 1) and 0xFF
            else -> (v + 1) and 0xFF
        }
        nz(r)
        return r
    }

    private fun g2(aaa: Int, bbb: Int) {
        when (bbb) {
            2 -> {
                cyc = 2
                when (aaa) {
                    0, 1, 2, 3 -> a = rmw(aaa, a)
                    4 -> { a = x; nz(a) }
                    5 -> { x = a; nz(x) }
                    6 -> { x = (x - 1) and 0xFF; nz(x) }
                    else -> {}
                }
            }
            4 -> cyc = 2
            6 -> {
                cyc = 2
                if (aaa == 4) sp = x else if (aaa == 5) { x = sp; nz(x) }
            }
            else -> {
                val mode = when (bbb) {
                    0 -> 2
                    1 -> 1
                    3 -> 3
                    5 -> if (aaa == 4 || aaa == 5) 8 else 5
                    else -> if (aaa == 5) 6 else 7
                }
                val kind = if (aaa == 5) 0 else if (aaa == 4) 1 else 2
                cyc = base(mode, kind)
                val ad = ea(mode, kind)
                when (aaa) {
                    4 -> if (bbb != 0 && bbb != 7) wr(ad, x)
                    5 -> { x = rd(ad); nz(x) }
                    else -> if (bbb != 0) wr(ad, rmw(aaa, rd(ad)))
                }
            }
        }
    }

    private fun g0(aaa: Int, bbb: Int) {
        when (bbb) {
            4 -> {
                cyc = 2
                val off = fetch().toByte().toInt()
                val flag = when (aaa shr 1) { 0 -> fN; 1 -> fV; 2 -> fC; else -> fZ }
                if (flag == (aaa and 1)) {
                    cyc++
                    val np = (pc + off) and 0xFFFF
                    if ((np and 0xFF00) != (pc and 0xFF00)) cyc++
                    pc = np
                }
            }
            2 -> when (aaa) {
                0 -> { cyc = 3; push(getP(0x10)) }
                1 -> { cyc = 4; setP(pull()) }
                2 -> { cyc = 3; push(a) }
                3 -> { cyc = 4; a = pull(); nz(a) }
                4 -> { cyc = 2; y = (y - 1) and 0xFF; nz(y) }
                5 -> { cyc = 2; y = a; nz(y) }
                6 -> { cyc = 2; y = (y + 1) and 0xFF; nz(y) }
                else -> { cyc = 2; x = (x + 1) and 0xFF; nz(x) }
            }
            6 -> {
                cyc = 2
                when (aaa) {
                    0 -> fC = 0
                    1 -> fC = 1
                    2 -> fI = 0
                    3 -> fI = 1
                    4 -> { a = y; nz(a) }
                    5 -> fV = 0
                    6 -> fD = 0
                    else -> fD = 1
                }
            }
            else -> {
                if (bbb == 0 && aaa < 4) {
                    when (aaa) {
                        0 -> { cyc = 7; fetch(); interrupt(0xFFFE, true) }
                        1 -> {
                            cyc = 6
                            val lo = fetch()
                            push(pc shr 8)
                            push(pc and 0xFF)
                            pc = lo or (rd(pc) shl 8)
                        }
                        2 -> { cyc = 6; setP(pull()); pc = pull() or (pull() shl 8) }
                        else -> { cyc = 6; pc = ((pull() or (pull() shl 8)) + 1) and 0xFFFF }
                    }
                    return
                }
                if (bbb == 3 && aaa == 2) { cyc = 3; pc = fetch() or (fetch() shl 8); return }
                if (bbb == 3 && aaa == 3) {
                    cyc = 5
                    val p = fetch() or (fetch() shl 8)
                    val lo = rd(p)
                    val hi = rd((p and 0xFF00) or ((p + 1) and 0xFF))
                    pc = lo or (hi shl 8)
                    return
                }
                val mode = when (bbb) { 0 -> 2; 1 -> 1; 3 -> 3; 5 -> 5; else -> 7 }
                val kind = if (aaa == 4) 1 else 0
                cyc = base(mode, kind)
                val ad = ea(mode, kind)
                when (aaa) {
                    1 -> if (bbb == 1 || bbb == 3) {
                        val v = rd(ad)
                        fZ = if ((a and v) == 0) 1 else 0
                        fN = (v shr 7) and 1
                        fV = (v shr 6) and 1
                    }
                    4 -> if (bbb != 0 && bbb != 7) wr(ad, y)
                    5 -> { y = rd(ad); nz(y) }
                    6 -> cmp(y, rd(ad))
                    7 -> cmp(x, rd(ad))
                    else -> {}
                }
            }
        }
    }

    private fun g3(aaa: Int, bbb: Int) {
        val isY = aaa == 4 || aaa == 5
        val mode = when (bbb) {
            5 -> if (isY) 8 else 5
            7 -> if (isY) 6 else 7
            else -> bbb
        }
        val kind = if (aaa == 5) 0 else if (aaa == 4) 1 else 2
        cyc = base(mode, kind)
        val ad = ea(mode, kind)
        if (bbb == 2) { if (aaa == 7) adc(rd(ad) xor 0xFF); return }
        when (aaa) {
            4 -> wr(ad, a and x)
            5 -> { a = rd(ad); x = a; nz(a) }
            else -> {
                val r = rmw(aaa, rd(ad))
                wr(ad, r)
                when (aaa) {
                    0 -> { a = a or r; nz(a) }
                    1 -> { a = a and r; nz(a) }
                    2 -> { a = a xor r; nz(a) }
                    3 -> adc(r)
                    6 -> cmp(a, r)
                    else -> adc(r xor 0xFF)
                }
            }
        }
    }
}
