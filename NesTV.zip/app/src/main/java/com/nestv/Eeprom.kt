package com.nestv

/**
 * Bit-banged serial EEPROM used by Bandai mapper 16/159.
 * kind: 1 = 24C01 (128 bytes, no device address, bits sent least-significant first),
 *       2 = 24C02 (256 bytes, standard I2C, device address 0xA0),
 *       0 = auto-detect from the first byte the game sends after a START condition.
 */
class Eeprom(kind: Int) {
    val mem = ByteArray(256).also { it.fill(0xFF.toByte()) }

    private var small = kind == 1
    private var known = kind != 0

    // diagnostics
    var starts = 0
    var bytesWritten = 0
    var bytesRead = 0
    var rejected = 0
    val typeName: String get() = if (!known) "unknown yet" else if (small) "24C01" else "24C02"

    private var scl = 0
    private var sda = 1
    private var out = 1
    private var mode = 0      // 0 idle, 1 first byte, 2 word address, 3 write data, 4 read data
    private var phase = 0     // 0 data bits, 1 acknowledge bit
    private var bits = 0
    private var shift = 0
    private var addr = 0
    private var cur = 0
    private var ackOn = false
    private var ackOk = true
    private var nextMode = 0

    private fun limit() = if (small) 0x7F else 0xFF
    private fun bitOut() = if (small) (cur shr bits) and 1 else (cur shr (7 - bits)) and 1

    fun read(): Int = out

    fun write(nScl: Int, nSda: Int) {
        if (scl == 1 && nScl == 1 && sda != nSda) {
            if (nSda == 0) start() else stop()
        } else if (scl == 0 && nScl == 1) {
            rise(nSda)
        } else if (scl == 1 && nScl == 0) {
            fall()
        }
        scl = nScl
        sda = nSda
    }

    private fun start() {
        starts++
        mode = 1; phase = 0; bits = 0; shift = 0; ackOn = false; out = 1
    }

    private fun stop() {
        mode = 0; out = 1
    }

    private fun rise(bit: Int) {
        if (mode == 0) return
        if (phase == 0) {
            if (mode != 4) shift = ((shift shl 1) or bit) and 0xFF
            bits++
            if (bits == 8) {
                bits = 0
                phase = 1
                if (mode != 4) byteDone()
                else {
                    bytesRead++
                    // the internal address pointer advances after every byte sent, whether or not the game acknowledges it
                    addr = (addr + 1) and limit()
                }
            }
        } else if (mode == 4) {
            // master acknowledge
            if (bit == 0) {
                cur = mem[addr].toInt() and 0xFF
                phase = 0
            } else {
                mode = 0
            }
        }
    }

    private fun fall() {
        if (mode == 0) return
        if (phase == 1) {
            if (mode == 4) {
                out = 1
            } else if (!ackOn) {
                if (ackOk) out = 0
                ackOn = true
            } else {
                out = 1
                ackOn = false
                phase = 0
                mode = nextMode
                if (mode == 4) out = bitOut()
            }
        } else if (mode == 4) {
            out = bitOut()
        }
    }

    private fun byteDone() {
        ackOk = true
        when (mode) {
            1 -> {
                if (!known) { small = (shift and 0xF0) != 0xA0; known = true }
                if (small) {
                    var ad = 0
                    for (i in 0..6) ad = ad or (((shift shr (7 - i)) and 1) shl i)
                    addr = ad
                    if ((shift and 1) == 1) { cur = mem[addr].toInt() and 0xFF; nextMode = 4 } else nextMode = 3
                } else if ((shift and 0xF0) == 0xA0) {
                    if ((shift and 1) == 1) { cur = mem[addr].toInt() and 0xFF; nextMode = 4 } else nextMode = 2
                } else {
                    ackOk = false
                    rejected++
                    nextMode = 0
                }
            }
            2 -> {
                addr = shift and limit()
                nextMode = 3
            }
            3 -> {
                bytesWritten++
                if (small) {
                    mem[addr] = (Integer.reverse(shift) ushr 24).toByte()
                    addr = (addr + 1) and 0x7F
                } else {
                    mem[addr] = shift.toByte()
                    addr = (addr and 7.inv()) or ((addr + 1) and 7)
                }
                nextMode = 3
            }
        }
    }
}
