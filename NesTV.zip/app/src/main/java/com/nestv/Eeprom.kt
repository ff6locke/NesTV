package com.nestv

/** Bit-banged I2C serial EEPROM: 24C01 (128 bytes) or 24C02 (256 bytes), as used by Bandai mapper 16/159. */
class Eeprom(private val small: Boolean) {
    val mem = ByteArray(if (small) 128 else 256).also { it.fill(0xFF.toByte()) }

    private var scl = 0
    private var sda = 1
    private var out = 1
    private var mode = 0      // 0 idle, 1 device address, 2 word address, 3 write data, 4 read data
    private var phase = 0     // 0 data bits, 1 acknowledge bit
    private var bits = 0
    private var shift = 0
    private var addr = 0
    private var cur = 0
    private var ackOn = false
    private var ackOk = true
    private var nextMode = 0

    fun read(): Int = out

    fun write(nScl: Int, nSda: Int) {
        if (scl == 1 && nScl == 1 && sda != nSda) {
            if (nSda == 0) start() else stop()
        } else if (scl == 0 && nScl == 1) {
            rise(nSda)
        } else if (scl == 1 && nScl == 0) {
            fall()
        }
        scl = nScl
        sda = nSda
    }

    private fun start() {
        mode = 1; phase = 0; bits = 0; shift = 0; ackOn = false; out = 1
    }

    private fun stop() {
        mode = 0; out = 1
    }

    private fun rise(bit: Int) {
        if (mode == 0) return
        if (phase == 0) {
            if (mode != 4) shift = ((shift shl 1) or bit) and 0xFF
            bits++
            if (bits == 8) {
                bits = 0
                phase = 1
                if (mode != 4) byteDone()
            }
        } else if (mode == 4) {
            // master acknowledge
            if (bit == 0) {
                addr = (addr + 1) and (mem.size - 1)
                cur = mem[addr].toInt() and 0xFF
                phase = 0
            } else {
                mode = 0
            }
        }
    }

    private fun fall() {
        if (mode == 0) return
        if (phase == 1) {
            if (mode == 4) {
                out = 1
            } else if (!ackOn) {
                if (ackOk) out = 0
                ackOn = true
            } else {
                out = 1
                ackOn = false
                phase = 0
                mode = nextMode
                if (mode == 4) out = (cur shr 7) and 1
            }
        } else if (mode == 4) {
            out = (cur shr (7 - bits)) and 1
        }
    }

    private fun byteDone() {
        ackOk = true
        when (mode) {
            1 -> {
                if (small) {
                    addr = (shift shr 1) and (mem.size - 1)
                    if ((shift and 1) == 1) {
                        cur = mem[addr].toInt() and 0xFF
                        nextMode = 4
                    } else nextMode = 3
                } else if ((shift and 0xF0) == 0xA0) {
                    if ((shift and 1) == 1) {
                        cur = mem[addr].toInt() and 0xFF
                        nextMode = 4
                    } else nextMode = 2
                } else {
                    ackOk = false
                    nextMode = 0
                }
            }
            2 -> {
                addr = shift and (mem.size - 1)
                nextMode = 3
            }
            3 -> {
                mem[addr] = shift.toByte()
                addr = (addr and 7.inv()) or ((addr + 1) and 7)
                nextMode = 3
            }
        }
    }
}
