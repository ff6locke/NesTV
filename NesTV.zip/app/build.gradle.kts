plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nestv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nestv"
        minSdk = 21
        targetSdk = 34
        // GitHub's run number goes up with every build, so each build counts as a newer version
        val run = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionCode = run
        versionName = "1.0.$run"
    }

    // One fixed key for every build. Android only installs an update over an existing app when both are
    // signed with the same key (GitHub would otherwise sign each build with a new random debug key).
    signingConfigs {
        create("nestv") {
            storeFile = file("nestv.keystore")
            storePassword = "nestv123"
            keyAlias = "nestv"
            keyPassword = "nestv123"
        }
    }
    buildTypes {
        // The "debug" build is what the workflow produces (app-debug.apk). Make it a fast build:
        // not debuggable (Android runs debuggable apps noticeably slower) and optimised by R8.
        debug {
            signingConfig = signingConfigs.getByName("nestv")
            isDebuggable = false
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("nestv")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf("-Xno-param-assertions", "-Xno-call-assertions", "-Xno-receiver-assertions")
    }
}
