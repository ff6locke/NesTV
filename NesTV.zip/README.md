# NES TV

NES emulator for Google TV / Android TV (also runs on phones). Pure Kotlin, no dependencies.

## Build (GitHub Actions)
Push the contents of this folder to a GitHub repo (the `.github/workflows/build.yml` is included).
When the run finishes, download the `NesTV-debug-apk` artifact and sideload `app-debug.apk`
(adb install, or a "Downloader"/"Send files to TV" app).

Local: `gradle assembleDebug` (JDK 17, Gradle 8.7+, Android SDK 34).

## ROMs
- Copy `.nes` (or `.zip` containing one) to `Android/data/com.nestv/files/roms/`, or any folder on a USB stick.
- "Allow access to all files" in the list lets it see Download/Roms folders. "Open file picker" appears if the TV has a file picker.

## Remote (G60S) / controllers
- Put the G60S in key (D-pad) mode, not air-mouse mode; pair it in Settings > Remotes & accessories.
- First launch asks you to press the remote button to use for A, B, Select, Start. D-pad arrows work by default.
- Back (or gamepad Mode button) opens the pause menu: Resume, Reset, Fast forward, Remap, Exit.
- Bluetooth gamepads work out of the box (D-pad/hat/left stick, A/B/X/Y, Start, Select).

## Support
Mappers 0, 1, 2, 3, 4, 7, 9, 10, 11, 16 (Bandai FCG/LZ93D50 with 24C02 EEPROM), 21, 22, 23, 24, 25, 26, 34, 66, 69, 71, 73, 75, 79, 87, 140, 153 (Bandai, battery WRAM), 159 (24C01 EEPROM), 180, 184, 206.
Battery saves and save states (10 slots) are written to the ROM folder/saves, /sdcard/NesTV/saves and the app folder, so they survive an uninstall when storage access is allowed.
Not included: mapper 153/157 (Datach), PAL timing.

## Phones
An on-screen touch pad (D-pad, A, B, turbo A/B, Select, Start, menu button top-right) is shown automatically on non-TV devices.
In the pause menu: Touch controls on/off, Touch opacity (slider), Move / resize touch buttons (drag, Smaller/Bigger, Reset, Done), Rapid fire speed (15 or 30 Hz).
Turbo A/B can also be bound to remote keys via Remap; gamepads use R1 = turbo A, L1 = turbo B.

## Graphics
Pause menu > Graphics / CRT effects: picture style presets (sharp pixels, smooth, scanlines, CRT TV, old composite TV),
fine-tune sliders (scanlines, phosphor mask, screen curve, blur, vignette), aspect ratio (4:3, 8:7, fill) and an FPS counter.
The picture is drawn with an OpenGL ES 2 shader; if the full shader cannot be compiled the app falls back to a plain output.

## Remapping
Pause menu > Remap buttons: pick any single button (A, B, Select, Start, Up, Down, Left, Right, Turbo A, Turbo B) and press the key
or gamepad button to use, or run the guided setup. Remapped buttons lose their default keys; "Reset all" restores them.

## Extra key bindings
Remap buttons also lists: Open menu, Fast forward (toggle), Quick save state, Quick load state, Next/Previous save slot.
Quick save/load use the current slot (1-10, shown in a message when you change it, and set when you pick a slot in the menu).
Back / gamepad Mode always open the menu as well.

## Split-screen glitches
Graphics menu: "Accurate mid-line drawing" (ON = the picture follows register writes made part-way along a line;
OFF = each line is drawn from the state at its start) and "Split-screen timing" (shifts the cartridge IRQ earlier/later,
Bandai mapper 16/159). The timing slider is applied live while the game keeps running behind the dialog.

## Frame skip
Graphics menu > Frame skip: Off, Auto (skips drawing only while the device is behind), every 2nd frame, or 2 of every 3 frames.
Skipped frames are still fully emulated (sound, timing, game logic), just not drawn. Fast forward now draws only 1 frame in 4.

## Performance
The APK produced by `gradle assembleDebug` is built non-debuggable and optimised with R8 (see app/build.gradle.kts), because Android runs
debuggable apps much slower. Tile fetching and the CPU bus fast paths were also trimmed.

## Fast forward
Pause menu: "Fast forward" toggles it, "Fast forward speed" cycles 2x / 3x / 4x / Max. While it is on, frames are emulated at that speed but only
about 60 per second are drawn (the rest are emulated without drawing); sound is muted. A slow device simply tops out below the chosen speed.
When fast forward or pause ends, the audio buffer is refilled immediately.

## Remotes that only send two keys at once (e.g. G60S Pro)
Android can handle any number of held keys, but many remotes only transmit two at a time. Remap buttons > Input test shows how many keys the remote
really sends. Workarounds under Remap buttons:
- Combo buttons: one key presses several NES buttons (A+B, Right+B, Right+A+B, Left+A, Up+B ...).
- Hold buttons: a key that holds A, B or a direction on/off until pressed again (plus "Release all held buttons").
- Key release delay: ignores very short key-up glitches (30 / 60 / 100 ms).

## Rollover assist
Some remotes drop a key you are still holding when a third key goes down (and which one depends on the order you press them).
Remap buttons > Rollover assist ON: if a key is released within 30 ms of another key going down, it is treated as dropped and kept held until the
other keys are released (or 3 seconds pass). Opposite directions are never treated this way. The Input test shows an event log (newest first) so you can see
exactly which key the remote drops.

Rollover assist now has three levels (Off / Normal 60 ms / Wide 200 ms) and only acts when three keys are involved (the one released plus two others),
so ordinary two-key play is never affected. A key assumed dropped stays held until the other keys are released (or 30 s); tapping that key again clears it.

Rollover assist is modelled on what the G60S Pro really does (seen in the Input test log): it can only report two keys. When a third key goes down it reports
that key and, in the same millisecond, an UP for one of the earlier keys, which is still held. When a slot frees up (the third key is released) it reports the hidden
key's DOWN again. The assist therefore keeps a key that reports UP at the instant a third key goes down (25 ms Normal / 100 ms Wide), and releases it
only if the remote does not re-report it within 60 ms after another key is released.

## Installing updates over the old app
Every build is signed with the same key (app/nestv.keystore) and gets a higher version number (the GitHub run number), so a new APK installs
over the old one without uninstalling. This works from the first build made with this setup onward; the one app installed before it was signed with a
random key and has to be uninstalled once. Keep nestv.keystore in the project: a build signed with a different key cannot update it.

## Start-screen settings and external storage
The ROM list now has "Settings (graphics, controls...)" at the top: graphics and CRT options, frame skip, remapping (with combos, holds, rollover assist and input test),
fast-forward and rapid-fire speed, touch controls. Only moving the touch buttons needs the game screen (in-game pause menu).
External storage: "Choose ROM folder" now lists every USB stick / SD card it can find (StorageManager, the app's per-volume folders, /storage, /mnt/media_rw, /mnt/usb*),
and "Pick a folder with the system picker" uses Android's own folder picker (works for any USB stick or SD card, no extra permission). Both survive restarts.

## Left/Right toggle mode
Remap buttons > "Left/Right keys toggle": tap Left or Right once to start walking, tap again to stop (tapping the opposite direction switches). With a remote that can only
report two keys at once this leaves both free for B and A. The Hold buttons now also switch the opposite direction off.

## Mapper notes
9/10 MMC2/MMC4 (Punch-Out!!, Fire Emblem), 11 Color Dreams, 21/22/23/25 Konami VRC2/VRC4, 24/26 VRC6 (no extra sound channels), 34 BNROM/NINA-001,
69 Sunsoft FME-7 (no 5B sound), 71 Codemasters, 73 VRC3, 75 VRC1, 79/87/140/180/184/206 simple discrete boards.
Not supported yet: MMC5 (5), Namco 163 (19), VRC7 (85), Taito TC0190 (33/48), Irem (32/65), Tengen RAMBO-1 (64), Bandai Datach (157), multicart mappers.

## Settings screen and touch themes
Settings (start screen: "Settings..."; in a game: pause menu > "Settings...") is one screen with a dropdown for each choice and sliders for amounts, so a value is picked
directly instead of being cycled: picture style, aspect ratio, frame skip, accurate drawing, FPS counter, scanlines / mask / curve / blur / vignette, sharp scaling,
split-screen timing, fast-forward speed, rapid-fire speed, touch controls on/off, touch theme, touch opacity. Changes apply immediately in a game.
Touch themes: Classic (glass), Dark, NES controller, Colour buttons, Neon, Outline only, Square buttons.
