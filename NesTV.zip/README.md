# NES TV

NES emulator for Google TV / Android TV (also runs on phones). Pure Kotlin, no dependencies.

## Build (GitHub Actions)
Push the contents of this folder to a GitHub repo (the `.github/workflows/build.yml` is included).
When the run finishes, download the `NesTV-debug-apk` artifact and sideload `app-debug.apk`
(adb install, or a "Downloader"/"Send files to TV" app).

Local: `gradle assembleDebug` (JDK 17, Gradle 8.7+, Android SDK 34).

## ROMs
- Copy `.nes` (or `.zip` containing one) to `Android/data/com.nestv/files/roms/`, or any folder on a USB stick.
- "Allow access to all files" in the list lets it see Download/Roms folders. "Open file picker" appears if the TV has a file picker.

## Remote (G60S) / controllers
- Put the G60S in key (D-pad) mode, not air-mouse mode; pair it in Settings > Remotes & accessories.
- First launch asks you to press the remote button to use for A, B, Select, Start. D-pad arrows work by default.
- Back (or gamepad Mode button) opens the pause menu: Resume, Reset, Fast forward, Remap, Exit.
- Bluetooth gamepads work out of the box (D-pad/hat/left stick, A/B/X/Y, Start, Select).

## Support
Mappers 0, 1, 2, 3, 4, 7, 16 (Bandai FCG/LZ93D50 with 24C02 EEPROM), 159 (24C01 EEPROM), 66.
Battery saves and save states (10 slots) are written to the ROM folder/saves, /sdcard/NesTV/saves and the app folder, so they survive an uninstall when storage access is allowed.
Not included: mapper 153/157 (Datach), PAL timing.

## Phones
An on-screen touch pad (D-pad, A, B, Select, Start, menu button top-right) is shown automatically on non-TV devices.
Toggle it in the pause menu ("Touch controls").
