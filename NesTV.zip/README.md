# NES TV

NES emulator for Google TV / Android TV (also runs on phones). Pure Kotlin, no dependencies.

## Build (GitHub Actions)
Push the contents of this folder to a GitHub repo (the `.github/workflows/build.yml` is included).
When the run finishes, download the `NesTV-debug-apk` artifact and sideload `app-debug.apk`
(adb install, or a "Downloader"/"Send files to TV" app).

Local: `gradle assembleDebug` (JDK 17, Gradle 8.7+, Android SDK 34).

## ROMs
- Copy `.nes` (or `.zip` containing one) to `Android/data/com.nestv/files/roms/`, or any folder on a USB stick.
- "Allow access to all files" in the list lets it see Download/Roms folders. "Open file picker" appears if the TV has a file picker.

## Remote (G60S) / controllers
- Put the G60S in key (D-pad) mode, not air-mouse mode; pair it in Settings > Remotes & accessories.
- First launch asks you to press the remote button to use for A, B, Select, Start. D-pad arrows work by default.
- Back (or gamepad Mode button) opens the pause menu: Resume, Reset, Fast forward, Remap, Exit.
- Bluetooth gamepads work out of the box (D-pad/hat/left stick, A/B/X/Y, Start, Select).

## Support
Mappers 0, 1, 2, 3, 4, 7, 16 (Bandai FCG/LZ93D50 with 24C02 EEPROM), 159 (24C01 EEPROM), 66.
Battery saves and save states (10 slots) are written to the ROM folder/saves, /sdcard/NesTV/saves and the app folder, so they survive an uninstall when storage access is allowed.
Not included: mapper 153/157 (Datach), PAL timing.

## Phones
An on-screen touch pad (D-pad, A, B, turbo A/B, Select, Start, menu button top-right) is shown automatically on non-TV devices.
In the pause menu: Touch controls on/off, Touch opacity (slider), Move / resize touch buttons (drag, Smaller/Bigger, Reset, Done), Rapid fire speed (15 or 30 Hz).
Turbo A/B can also be bound to remote keys via Remap; gamepads use R1 = turbo A, L1 = turbo B.

## Graphics
Pause menu > Graphics / CRT effects: picture style presets (sharp pixels, smooth, scanlines, CRT TV, old composite TV),
fine-tune sliders (scanlines, phosphor mask, screen curve, blur, vignette), aspect ratio (4:3, 8:7, fill) and an FPS counter.
The picture is drawn with an OpenGL ES 2 shader; if the full shader cannot be compiled the app falls back to a plain output.

## Remapping
Pause menu > Remap buttons: pick any single button (A, B, Select, Start, Up, Down, Left, Right, Turbo A, Turbo B) and press the key
or gamepad button to use, or run the guided setup. Remapped buttons lose their default keys; "Reset all" restores them.

## Extra key bindings
Remap buttons also lists: Open menu, Fast forward (toggle), Quick save state, Quick load state, Next/Previous save slot.
Quick save/load use the current slot (1-10, shown in a message when you change it, and set when you pick a slot in the menu).
Back / gamepad Mode always open the menu as well.

## Split-screen glitches
Graphics menu: "Accurate mid-line drawing" (ON = the picture follows register writes made part-way along a line;
OFF = each line is drawn from the state at its start) and "Split-screen timing" (shifts the cartridge IRQ earlier/later,
Bandai mapper 16/159). The timing slider is applied live while the game keeps running behind the dialog.

## Frame skip
Graphics menu > Frame skip: Off, Auto (skips drawing only while the device is behind), every 2nd frame, or 2 of every 3 frames.
Skipped frames are still fully emulated (sound, timing, game logic), just not drawn. Fast forward now draws only 1 frame in 4.

## Performance
The APK produced by `gradle assembleDebug` is built non-debuggable and optimised with R8 (see app/build.gradle.kts), because Android runs
debuggable apps much slower. Tile fetching and the CPU bus fast paths were also trimmed.

## Fast forward
Pause menu: "Fast forward" toggles it, "Fast forward speed" cycles 2x / 3x / 4x / Max. While it is on, frames are emulated at that speed but only
about 60 per second are drawn (the rest are emulated without drawing); sound is muted. A slow device simply tops out below the chosen speed.
When fast forward or pause ends, the audio buffer is refilled immediately.

## Remotes that only send two keys at once (e.g. G60S Pro)
Android can handle any number of held keys, but many remotes only transmit two at a time. Remap buttons > Input test shows how many keys the remote
really sends. Workarounds under Remap buttons:
- Combo buttons: one key presses several NES buttons (A+B, Right+B, Right+A+B, Left+A, Up+B ...).
- Hold buttons: a key that holds A, B or a direction on/off until pressed again (plus "Release all held buttons").
- Key release delay: ignores very short key-up glitches (30 / 60 / 100 ms).

## Rollover assist
Some remotes drop a key you are still holding when a third key goes down (and which one depends on the order you press them).
Remap buttons > Rollover assist ON: if a key is released within 30 ms of another key going down, it is treated as dropped and kept held until the
other keys are released (or 3 seconds pass). Opposite directions are never treated this way. The Input test shows an event log (newest first) so you can see
exactly which key the remote drops.

Rollover assist now has three levels (Off / Normal 60 ms / Wide 200 ms) and only acts when three keys are involved (the one released plus two others),
so ordinary two-key play is never affected. A key assumed dropped stays held until the other keys are released (or 30 s); tapping that key again clears it.

Rollover assist only treats a release as a dropped key when it matches what a two-key remote does: exactly two keys were held, a third key went down,
and the key that disappeared is the one that had been down longest. Any other release is handled normally.

## Installing updates over the old app
Every build is signed with the same key (app/nestv.keystore) and gets a higher version number (the GitHub run number), so a new APK installs
over the old one without uninstalling. This works from the first build made with this setup onward; the one app installed before it was signed with a
random key and has to be uninstalled once. Keep nestv.keystore in the project: a build signed with a different key cannot update it.
