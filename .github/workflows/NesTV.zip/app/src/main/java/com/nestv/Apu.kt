package com.nestv

/** 2A03 APU: two pulse channels, triangle, noise, DMC. Produces mono 16-bit samples at SAMPLE_RATE. */
class Apu(private val nes: Nes) {
    companion object {
        const val SAMPLE_RATE = 48000
        const val CPU_HZ = 1789773
        val LEN = intArrayOf(10, 254, 20, 2, 40, 4, 80, 6, 160, 8, 60, 10, 14, 12, 26, 14,
            12, 16, 24, 18, 48, 20, 96, 22, 192, 24, 72, 26, 16, 28, 32, 30)
        val DUTY = intArrayOf(0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
            0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1)
        val NOISE = intArrayOf(4, 8, 16, 32, 64, 96, 128, 160, 202, 254, 380, 508, 762, 1016, 2034, 4068)
        val DMC = intArrayOf(428, 380, 340, 320, 286, 254, 226, 214, 190, 160, 142, 128, 106, 84, 72, 54)
        val PULSE_T = FloatArray(31) { if (it == 0) 0f else 95.52f / (8128f / it + 100f) }
        val TND_T = FloatArray(203) { if (it == 0) 0f else 163.67f / (24329f / it + 100f) }
    }

    private class Pulse(val ch1: Boolean) {
        var en = false; var duty = 0; var halt = false; var cv = false; var vol = 0
        var period = 0; var timer = 0; var seq = 0; var len = 0
        var sweepEn = false; var sweepP = 0; var neg = false; var shift = 0
        var sweepReload = false; var sweepDiv = 0
        var envStart = false; var envDiv = 0; var decay = 0

        fun write(r: Int, v: Int) {
            when (r) {
                0 -> { duty = v shr 6; halt = (v and 0x20) != 0; cv = (v and 0x10) != 0; vol = v and 15 }
                1 -> { sweepEn = (v and 0x80) != 0; sweepP = (v shr 4) and 7; neg = (v and 8) != 0; shift = v and 7; sweepReload = true }
                2 -> period = (period and 0x700) or v
                3 -> {
                    period = (period and 0xFF) or ((v and 7) shl 8)
                    if (en) len = LEN[v shr 3]
                    seq = 0
                    envStart = true
                }
            }
        }

        fun clockTimer() { if (timer == 0) { timer = period; seq = (seq + 1) and 7 } else timer-- }

        fun clockEnv() {
            if (envStart) { envStart = false; decay = 15; envDiv = vol }
            else if (envDiv == 0) {
                envDiv = vol
                if (decay > 0) decay-- else if (halt) decay = 15
            } else envDiv--
        }

        fun clockLen() { if (!halt && len > 0) len-- }

        private fun target(): Int {
            val d = period shr shift
            return if (neg) period - d - (if (ch1) 1 else 0) else period + d
        }

        fun clockSweep() {
            val tg = target()
            if (sweepDiv == 0 && sweepEn && shift > 0 && period >= 8 && tg <= 0x7FF) period = tg
            if (sweepDiv == 0 || sweepReload) { sweepDiv = sweepP; sweepReload = false } else sweepDiv--
        }

        fun out(): Int {
            if (!en || len == 0 || period < 8 || target() > 0x7FF || DUTY[duty * 8 + seq] == 0) return 0
            return if (cv) vol else decay
        }
    }

    private class Tri {
        var en = false; var ctrl = false; var reloadVal = 0; var period = 0; var timer = 0
        var seq = 0; var len = 0; var linear = 0; var linReload = false

        fun write(r: Int, v: Int) {
            when (r) {
                0 -> { ctrl = (v and 0x80) != 0; reloadVal = v and 0x7F }
                2 -> period = (period and 0x700) or v
                3 -> { period = (period and 0xFF) or ((v and 7) shl 8); if (en) len = LEN[v shr 3]; linReload = true }
            }
        }

        fun clockTimer() {
            if (timer == 0) {
                timer = period
                if (len > 0 && linear > 0) seq = (seq + 1) and 31
            } else timer--
        }

        fun clockLinear() {
            if (linReload) linear = reloadVal else if (linear > 0) linear--
            if (!ctrl) linReload = false
        }

        fun clockLen() { if (!ctrl && len > 0) len-- }
        fun out(): Int = if (seq < 16) 15 - seq else seq - 16
    }

    private class Noise {
        var en = false; var halt = false; var cv = false; var vol = 0; var mode = false
        var period = 4; var timer = 0; var sr = 1; var len = 0
        var envStart = false; var envDiv = 0; var decay = 0

        fun write(r: Int, v: Int) {
            when (r) {
                0 -> { halt = (v and 0x20) != 0; cv = (v and 0x10) != 0; vol = v and 15 }
                2 -> { mode = (v and 0x80) != 0; period = NOISE[v and 15] }
                3 -> { if (en) len = LEN[v shr 3]; envStart = true }
            }
        }

        fun clockTimer() {
            if (timer == 0) {
                timer = period - 1
                val fb = (sr and 1) xor ((sr shr (if (mode) 6 else 1)) and 1)
                sr = (sr shr 1) or (fb shl 14)
            } else timer--
        }

        fun clockEnv() {
            if (envStart) { envStart = false; decay = 15; envDiv = vol }
            else if (envDiv == 0) {
                envDiv = vol
                if (decay > 0) decay-- else if (halt) decay = 15
            } else envDiv--
        }

        fun clockLen() { if (!halt && len > 0) len-- }
        fun out(): Int = if (!en || len == 0 || (sr and 1) == 1) 0 else if (cv) vol else decay
    }

    private val p1 = Pulse(true)
    private val p2 = Pulse(false)
    private val tri = Tri()
    private val noise = Noise()

    // DMC
    private var dIrqEn = false
    private var dLoop = false
    private var dRate = DMC[0]
    private var dLevel = 0
    private var dSampleAddr = 0xC000
    private var dSampleLen = 1
    private var dCurAddr = 0xC000
    private var dBytes = 0
    private var dShift = 0
    private var dBits = 8
    private var dSilence = true
    private var dBuf = 0
    private var dBufEmpty = true
    private var dTimer = 0
    var dmcIrq = false

    // frame counter
    private var fc = 0
    private var mode5 = false
    private var inhibit = false
    var frameIrq = false

    val irq: Boolean get() = frameIrq || dmcIrq

    private var odd = false
    private var acc = 0
    private var sum = 0f
    private var cnt = 0
    private var hp = 0f
    private var prevIn = 0f

    val buf = ShortArray(4096)
    var count = 0

    fun takeSamples(dst: ShortArray): Int {
        val n = minOf(count, dst.size)
        System.arraycopy(buf, 0, dst, 0, n)
        count = 0
        return n
    }

    fun write(a: Int, v: Int) {
        when {
            a < 0x4004 -> p1.write(a and 3, v)
            a < 0x4008 -> p2.write(a and 3, v)
            a < 0x400C -> tri.write(a and 3, v)
            a < 0x4010 -> noise.write(a and 3, v)
            a == 0x4010 -> { dIrqEn = (v and 0x80) != 0; if (!dIrqEn) dmcIrq = false; dLoop = (v and 0x40) != 0; dRate = DMC[v and 15] }
            a == 0x4011 -> dLevel = v and 0x7F
            a == 0x4012 -> dSampleAddr = 0xC000 + v * 64
            a == 0x4013 -> dSampleLen = v * 16 + 1
            a == 0x4015 -> {
                p1.en = (v and 1) != 0; if (!p1.en) p1.len = 0
                p2.en = (v and 2) != 0; if (!p2.en) p2.len = 0
                tri.en = (v and 4) != 0; if (!tri.en) tri.len = 0
                noise.en = (v and 8) != 0; if (!noise.en) noise.len = 0
                dmcIrq = false
                if ((v and 0x10) == 0) dBytes = 0
                else if (dBytes == 0) { dCurAddr = dSampleAddr; dBytes = dSampleLen; dFill() }
            }
            a == 0x4017 -> {
                mode5 = (v and 0x80) != 0
                inhibit = (v and 0x40) != 0
                if (inhibit) frameIrq = false
                fc = 0
                if (mode5) { quarter(); half() }
            }
        }
    }

    fun readStatus(): Int {
        var r = 0
        if (p1.len > 0) r = r or 1
        if (p2.len > 0) r = r or 2
        if (tri.len > 0) r = r or 4
        if (noise.len > 0) r = r or 8
        if (dBytes > 0) r = r or 0x10
        if (frameIrq) r = r or 0x40
        if (dmcIrq) r = r or 0x80
        frameIrq = false
        return r
    }

    private fun quarter() { p1.clockEnv(); p2.clockEnv(); noise.clockEnv(); tri.clockLinear() }
    private fun half() {
        p1.clockLen(); p2.clockLen(); tri.clockLen(); noise.clockLen()
        p1.clockSweep(); p2.clockSweep()
    }

    private fun dFill() {
        if (!dBufEmpty || dBytes == 0) return
        dBuf = nes.read(dCurAddr)
        nes.stall += 4
        dCurAddr = ((dCurAddr + 1) and 0xFFFF) or 0x8000
        dBufEmpty = false
        dBytes--
        if (dBytes == 0) {
            if (dLoop) { dCurAddr = dSampleAddr; dBytes = dSampleLen }
            else if (dIrqEn) dmcIrq = true
        }
    }

    private fun dClock() {
        if (dTimer > 0) { dTimer--; return }
        dTimer = dRate - 1
        if (!dSilence) {
            if ((dShift and 1) != 0) { if (dLevel <= 125) dLevel += 2 } else { if (dLevel >= 2) dLevel -= 2 }
            dShift = dShift shr 1
        }
        dBits--
        if (dBits == 0) {
            dBits = 8
            if (dBufEmpty) dSilence = true
            else { dSilence = false; dShift = dBuf; dBufEmpty = true; dFill() }
        }
    }

    fun step(n: Int) {
        for (i in 0 until n) cycle()
    }

    private fun cycle() {
        fc++
        when (fc) {
            7457 -> quarter()
            14913 -> { quarter(); half() }
            22371 -> quarter()
            29829 -> if (!mode5) { quarter(); half(); if (!inhibit) frameIrq = true; fc = 0 }
            37281 -> { quarter(); half(); fc = 0 }
        }
        tri.clockTimer()
        noise.clockTimer()
        dClock()
        if (odd) { p1.clockTimer(); p2.clockTimer() }
        odd = !odd

        val pulse = PULSE_T[p1.out() + p2.out()]
        val tnd = TND_T[3 * tri.out() + 2 * noise.out() + dLevel]
        sum += pulse + tnd
        cnt++
        acc += SAMPLE_RATE
        if (acc >= CPU_HZ) {
            acc -= CPU_HZ
            val s = sum / cnt
            sum = 0f; cnt = 0
            hp = s - prevIn + 0.9995f * hp
            prevIn = s
            if (count < buf.size) buf[count++] = (hp * 32000f).toInt().coerceIn(-32768, 32767).toShort()
        }
    }
}
