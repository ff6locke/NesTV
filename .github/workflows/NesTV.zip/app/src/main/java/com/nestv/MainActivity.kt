package com.nestv

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** D-pad friendly ROM list for Google TV. */
class MainActivity : Activity() {
    private class Item(val label: String, val file: File?, val action: Int) // 0 rom, 1 picker, 2 all-files permission

    private val items = ArrayList<Item>()
    private lateinit var list: ListView
    private lateinit var hint: TextView

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val tv = (convertView as? TextView) ?: TextView(this@MainActivity).apply {
                textSize = 22f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(32, 22, 32, 22)
            }
            tv.text = items[position].label
            return tv
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(96, 48, 96, 48)
            setBackgroundColor(0xFF101010.toInt())
        }
        root.addView(TextView(this).apply {
            text = "NES TV"
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
        })
        hint = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFAAAAAA.toInt())
            setPadding(0, 8, 0, 24)
        }
        root.addView(hint)
        list = ListView(this)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onItem(items[pos]) }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT in 23..32 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        refresh()
    }

    private fun romDir(): File? {
        val base = getExternalFilesDir(null) ?: return null
        val d = File(base, "roms")
        d.mkdirs()
        return d
    }

    private fun refresh() {
        items.clear()
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        if (picker.resolveActivity(packageManager) != null) items.add(Item("Open file picker...", null, 1))
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager())
            items.add(Item("Allow access to all files (shows ROMs in Download, USB...)", null, 2))

        val roots = LinkedHashSet<File>()
        romDir()?.let { roots.add(it) }
        @Suppress("DEPRECATION")
        val ext = Environment.getExternalStorageDirectory()
        for (n in listOf("Roms", "ROMs", "roms", "NES", "nes", "Download", "Downloads")) roots.add(File(ext, n))
        File("/storage").listFiles()?.forEach { if (it.name != "emulated" && it.name != "self") roots.add(it) }

        val found = ArrayList<File>()
        for (r in roots) walk(r, 0, found)
        found.sortBy { it.name.lowercase() }
        for (f in found) items.add(Item(f.name, f, 0))

        hint.text = "ROM folder: ${romDir()?.absolutePath ?: "?"}\n" +
            "Copy .nes or .zip files there (USB / adb push), or use the file picker. Back button inside a game opens the menu."
        adapter.notifyDataSetChanged()
        list.requestFocus()
    }

    private fun walk(dir: File, depth: Int, out: ArrayList<File>) {
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (out.size >= 500) return
            if (f.isDirectory) { if (depth < 3) walk(f, depth + 1, out) }
            else {
                val n = f.name.lowercase()
                if (n.endsWith(".nes") || n.endsWith(".zip")) out.add(f)
            }
        }
    }

    private fun onItem(it: Item) {
        when (it.action) {
            0 -> startActivity(Intent(this, EmuActivity::class.java).putExtra("path", it.file!!.absolutePath))
            1 -> {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                startActivityForResult(i, 42)
            }
            2 -> {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    } catch (e2: Exception) {
                        Toast.makeText(this, "Not available on this device. Use the ROM folder shown above.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 42 && resultCode == RESULT_OK && uri != null) {
            val i = Intent(this, EmuActivity::class.java)
            i.data = uri
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            i.putExtra("name", RomLoader.displayName(this, uri))
            startActivity(i)
        }
    }
}
