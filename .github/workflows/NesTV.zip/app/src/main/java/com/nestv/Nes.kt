package com.nestv

class Nes(val rom: Rom) {
    val mapper: Mapper = createMapper(rom)
    val ppu = Ppu(mapper)
    val apu = Apu(this)
    private val cpu = Cpu(this)
    private val ram = IntArray(0x800)

    @Volatile var pad = 0
    var stall = 0
    private var strobe = false
    private var shiftReg = 0

    init { cpu.reset() }

    fun irqLine() = mapper.irq || apu.irq

    fun read(a: Int): Int = when {
        a < 0x2000 -> ram[a and 0x7FF]
        a < 0x4000 -> ppu.readReg(a and 7)
        a == 0x4015 -> apu.readStatus()
        a == 0x4016 -> {
            if (strobe) (pad and 1) or 0x40
            else {
                val b = shiftReg and 1
                shiftReg = (shiftReg shr 1) or 0x80
                b or 0x40
            }
        }
        a < 0x4020 -> 0
        else -> mapper.cpuRead(a)
    }

    fun write(a: Int, v: Int) {
        when {
            a < 0x2000 -> ram[a and 0x7FF] = v
            a < 0x4000 -> ppu.writeReg(a and 7, v)
            a == 0x4014 -> {
                val base = v shl 8
                for (i in 0 until 256) ppu.dmaWrite(read(base + i))
                stall += 513
            }
            a == 0x4016 -> {
                strobe = (v and 1) != 0
                if (strobe) shiftReg = pad
            }
            a < 0x4018 -> apu.write(a, v)
            a < 0x4020 -> {}
            else -> mapper.cpuWrite(a, v)
        }
    }

    fun runFrame() {
        ppu.frameReady = false
        while (!ppu.frameReady) {
            var c = cpu.step()
            if (stall > 0) { c += stall; stall = 0 }
            mapper.cpuClock(c)
            apu.step(c)
            ppu.step(c * 3)
        }
    }

    fun reset() {
        cpu.reset()
    }
}
