package com.nestv

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class EmuActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var input: InputMap
    private var nes: Nes? = null
    private var romName = "rom"
    private lateinit var saveFile: File
    private var thread: Thread? = null
    private var overlay: TextView? = null

    @Volatile private var holderRef: SurfaceHolder? = null
    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var fast = false
    @Volatile private var resetReq = false
    @Volatile private var saveReq = false

    private val bmp = Bitmap.createBitmap(256, 240, Bitmap.Config.ARGB_8888)
    private val paint = Paint().apply { isFilterBitmap = true }

    private var menuOpen = false
    private var remapPending = false
    private var wizStep = -1
    private val wizMap = HashMap<Int, Int>()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        input = InputMap(this)

        try {
            val path = intent.getStringExtra("path")
            val bytes: ByteArray
            if (path != null) {
                val f = File(path)
                bytes = RomLoader.fromFile(f)
                romName = f.name
            } else {
                val uri = intent.data ?: throw IllegalArgumentException("No ROM given")
                bytes = RomLoader.fromUri(this, uri)
                romName = intent.getStringExtra("name") ?: "rom"
            }
            val n = Nes(Rom(bytes))
            val safe = romName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_")
            saveFile = File(File(filesDir, "saves").also { it.mkdirs() }, "$safe.sav")
            if (saveFile.exists()) n.mapper.loadData(saveFile.readBytes())
            nes = n
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot load ROM: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val frame = FrameLayout(this)
        val sv = SurfaceView(this)
        sv.holder.addCallback(this)
        frame.addView(sv, FrameLayout.LayoutParams(-1, -1))
        overlay = TextView(this).apply {
            textSize = 26f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC000000.toInt())
            setPadding(60, 40, 60, 40)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        frame.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(frame)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        if (!input.configured) startWizard()
        running = true
        thread = Thread({ emuLoop() }, "emu").also { it.start() }
    }

    override fun onResume() {
        super.onResume()
        if (!menuOpen && wizStep < 0) paused = false
    }

    override fun onPause() {
        super.onPause()
        paused = true
        saveReq = true
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        thread?.join(1000)
        nes?.let { persist(it, null) }
    }

    override fun surfaceCreated(holder: SurfaceHolder) { holderRef = holder }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { holderRef = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder) { holderRef = null }

    // ---------- emulation thread ----------
    private fun persist(n: Nes, last: ByteArray?): ByteArray? {
        val d = n.mapper.saveData() ?: return last
        if (last == null || !d.contentEquals(last)) {
            try { saveFile.writeBytes(d) } catch (e: Exception) {}
        }
        return d
    }

    private fun emuLoop() {
        val n = nes ?: return
        var track: AudioTrack? = null
        try {
            val min = AudioTrack.getMinBufferSize(Apu.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            @Suppress("DEPRECATION")
            val t = AudioTrack(
                AudioManager.STREAM_MUSIC, Apu.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 16384), AudioTrack.MODE_STREAM
            )
            t.play()
            track = t
        } catch (e: Exception) {
            track = null
        }

        val tmp = ShortArray(4096)
        var next = System.nanoTime()
        var lastSave = System.currentTimeMillis()
        var lastData: ByteArray? = n.mapper.saveData()

        while (running) {
            val now = System.currentTimeMillis()
            if (saveReq || now - lastSave > 5000) {
                saveReq = false
                lastSave = now
                lastData = persist(n, lastData)
            }
            if (paused) {
                try { Thread.sleep(30) } catch (e: InterruptedException) {}
                next = System.nanoTime()
                continue
            }
            if (resetReq) { resetReq = false; n.reset() }

            if (fast) {
                for (i in 0 until 4) {
                    n.pad = input.pad
                    n.runFrame()
                    n.apu.count = 0
                }
                draw(n)
                continue
            }

            n.pad = input.pad
            n.runFrame()
            draw(n)
            val cnt = n.apu.takeSamples(tmp)
            val t = track
            if (t != null) {
                if (t.write(tmp, 0, cnt) < 0) { t.release(); track = null }
            } else {
                next += 16_639_267L
                val d = next - System.nanoTime()
                if (d > 0) {
                    try { Thread.sleep(d / 1_000_000, (d % 1_000_000).toInt()) } catch (e: InterruptedException) {}
                } else if (d < -100_000_000L) next = System.nanoTime()
            }
        }
        track?.release()
    }

    private fun draw(n: Nes) {
        val h = holderRef ?: return
        bmp.setPixels(n.ppu.fb, 0, 256, 0, 0, 256, 240)
        try {
            val c = h.lockCanvas() ?: return
            try {
                c.drawColor(Color.BLACK)
                val vw = c.width
                val vh = c.height
                var dh = vh
                var dw = dh * 4 / 3
                if (dw > vw) { dw = vw; dh = dw * 3 / 4 }
                val l = (vw - dw) / 2
                val t = (vh - dh) / 2
                c.drawBitmap(bmp, null, Rect(l, t, l + dw, t + dh), paint)
            } finally {
                h.unlockCanvasAndPost(c)
            }
        } catch (e: Exception) {}
    }

    // ---------- input ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (wizStep >= 0) { handleWizard(e); return true }
        val kc = e.keyCode
        if (kc == KeyEvent.KEYCODE_BACK || kc == KeyEvent.KEYCODE_BUTTON_MODE || kc == KeyEvent.KEYCODE_ESCAPE) {
            if (e.action == KeyEvent.ACTION_UP) showMenu()
            return true
        }
        if (input.onKey(e)) return true
        return super.dispatchKeyEvent(e)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != 0 && input.onMotion(e)) return true
        return super.onGenericMotionEvent(e)
    }

    private fun showMenu() {
        if (menuOpen || wizStep >= 0) return
        menuOpen = true
        paused = true
        input.keys = 0
        input.axes = 0
        val items = arrayOf("Resume", "Reset", "Fast forward: " + (if (fast) "ON" else "OFF"), "Remap A / B / Select / Start", "Exit")
        AlertDialog.Builder(this)
            .setTitle(romName)
            .setItems(items) { _, which ->
                when (which) {
                    1 -> resetReq = true
                    2 -> fast = !fast
                    3 -> remapPending = true
                    4 -> finish()
                }
            }
            .setOnDismissListener {
                menuOpen = false
                if (remapPending) { remapPending = false; startWizard() } else paused = false
            }
            .show()
    }

    private fun startWizard() {
        wizStep = 0
        wizMap.clear()
        paused = true
        showWizardText(null)
    }

    private fun showWizardText(extra: String?) {
        val o = overlay ?: return
        o.visibility = View.VISIBLE
        o.text = "Press the remote button to use as  " + InputMap.NAMES[wizStep] +
            "\n(" + (wizStep + 1) + " of 4)   Back = cancel" + (if (extra != null) "\n$extra" else "")
    }

    private fun endWizard() {
        wizStep = -1
        overlay?.visibility = View.GONE
        paused = false
    }

    private fun handleWizard(e: KeyEvent) {
        if (e.action != KeyEvent.ACTION_DOWN || e.repeatCount > 0) return
        val kc = e.keyCode
        if (kc == KeyEvent.KEYCODE_BACK) {
            if (!input.configured) input.save(emptyMap())
            endWizard()
            return
        }
        if (wizMap.containsKey(kc)) { showWizardText("That key is already used, pick another"); return }
        wizMap[kc] = InputMap.WIZARD_BITS[wizStep]
        wizStep++
        if (wizStep >= InputMap.WIZARD_BITS.size) {
            input.save(wizMap)
            endWizard()
            Toast.makeText(this, "Controls saved", Toast.LENGTH_SHORT).show()
        } else showWizardText(null)
    }
}
